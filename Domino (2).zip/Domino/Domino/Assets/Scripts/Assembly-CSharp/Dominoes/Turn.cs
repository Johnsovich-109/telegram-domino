using System.Collections.Generic;
using System.Text;

namespace Dominoes
{
	public class Turn
	{
		public int index;

		public static int _turnId;

		public int turnUID;

		public bool autoplay;

		public bool isPlayed;

		public Player player;

		public ListBone adding;

		public ListBone available;

		public ListBone moveBone;

		public List<int> moveBranch;

		private int indexAdd;

		public int Count
		{
			get
			{
				return moveBone.Count;
			}
		}

		public bool Skip
		{
			get
			{
				return moveBone.Count == 0 && indexAdd >= adding.Count;
			}
		}

		public Bone MoveBone
		{
			get
			{
				if (index < moveBone.Count)
				{
					return moveBone[index];
				}
				return null;
			}
		}

		public bool CompletedSingle
		{
			get
			{
				return index >= moveBone.Count && indexAdd >= adding.Count;
			}
		}

		public bool CompletedOnline { get; set; }

		public int MoveBranch
		{
			get
			{
				return moveBranch[index];
			}
		}

		public Bone PullAdding
		{
			get
			{
				return (indexAdd >= adding.Count) ? null : adding[indexAdd++];
			}
		}

		protected Turn()
		{
			turnUID = _turnId++;
			adding = new ListBone(2);
			moveBone = new ListBone(2);
			moveBranch = new List<int>();
		}

		public Turn(Player player)
			: this()
		{
			this.player = player;
		}

		public Turn(Player player, Bone move, int branch)
			: this()
		{
			this.player = player;
			moveBone.Add(move);
			moveBranch.Add(branch);
		}

		public void Add(Bone move, int branch)
		{
			moveBone.Add(move);
			moveBranch.Add(branch);
		}

		public void NextStep()
		{
			index++;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("[TURN] " + turnUID);
			stringBuilder.AppendLine("Player id:\t" + player.Id);
			stringBuilder.AppendLine("Adding: \t" + Utils.ToString(adding));
			stringBuilder.AppendLine("Bones: \t" + Utils.ToString(moveBone));
			stringBuilder.AppendLine("Branches: \t" + Utils.ToString(moveBranch));
			stringBuilder.AppendLine("Autoplay: \t" + autoplay);
			return stringBuilder.ToString();
		}
	}
}
