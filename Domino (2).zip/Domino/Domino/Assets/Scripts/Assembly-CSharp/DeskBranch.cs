using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class DeskBranch : List<BoneView>
{
	private DeskView desk;

	private Rect deskRect;

	private int branchRotate;

	private int index;

	private static Vector3[] branchDirections = new Vector3[4]
	{
		new Vector3(-1f, 0f),
		new Vector3(0f, 1f),
		new Vector3(1f, 0f),
		new Vector3(0f, -1f)
	};

	private static int[] converts = new int[4] { 0, 2, 1, 3 };

	private static int[] branchRotates = new int[4] { 1, 0, 3, 2 };

	public DeskBranch(int index, DeskView deskView)
		: base(10)
	{
		desk = deskView;
		this.index = index;
		branchRotate = branchRotates[converts[index]];
	}

	public void Build()
	{
		int num = 0;
		int value = GetStartValue(desk.tileSpinner.Bone);
		deskRect = desk.nodeUI.rect;
		if (base.Count > 1)
		{
			SetPositionFirst(base[0], base[1]);
			SetRotation(base[1], value, num);
			value = GetNextBone(value, base[1].Bone);
		}
		int num2 = 2;
		int num3 = 1;
		while (num2 < base.Count)
		{
			SetPosition(base[num2 - 1], base[num2], num);
			if (CheckOutDesk(base[num2]) && num3 > 1)
			{
				num++;
				num3 = 0;
				SetPositionRotate(base[num2 - 1], base[num2], num);
			}
			SetRotation(base[num2], value, num);
			value = GetNextBone(value, base[num2].Bone);
			num2++;
			num3++;
		}
	}

	public void Reset()
	{
		Clear();
	}

	private bool CheckOutDesk(BoneView bone)
	{
		float num = desk.sizeReal.x * 0.75f;
		return bone.TestPosition.x + num > deskRect.xMax || bone.TestPosition.x - num < deskRect.xMin || bone.TestPosition.y + num > deskRect.yMax || bone.TestPosition.y - num < deskRect.yMin;
	}

	private int GetNextBone(int value, Bone bone)
	{
		if (value == bone.SideA)
		{
			return bone.SideB;
		}
		return bone.SideA;
	}

	private int GetStartValue(Bone bone)
	{
		if (bone.IsDouble)
		{
			return bone.SideA;
		}
		if (index == 0)
		{
			return Mathf.Min(bone.SideA, bone.SideB);
		}
		return Mathf.Max(bone.SideA, bone.SideB);
	}

	private void SetPositionFirst(BoneView boneA, BoneView boneB)
	{
		float num = desk.sizeReal.y;
		if ((boneA.Bone.IsDouble || boneB.Bone.IsDouble) && index < 2)
		{
			num = (desk.sizeReal.x + num) * 0.5f;
		}
		boneB.TestPosition = boneA.TestPosition + Direction() * num;
	}

	private void SetPosition(BoneView boneA, BoneView boneB, int rotate)
	{
		float num = desk.sizeReal.y;
		if (boneA.Bone.IsDouble || boneB.Bone.IsDouble)
		{
			num = (desk.sizeReal.x + num) * 0.5f;
		}
		boneB.TestPosition = boneA.TestPosition + Direction(rotate) * num;
	}

	private void SetPositionRotate(BoneView boneA, BoneView boneB, int rotate)
	{
		float num = 0f;
		float num2 = 0f;
		if (boneA.Bone.IsDouble)
		{
			num = desk.sizeReal.y;
		}
		else if (boneB.Bone.IsDouble)
		{
			num2 = desk.sizeReal.y * 0.25f;
			num = desk.sizeReal.x;
		}
		else
		{
			num2 = desk.sizeReal.y * 0.25f;
			num = desk.sizeReal.y * 0.75f;
		}
		boneB.TestPosition = boneA.TestPosition + Direction(rotate - 1) * num2 + Direction(rotate) * num;
	}

	private void SetRotation(BoneView last, int value, int rotate)
	{
		if (last.Bone.IsDouble)
		{
			rotate++;
		}
		else if (value == last.Bone.SideA)
		{
			rotate += 2;
		}
		last.TestRotate = (branchRotate + rotate + 4) % 4;
	}

	private Vector3 Direction(int rotate = 0)
	{
		return branchDirections[(converts[index] - rotate + 4) % 4];
	}
}
