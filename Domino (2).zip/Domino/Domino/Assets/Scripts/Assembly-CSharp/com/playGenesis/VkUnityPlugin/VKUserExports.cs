using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUserExports
	{
		public int twitter { get; set; }

		public int facebook { get; set; }

		public int livejournal { get; set; }

		public int instagram { get; set; }

		public static VKUserExports Deserialize(object UserExports)
		{
			VKUserExports vKUserExports = new VKUserExports();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)UserExports;
			object value;
			if (dictionary.TryGetValue("twitter", out value))
			{
				vKUserExports.twitter = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("facebook", out value2))
			{
				vKUserExports.facebook = (int)(long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("livejournal", out value3))
			{
				vKUserExports.livejournal = (int)(long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("instagram", out value4))
			{
				vKUserExports.instagram = (int)(long)value4;
			}
			return vKUserExports;
		}
	}
}
