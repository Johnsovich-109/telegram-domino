using System;
using UnityEngine;
using UnityEngine.UI;

public class ChooseCanvas : CanvasManager
{
	public static ChooseCanvas instance;

	public Text textTitle;

	public Text textButtonWatch;

	public Button buttonRewardVideo;

	public BalanceView balance;

	public ChooseGames chooseGames;

	public ChoosePlayers choosePlayers;

	public ChooseRate chooseRates;

	public ChooseFriends chooseFriends;

	public MessagePopupAdvanced chooseMessage;

	private bool updateReward;

	private float counterTime;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool RewardButton
	{
		get
		{
			return buttonRewardVideo.gameObject.activeSelf;
		}
		set
		{
			buttonRewardVideo.gameObject.SetActive(value);
			IsUpdateReward = value;
		}
	}

	public bool IsUpdateReward
	{
		get
		{
			return updateReward;
		}
		set
		{
			if (updateReward != value && (updateReward = value))
			{
				UpdateReward();
			}
		}
	}

	public event Action OnClickReward;

	public override void Show()
	{
		base.Show();
	}

	public override void Hide()
	{
		base.Hide();
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		textButtonWatch.text = TextManager.GetString("shopWatch");
		Reset();
	}

	private void Update()
	{
		if (currentState == DisplayState.Show && updateReward && (counterTime += Time.deltaTime) > 5f)
		{
			UpdateReward();
		}
	}

	public void OnButtonReward()
	{
		if (this.OnClickReward != null)
		{
			this.OnClickReward();
		}
	}

	public void UpdateReward()
	{
		counterTime -= 5f;
		//RewardButton = AdsController.instance.IsRewardReady;
	}
}
