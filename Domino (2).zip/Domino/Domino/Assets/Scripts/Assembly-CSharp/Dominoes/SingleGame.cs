namespace Dominoes
{
	public abstract class SingleGame : ISingleGame
	{
		public ISingleGame singleGame;

		public Desk Desk
		{
			get
			{
				return singleGame.Desk;
			}
		}

		public Heap Heap
		{
			get
			{
				return singleGame.Heap;
			}
			set
			{
				singleGame.Heap = value;
			}
		}

		public bool IsShowScoreBranches
		{
			get
			{
				return singleGame.IsShowScoreBranches;
			}
		}

		public PlayersController Players
		{
			get
			{
				return singleGame.Players;
			}
		}

		public ScoreBranches ScoreBranches
		{
			get
			{
				return singleGame.ScoreBranches;
			}
		}

		public ScoresController Scores
		{
			get
			{
				return singleGame.Scores;
			}
		}

		public GameState State
		{
			get
			{
				return singleGame.State;
			}
			set
			{
				singleGame.State = value;
			}
		}

		public int NumberOfBoneValues
		{
			get
			{
				return singleGame.NumberOfBoneValues;
			}
		}

		public int NumberOfBranches
		{
			get
			{
				return singleGame.NumberOfBranches;
			}
		}

		public int NumberBonesGive
		{
			get
			{
				return singleGame.NumberBonesGive;
			}
		}

		public int FinalScore
		{
			get
			{
				return singleGame.FinalScore;
			}
			set
			{
				singleGame.FinalScore = value;
			}
		}

		protected SingleGame(ISingleGame singleGame)
		{
			this.singleGame = singleGame;
		}

		public virtual Bone Adding()
		{
			return singleGame.Adding();
		}

		public bool CheckLocalWin()
		{
			return singleGame.CheckLocalWin();
		}

		public virtual bool CheckRetake()
		{
			return singleGame.CheckRetake();
		}

		public virtual Turn CreateTurn()
		{
			return singleGame.CreateTurn();
		}

		public virtual Turn CreateTurn(Bone tile)
		{
			return singleGame.CreateTurn(tile);
		}

		public virtual Turn CreateTurn(Bone moveBone, Bone deskBone)
		{
			return singleGame.CreateTurn(moveBone, deskBone);
		}

		public virtual ListBone GetAvailablePlayer()
		{
			return singleGame.GetAvailablePlayer();
		}

		public GameState GetStateGame()
		{
			return singleGame.GetStateGame();
		}

		public virtual TurnData GetTurnData()
		{
			return singleGame.GetTurnData();
		}

		public virtual void NewRound()
		{
			singleGame.NewRound();
		}

		public virtual GameState Next()
		{
			return singleGame.Next();
		}

		public virtual GameState Play(Turn turn)
		{
			return singleGame.Play(turn);
		}

		public virtual void RoundOver()
		{
			singleGame.RoundOver();
		}

		public virtual GameState Scoring()
		{
			return singleGame.Scoring();
		}

		public virtual GameState Surrender()
		{
			return singleGame.Surrender();
		}
	}
}
