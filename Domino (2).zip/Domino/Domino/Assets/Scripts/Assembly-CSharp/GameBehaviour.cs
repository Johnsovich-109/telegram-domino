using UnityEngine;

public class GameBehaviour : MonoBehaviour
{
	private Transform nodeSelf;

	public bool ActiveSelf
	{
		get
		{
			return base.gameObject.activeSelf;
		}
		set
		{
			base.gameObject.SetActive(value);
		}
	}

	public Transform Node
	{
		get
		{
			return nodeSelf ?? (nodeSelf = base.transform);
		}
	}
}
