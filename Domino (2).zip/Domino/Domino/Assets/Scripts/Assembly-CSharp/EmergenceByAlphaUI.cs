using System.Collections;
using UnityEngine;

public class EmergenceByAlphaUI : GameBehaviour
{
	public float timeout = 1f;

	public float exponentiation = 1f;

	public GameObject callbackTarget;

	public bool updateCanvases;

	public string messageShowEnd = "OnShowed";

	public string messageHideEnd = "OnHidden";

	protected DisplayState currentState = DisplayState.Hide;

	protected CanvasRenderer[] canvases;

	private float currentValue;

	private float minValue;

	private float maxValue = 1f;

	private int idCoroutine;

	public float Timeout
	{
		get
		{
			return timeout;
		}
		set
		{
			timeout = value;
		}
	}

	public float Min
	{
		get
		{
			return minValue;
		}
		set
		{
			minValue = Mathf.Clamp(value, 0f, maxValue);
		}
	}

	public float Max
	{
		get
		{
			return maxValue;
		}
		set
		{
			maxValue = Mathf.Clamp(value, minValue, 1f);
		}
	}

	public DisplayState State
	{
		get
		{
			return currentState;
		}
	}

	public bool IsShow
	{
		get
		{
			return currentState == DisplayState.Show || currentState == DisplayState.Showing;
		}
	}

	public bool IsHide
	{
		get
		{
			return currentState == DisplayState.Hide || currentState == DisplayState.Hidding;
		}
	}

	public void Show()
	{
		CheckCanvases();
		idCoroutine++;
		currentValue = maxValue;
		currentState = DisplayState.Show;
		CanvasesSetColor(currentValue);
	}

	public void Hide()
	{
		CheckCanvases();
		idCoroutine++;
		currentValue = minValue;
		currentState = DisplayState.Hide;
		CanvasesSetColor(currentValue);
	}

	public void EmergenceShow()
	{
		CheckCanvases();
		StopAllCoroutines();
		StartCoroutine(Showing());
		currentState = DisplayState.Showing;
	}

	public void EmergenceHide()
	{
		CheckCanvases();
		StopAllCoroutines();
		StartCoroutine(Hiding());
		currentState = DisplayState.Hidding;
	}

	public void EmergenceReset()
	{
		CheckCanvases();
		StopAllCoroutines();
		currentValue = minValue;
		currentState = DisplayState.Hide;
		CanvasesSetColor(currentValue);
	}

	private void CheckCanvases()
	{
		if (updateCanvases || canvases == null)
		{
			canvases = GetComponentsInChildren<CanvasRenderer>();
		}
	}

	private IEnumerator Showing()
	{
		int id = ++idCoroutine;
		while (id == idCoroutine && currentValue < maxValue)
		{
			if ((currentValue += Time.deltaTime / timeout) > maxValue)
			{
				currentValue = maxValue;
			}
			CanvasesSetColor(currentValue);
			yield return null;
		}
		if (messageShowEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageShowEnd, id == idCoroutine);
		}
		if (id == idCoroutine)
		{
			currentState = DisplayState.Show;
		}
	}

	private IEnumerator Hiding()
	{
		int id = ++idCoroutine;
		while (id == idCoroutine && currentValue > minValue)
		{
			if ((currentValue -= Time.deltaTime / timeout) < minValue)
			{
				currentValue = minValue;
			}
			CanvasesSetColor(currentValue);
			yield return null;
		}
		if (messageHideEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageHideEnd, id == idCoroutine);
		}
		if (id == idCoroutine)
		{
			currentState = DisplayState.Hide;
		}
	}

	private void CanvasesSetColor(float delta)
	{
		float alpha = Mathf.Pow(delta, exponentiation);
		for (int i = 0; i < canvases.Length; i++)
		{
			canvases[i].SetAlpha(alpha);
		}
	}
}
