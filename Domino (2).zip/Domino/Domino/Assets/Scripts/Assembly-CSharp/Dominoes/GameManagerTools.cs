using System;
using System.Collections.Generic;

namespace Dominoes
{
	public abstract class GameManagerTools
	{
		protected Player GetStartPlayerByMinBone(PlayersController players)
		{
			int index = 0;
			Bone bone = players[index].GetMinBone();
			for (int i = 1; i < players.Count; i++)
			{
				Bone minBone = players[i].GetMinBone();
				if (minBone.Value < bone.Value)
				{
					bone = minBone;
					index = i;
				}
			}
			return players[index];
		}

		protected Player GetStartPlayerByMaxBone(PlayersController players)
		{
			int index = 0;
			Bone bone = players[index].GetMaxBone();
			for (int i = 1; i < players.Count; i++)
			{
				Bone maxBone = players[i].GetMaxBone();
				if (maxBone.Value > bone.Value)
				{
					bone = maxBone;
					index = i;
				}
			}
			return players[index];
		}

		protected Player GetStartPlayerByDoubles(PlayersController players, int[] startDoubleArray)
		{
			for (int i = 0; i < startDoubleArray.Length; i++)
			{
				Player player = players.Find((Player x) => x.Exists((Bone y) => y.IsDouble && y.SideA == startDoubleArray[i]));
				if (player != null)
				{
					return player;
				}
			}
			return null;
		}

		public T Min<T>(IEnumerable<T> collection, Func<T, int> predicate)
		{
			T result = default(T);
			if (collection == null)
			{
				return result;
			}
			int num = int.MaxValue;
			foreach (T item in collection)
			{
				int num2 = predicate(item);
				if (num2 < num)
				{
					result = item;
					num = num2;
				}
			}
			return result;
		}

		public T Max<T>(IEnumerable<T> collection, Func<T, int> predicate)
		{
			T result = default(T);
			if (collection == null)
			{
				return result;
			}
			int num = int.MinValue;
			foreach (T item in collection)
			{
				int num2 = predicate(item);
				if (num2 > num)
				{
					result = item;
					num = num2;
				}
			}
			return result;
		}
	}
}
