public enum OnSerializeTransform
{
	OnlyPosition = 0,
	OnlyRotation = 1,
	OnlyScale = 2,
	PositionAndRotation = 3,
	All = 4
}
