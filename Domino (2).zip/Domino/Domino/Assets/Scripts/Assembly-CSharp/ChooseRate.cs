using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ChooseRate : PopupBehaviour
{
	public ChooseRateItem[] rateItems;

	public Text textTitle;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<BetItem> OnChooseRate;

	public event Action<string> OnButtonClick;

	public override void Show()
	{
		base.ActiveSelf = true;
		base.Show();
	}

	protected override void OnHidden()
	{
		base.ActiveSelf = false;
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}

	public void Init(BetsCollection bets)
	{
		if (rateItems == null || rateItems.Length == 0)
		{
			throw new Exception("Error: incorrent initialized rates");
		}
		if (bets.Count < 1)
		{
			throw new Exception("Error: incorrect rates");
		}
		ArrayAlignment(bets.Count);
		SetRates(bets);
	}

	private void Start()
	{
		ChooseRateItem[] array = rateItems;
		foreach (ChooseRateItem chooseRateItem in array)
		{
			chooseRateItem.OnChoice += Rate_OnChoice;
		}
		Title = TextManager.GetString("Choose bet");
		base.ActiveSelf = false;
	}

	private void SetRates(BetsCollection bets)
	{
		for (int i = 0; i < bets.Count; i++)
		{
			rateItems[i].Set(bets[i]);
		}
	}

	private void ArrayAlignment(int rates)
	{
		List<ChooseRateItem> list = new List<ChooseRateItem>(rateItems);
		while (list.Count < rates)
		{
			list.Add(CreateChooseRateItem(list[0]));
		}
		while (list.Count > rates)
		{
			RemoveChooseRateItem(list, 0);
		}
		rateItems = list.ToArray();
	}

	private void RemoveChooseRateItem(List<ChooseRateItem> list, int index)
	{
		ChooseRateItem chooseRateItem = list[index];
		list.RemoveAt(index);
		chooseRateItem.OnChoice -= Rate_OnChoice;
		UnityEngine.Object.DestroyObject(chooseRateItem.gameObject);
	}

	private ChooseRateItem CreateChooseRateItem(ChooseRateItem prototype)
	{
		ChooseRateItem chooseRateItem = UnityEngine.Object.Instantiate(prototype);
		chooseRateItem.transform.SetParent(prototype.transform.parent);
		chooseRateItem.transform.localScale = prototype.transform.localScale;
		chooseRateItem.OnChoice += Rate_OnChoice;
		return chooseRateItem;
	}

	private void Rate_OnChoice(BetItem bet)
	{
		if (this.OnChooseRate != null)
		{
			this.OnChooseRate(bet);
		}
	}
}
