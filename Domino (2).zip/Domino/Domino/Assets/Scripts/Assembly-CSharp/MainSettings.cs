using System;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

[ExecuteInEditMode]
public class MainSettings : MonoBehaviour
{
	private static string deviceUID;

	private static MainSettings instance;

	[SerializeField]
	private string productName;

	[SerializeField]
	private string bundleIdentifier;

	[SerializeField]
	private string bundleVersion;

	public static string DeviceUID
	{
		get
		{
			return deviceUID ?? (deviceUID = GetUniqueID());
		}
	}

	public static string OneSignalUserId
	{
		get
		{
			return PlayerPrefs.GetString("onesignal_userid", string.Empty);
		}
		set
		{
			PlayerPrefs.SetString("onesignal_userid", value);
		}
	}

	public static string ProductName
	{
		get
		{
			return (!(instance == null)) ? instance.productName : string.Empty;
		}
	}

	public static string BundleIdentifier
	{
		get
		{
			return (!(instance == null)) ? instance.bundleIdentifier : string.Empty;
		}
	}

	public static string BundleVersion
	{
		get
		{
			return (!(instance == null)) ? instance.bundleVersion : string.Empty;
		}
	}

	public static string GetUniqueID()
	{
		string androidID = GetAndroidID();
		string deviceID = GetDeviceID();
		if (androidID.Length > 0)
		{
			return deviceID + ":" + androidID;
		}
		return deviceID;
	}

	private static string GetDeviceID()
	{
		return GetMD5(SystemInfo.deviceUniqueIdentifier + SystemInfo.deviceModel + SystemInfo.deviceName);
	}

	private static string GetAndroidID()
	{
		try
		{
			AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject @static = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
			AndroidJavaObject androidJavaObject = @static.Call<AndroidJavaObject>("getContentResolver", new object[0]);
			AndroidJavaClass androidJavaClass2 = new AndroidJavaClass("android.provider.Settings$Secure");
			return androidJavaClass2.CallStatic<string>("getString", new object[2] { androidJavaObject, "android_id" });
		}
		catch (Exception ex)
		{
			Debug.Log(ex.Message);
		}
		return string.Empty;
	}

	private static string GetMD5(string text)
	{
		MD5 mD = MD5.Create();
		byte[] array = mD.ComputeHash(Encoding.Default.GetBytes(text));
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < array.Length; i++)
		{
			stringBuilder.Append(array[i].ToString("x2"));
		}
		return stringBuilder.ToString();
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
	}
}
