using System;
using UnityEngine.UI;

public class MessagePopupAdvanced : MessagePopup
{
	public Button buttonOk;

	public Button buttonYes;

	public Button buttonNo;

	private MessageBoxButtons? boxButtons;

	public MessageBoxButtons BoxButtons
	{
		get
		{
			MessageBoxButtons? messageBoxButtons = boxButtons;
			return messageBoxButtons.Value;
		}
		set
		{
			if (boxButtons != value)
			{
				boxButtons = value;
				switch (value)
				{
				case MessageBoxButtons.OK:
					SetOk();
					break;
				case MessageBoxButtons.YesNo:
					SetYesNo();
					break;
				default:
					throw new Exception("Invalid values selected: " + value);
				}
			}
		}
	}

	private void SetOk()
	{
		buttonOk.gameObject.SetActive(true);
		buttonYes.gameObject.SetActive(false);
		buttonNo.gameObject.SetActive(false);
	}

	private void SetYesNo()
	{
		buttonOk.gameObject.SetActive(false);
		buttonYes.gameObject.SetActive(true);
		buttonNo.gameObject.SetActive(true);
	}
}
