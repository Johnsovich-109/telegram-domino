using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using com.playGenesis.VkUnityPlugin;

public class ShareScreenShot : MonoBehaviour
{
	private VkApi vkapi;

	private string _filePath;

	private byte[] jpegScreenShotBytes;

	private void Start()
	{
		vkapi = VkApi.VkApiInstance;
		if (!vkapi.IsUserLoggedIn)
		{
			vkapi.Login();
		}
	}

	public void TakeScreenShot()
	{
		string text = "screnshot.jpg";
		_filePath = Path.Combine(Application.persistentDataPath, text);
		Application.CaptureScreenshot(text);
		StartCoroutine(LoadScreenShot());
	}

	private IEnumerator LoadScreenShot()
	{
		yield return new WaitForSeconds(3f);
		while (!vkapi.IsUserLoggedIn)
		{
			yield return null;
		}
		WWW www = new WWW("file:///" + _filePath);
		yield return www;
		if (string.IsNullOrEmpty(www.error))
		{
			Texture2D texture = www.texture;
			jpegScreenShotBytes = texture.EncodeToJPG();
			List<ShareImage> list = new List<ShareImage>();
			ShareImage shareImage = new ShareImage();
			shareImage.data = jpegScreenShotBytes;
			shareImage.imageName = "screenshot.jpg";
			shareImage.imagetype = ImageType.Jpeg;
			ShareImage item = shareImage;
			list.Add(item);
			VKShare vKShare = new VKShare(OnShareFinished, "Hello From VK Api", list, "http://u3d.as/8HK", 0L);
			vKShare.Share();
		}
	}

	private void OnShareFinished(VKRequest resp)
	{
		if (resp.error == null)
		{
			Debug.Log("Succesfully finished sharing");
		}
	}

	public void Back()
	{
		SceneManager.LoadScene("StarterScene");
	}
}
