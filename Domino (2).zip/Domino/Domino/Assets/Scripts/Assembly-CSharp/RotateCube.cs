using UnityEngine;

public class RotateCube : MonoBehaviour
{
	public int Degree_per_second;

	private void Update()
	{
		base.transform.Rotate(Vector3.up, (float)Degree_per_second * Time.deltaTime);
	}
}
