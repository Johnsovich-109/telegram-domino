using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class PlayersManager : MonoBehaviour
{
	public PlayerPanel[] players;

	public PlayerPanel[] rivals;

	public Transform parentForMain;

	public Transform[] parentsFor2;

	public Transform[] parentsFor3;

	public Transform[] parentsFor4;

	private int playerActiveCount;

	private int indexPlayerActive;

	private Transform[][] parents;

	public PlayerPanel this[int index]
	{
		get
		{
			return players[index];
		}
	}

	public PlayerPanel this[Player player]
	{
		get
		{
			return players[player.Id];
		}
	}

	public int IndexActive
	{
		get
		{
			return indexPlayerActive;
		}
		set
		{
			if (indexPlayerActive != value)
			{
				indexPlayerActive = value;
				PlayerPanel[] array = players;
				foreach (PlayerPanel playerPanel in array)
				{
					playerPanel.IndexActive = value;
				}
			}
		}
	}

	public PlayerPanel PlayerActive
	{
		get
		{
			if (indexPlayerActive > -1)
			{
				return players[indexPlayerActive];
			}
			return null;
		}
	}

	public PlayerPanel Local
	{
		get
		{
			return players[0];
		}
	}

	public void StartGame(int playerCount)
	{
		playerActiveCount = playerCount;
		Set(playerCount);
		IndexActive = -1;
		for (int i = 0; i < players.Length; i++)
		{
			players[i].StartGame(i);
			players[i].IsShow = i < playerCount;
		}
	}

	public void NewRound()
	{
		PlayerPanel[] array = players;
		foreach (PlayerPanel playerPanel in array)
		{
			playerPanel.NewRound();
		}
	}

	public void Clear()
	{
		PlayerPanel[] array = players;
		foreach (PlayerPanel playerPanel in array)
		{
			playerPanel.Clear();
		}
	}

	public void Set(int count)
	{
		Transform[] array = parents[count];
		for (int i = 0; i < array.Length; i++)
		{
			rivals[i].transform.SetParent(array[i]);
			(rivals[i].transform as RectTransform).anchoredPosition = Vector3.zero;
		}
	}

	public void SetGameScores(PlayersController players)
	{
		foreach (Player player in players)
		{
			this[player].DominoScore = player.Score.GameTotal;
		}
	}

	public void Show(PlayersController players)
	{
		foreach (Player player in players)
		{
			this[player].Username = player.Name;
			this[player].avatar.AvatarURL = player.Avatar;
			this[player].avatar.ShowAvatar();
		}
	}

	public void Distribution(ListBone[] bones, List<BoneView>[] tiles, Action callback)
	{
		if (bones.Length != tiles.Length || bones.Length != playerActiveCount)
		{
			throw new Exception("Incorrect data");
		}
		StartCoroutine(DistributionAnimation(bones, tiles, callback));
	}

	private void Awake()
	{
		parents = new Transform[5][] { null, null, parentsFor2, parentsFor3, parentsFor4 };
	}

	private void Start()
	{
		indexPlayerActive = -1;
		PlayerPanel[] array = players;
		foreach (PlayerPanel playerPanel in array)
		{
			playerPanel.DominoScore = 0;
		}
	}

	private IEnumerator DistributionAnimation(ListBone[] bones, List<BoneView>[] tiles, Action callback)
	{
		for (int i = 0; i < playerActiveCount; i++)
		{
			players[i].Push(bones[i], tiles[i]);
			yield return new WaitForSeconds(0.1f * (float)bones[i].Count);
		}
		yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
		if (callback != null)
		{
			callback();
		}
	}
}
