using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUser
	{
		public long id { get; set; }

		public string first_name { get; set; }

		public string last_name { get; set; }

		public string deactivated { get; set; }

		public int hidden { get; set; }

		public int verified { get; set; }

		public int blacklisted { get; set; }

		public int sex { get; set; }

		public string bdate { get; set; }

		public string city { get; set; }

		public string country { get; set; }

		public string home_town { get; set; }

		public string photo_50 { get; set; }

		public string photo_100 { get; set; }

		public string photo_200_orig { get; set; }

		public string photo_200 { get; set; }

		public string photo_400_orig { get; set; }

		public string photo_max { get; set; }

		public string photo_max_orig { get; set; }

		public int online { get; set; }

		public List<long> lists { get; set; }

		public string domain { get; set; }

		public int has_mobile { get; set; }

		public string mobile_phone { get; set; }

		public string home_phone { get; set; }

		public string site { get; set; }

		public long university { get; set; }

		public string university_name { get; set; }

		public long faculty { get; set; }

		public string faculty_name { get; set; }

		public int graduation { get; set; }

		public List<VKUniversity> universities { get; set; }

		public List<VKSchool> schools { get; set; }

		public string status { get; set; }

		public VKAudio status_audio { get; set; }

		public int followers_count { get; set; }

		public int common_count { get; set; }

		public VKCounters counters { get; set; }

		public VKUserOccupation occupation { get; set; }

		public string nickname { get; set; }

		public List<VKUserRelative> relatives { get; set; }

		public int relation { get; set; }

		public VKUserPersonal personal { get; set; }

		public string facebook { get; set; }

		public string twitter { get; set; }

		public string livejournal { get; set; }

		public string instagram { get; set; }

		public VKUserExports exports { get; set; }

		public int wall_comments { get; set; }

		public string activities { get; set; }

		public string interests { get; set; }

		public string movies { get; set; }

		public string tv { get; set; }

		public string books { get; set; }

		public string games { get; set; }

		public string about { get; set; }

		public string quotes { get; set; }

		public int can_post { get; set; }

		public int can_see_all_posts { get; set; }

		public int can_see_audio { get; set; }

		public int can_write_private_message { get; set; }

		public int timezone { get; set; }

		public string screen_name { get; set; }

		public string maiden_name { get; set; }

		public static List<VKUser> Deserialize(object[] Users)
		{
			List<VKUser> list = new List<VKUser>();
			foreach (object user in Users)
			{
				list.Add(Deserialize(user));
			}
			return list;
		}

		public static VKUser Deserialize(object User)
		{
			VKUser vKUser = new VKUser();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)User;
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKUser.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("first_name", out value2))
			{
				vKUser.first_name = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("last_name", out value3))
			{
				vKUser.last_name = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("deactivated", out value4))
			{
				vKUser.deactivated = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("hidden", out value5))
			{
				vKUser.hidden = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("verified", out value6))
			{
				vKUser.verified = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("blacklisted", out value7))
			{
				vKUser.blacklisted = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("sex", out value8))
			{
				vKUser.sex = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("bdate", out value9))
			{
				vKUser.bdate = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("city", out value10))
			{
				vKUser.city = (string)value10;
			}
			object value11;
			if (dictionary.TryGetValue("country", out value11))
			{
				vKUser.country = (string)value11;
			}
			object value12;
			if (dictionary.TryGetValue("home_town", out value12))
			{
				vKUser.home_town = (string)value12;
			}
			object value13;
			if (dictionary.TryGetValue("home_phone", out value13))
			{
				vKUser.home_phone = (string)value13;
			}
			object value14;
			if (dictionary.TryGetValue("photo_50", out value14))
			{
				vKUser.photo_50 = (string)value14;
			}
			object value15;
			if (dictionary.TryGetValue("photo_100", out value15))
			{
				vKUser.photo_100 = (string)value15;
			}
			object value16;
			if (dictionary.TryGetValue("photo_200", out value16))
			{
				vKUser.photo_200 = (string)value16;
			}
			object value17;
			if (dictionary.TryGetValue("photo_200_orig", out value17))
			{
				vKUser.photo_200_orig = (string)value17;
			}
			object value18;
			if (dictionary.TryGetValue("photo_400_orig", out value18))
			{
				vKUser.photo_400_orig = (string)value18;
			}
			object value19;
			if (dictionary.TryGetValue("photo_max", out value19))
			{
				vKUser.photo_max = (string)value19;
			}
			object value20;
			if (dictionary.TryGetValue("photo_max_orig", out value20))
			{
				vKUser.photo_max_orig = (string)value20;
			}
			object value21;
			if (dictionary.TryGetValue("online", out value21))
			{
				vKUser.online = int.Parse(value21.ToString());
			}
			object value22;
			if (dictionary.TryGetValue("lists", out value22))
			{
				vKUser.lists = new List<long>();
				foreach (object item in (List<object>)value22)
				{
					vKUser.lists.Add((long)item);
				}
			}
			object value23;
			if (dictionary.TryGetValue("domain", out value23))
			{
				vKUser.domain = (string)value23;
			}
			object value24;
			if (dictionary.TryGetValue("has_mobile", out value24))
			{
				vKUser.has_mobile = (int)(long)value24;
			}
			object value25;
			if (dictionary.TryGetValue("mobile_phone", out value25))
			{
				vKUser.mobile_phone = (string)value25;
			}
			if (dictionary.TryGetValue("home_phone", out value13))
			{
				vKUser.home_phone = (string)value13;
			}
			object value26;
			if (dictionary.TryGetValue("site", out value26))
			{
				vKUser.site = (string)value26;
			}
			object value27;
			if (dictionary.TryGetValue("university", out value27))
			{
				vKUser.university = (long)value27;
			}
			object value28;
			if (dictionary.TryGetValue("university_name", out value28))
			{
				vKUser.university_name = (string)value28;
			}
			object value29;
			if (dictionary.TryGetValue("faculty", out value29))
			{
				vKUser.faculty = (long)value29;
			}
			object value30;
			if (dictionary.TryGetValue("faculty_name", out value30))
			{
				vKUser.faculty_name = (string)value30;
			}
			object value31;
			if (dictionary.TryGetValue("graduation", out value31))
			{
				vKUser.graduation = (int)(long)value31;
			}
			object value32;
			if (dictionary.TryGetValue("universities", out value32))
			{
				List<VKUniversity> list = new List<VKUniversity>();
				List<object> list2 = (List<object>)value32;
				foreach (object item2 in list2)
				{
					list.Add(VKUniversity.Deserialize(item2));
				}
				vKUser.universities = list;
			}
			object value33;
			if (dictionary.TryGetValue("schools", out value33))
			{
				List<VKSchool> list3 = new List<VKSchool>();
				List<object> list4 = (List<object>)value33;
				foreach (object item3 in list4)
				{
					list3.Add(VKSchool.Deserialize(item3));
				}
				vKUser.schools = list3;
			}
			object value34;
			if (dictionary.TryGetValue("status", out value34))
			{
				vKUser.status = (string)value34;
			}
			object value35;
			if (dictionary.TryGetValue("status_audio", out value35))
			{
				vKUser.status_audio = VKAudio.Deserialize(value35);
			}
			object value36;
			if (dictionary.TryGetValue("followers_count", out value36))
			{
				vKUser.followers_count = (int)(long)value36;
			}
			object value37;
			if (dictionary.TryGetValue("common_count", out value37))
			{
				vKUser.common_count = (int)(long)value37;
			}
			object value38;
			if (dictionary.TryGetValue("counters", out value38))
			{
				vKUser.counters = VKCounters.Deserialize(value38);
			}
			object value39;
			if (dictionary.TryGetValue("occupation", out value39))
			{
				vKUser.occupation = VKUserOccupation.Deserialize(value39);
			}
			object value40;
			if (dictionary.TryGetValue("nickname", out value40))
			{
				vKUser.nickname = (string)value40;
			}
			object value41;
			if (dictionary.TryGetValue("relatives", out value41))
			{
				List<object> list5 = (List<object>)value41;
				List<VKUserRelative> list6 = new List<VKUserRelative>();
				foreach (object item4 in list5)
				{
					list6.Add(VKUserRelative.Deserialize(item4));
				}
				vKUser.relatives = list6;
			}
			object value42;
			if (dictionary.TryGetValue("relation", out value42))
			{
				vKUser.relation = (int)(long)value42;
			}
			object value43;
			if (dictionary.TryGetValue("personal", out value43))
			{
				vKUser.personal = VKUserPersonal.Deserialize(value43);
			}
			object value44;
			if (dictionary.TryGetValue("facebook", out value44))
			{
				vKUser.facebook = (string)value44;
			}
			object value45;
			if (dictionary.TryGetValue("twitter", out value45))
			{
				vKUser.twitter = (string)value45;
			}
			object value46;
			if (dictionary.TryGetValue("livejournal", out value46))
			{
				vKUser.livejournal = (string)value46;
			}
			object value47;
			if (dictionary.TryGetValue("instagram", out value47))
			{
				vKUser.instagram = (string)value47;
			}
			object value48;
			if (dictionary.TryGetValue("exports", out value48))
			{
				vKUser.exports = VKUserExports.Deserialize(value48);
			}
			object value49;
			if (dictionary.TryGetValue("wall_comments", out value49))
			{
				vKUser.wall_comments = (int)(long)value49;
			}
			object value50;
			if (dictionary.TryGetValue("activities", out value50))
			{
				vKUser.activities = (string)value50;
			}
			object value51;
			if (dictionary.TryGetValue("interests", out value51))
			{
				vKUser.interests = (string)value51;
			}
			object value52;
			if (dictionary.TryGetValue("movies", out value52))
			{
				vKUser.movies = (string)value52;
			}
			object value53;
			if (dictionary.TryGetValue("tv", out value53))
			{
				vKUser.tv = (string)value53;
			}
			object value54;
			if (dictionary.TryGetValue("books", out value54))
			{
				vKUser.books = (string)value54;
			}
			object value55;
			if (dictionary.TryGetValue("games", out value55))
			{
				vKUser.games = (string)value55;
			}
			object value56;
			if (dictionary.TryGetValue("about", out value56))
			{
				vKUser.about = (string)value56;
			}
			object value57;
			if (dictionary.TryGetValue("quotes", out value57))
			{
				vKUser.quotes = (string)value57;
			}
			object value58;
			if (dictionary.TryGetValue("can_post", out value58))
			{
				vKUser.can_post = (int)(long)value58;
			}
			object value59;
			if (dictionary.TryGetValue("can_see_all_posts", out value59))
			{
				vKUser.can_see_all_posts = (int)(long)value59;
			}
			object value60;
			if (dictionary.TryGetValue("can_see_audio", out value60))
			{
				vKUser.can_see_audio = (int)(long)value60;
			}
			object value61;
			if (dictionary.TryGetValue("can_write_private_message", out value61))
			{
				vKUser.can_write_private_message = (int)(long)value61;
			}
			object value62;
			if (dictionary.TryGetValue("timezone", out value62))
			{
				vKUser.timezone = (int)(long)value62;
			}
			object value63;
			if (dictionary.TryGetValue("screen_name", out value63))
			{
				vKUser.screen_name = (string)value63;
			}
			object value64;
			if (dictionary.TryGetValue("maiden_name", out value64))
			{
				vKUser.maiden_name = (string)value64;
			}
			return vKUser;
		}
	}
}
