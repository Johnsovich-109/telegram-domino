using System;
using Dominoes;
using UnityEngine.UI;

public class StatisticsPopup : TableStatisticPopup
{
	public Text textTitle;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<string> OnClick;

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	public override void Refresh(ScoresController scores)
	{
		base.Refresh(scores);
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
	}
}
