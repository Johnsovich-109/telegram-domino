using System.Collections;
using UnityEngine;

public class PhotonManager : MonoBehaviour
{
	public static PhotonManager instance;

	private PhotonClient client;

	public PhotonClient Client
	{
		get
		{
			return client;
		}
		set
		{
			client = value;
		}
	}

	public void ToMaster()
	{
		if ((bool)client)
		{
			client.ConnectToMaster();
		}
	}

	public void ToLobby()
	{
		if ((bool)client)
		{
			client.ConnectToLobby();
		}
	}

	public void ToGame()
	{
		if ((bool)client)
		{
			client.ConnectToGame(null, null);
		}
	}

	public void Ready(bool ready)
	{
		if ((bool)client)
		{
			client.ReadyInGame(ready);
		}
	}

	public void ClientCreate()
	{
		client = PhotonClientCreate();
	}

	public void ClientDestroy()
	{
		if ((bool)client)
		{
			StartCoroutine(PhotonClientDestroy(client));
		}
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		PhotonNetwork.lobby = new TypedLobby("dominoes", LobbyType.SqlLobby);
	}

	private PhotonClient PhotonClientCreate()
	{
		GameObject gameObject = new GameObject("Client", typeof(PhotonClient));
		gameObject.transform.SetParent(base.transform);
		return gameObject.GetComponent<PhotonClient>();
	}

	private IEnumerator PhotonClientDestroy(PhotonClient client)
	{
		client.Disconnect();
		yield return null;
		Object.DestroyObject(client.gameObject);
	}
}
