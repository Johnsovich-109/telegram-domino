using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHandController : PlayerHandOpen
{
	public RectTransform imageBoard;

	private BoneView selectTile;

	private int idCoroutine;

	public event Action<BoneView> OnMoveBegin;

	public event Action<BoneView> OnMoveEnd;

	public event Action<BoneView> OnSelectTile;

	public event Action<BoneView> OnUnselectTile;

	public event Action<BoneView, Vector3> OnClickField;

	public BoneView GetNearestBone(BoneView tile, List<BoneView> bones)
	{
		if (bones == null || bones.Count == 0)
		{
			return null;
		}
		if (tile.node.localPosition.y < imageBoard.rect.yMax)
		{
			return null;
		}
		BoneView result = null;
		float num = float.MaxValue;
		foreach (BoneView bone in bones)
		{
			float num2 = Vector3.Distance(tile.node.position, bone.node.position);
			if (num2 < num)
			{
				num = num2;
				result = bone;
			}
		}
		return result;
	}

	public BoneView GetNearestBonePosition(BoneView tile, List<BoneView> bones, Vector3 position)
	{
		if (bones == null || bones.Count == 0)
		{
			return null;
		}
		if (position.y < imageBoard.position.y + imageBoard.rect.height * 0.5f)
		{
			return null;
		}
		BoneView result = null;
		float num = float.MaxValue;
		foreach (BoneView bone in bones)
		{
			float num2 = Vector3.Distance(position, bone.node.position);
			if (num2 < num)
			{
				num = num2;
				result = bone;
			}
		}
		return result;
	}

	public bool GetNearestBone(BoneView tile)
	{
		return tile.node.localPosition.y > imageBoard.rect.yMax;
	}

	public bool GetNearestBonePosition(BoneView tile, Vector3 position)
	{
		return position.y > imageBoard.position.y + imageBoard.rect.height * 0.5f;
	}

	public void BackToHand(BoneView tile)
	{
		collection.Sort((BoneView x, BoneView y) => (!(x.node.localPosition.x < y.node.localPosition.x)) ? 1 : (-1));
		int index = FindIndex(tile);
		selectTile = null;
		StartCoroutine(BackToHandAnimation(index));
	}

	protected override void BonePulled(BoneView tile)
	{
		tile.IsCanMoving = false;
		tile.OnMoveBegin -= BoneTile_OnMoveBegin;
		tile.OnMoveEnd -= BoneTile_OnMoveEnd;
		tile.OnClick -= BoneTile_OnClick;
		TileUnselect();
	}

	protected override void BonePushed(BoneView tile)
	{
		tile.IsCanMoving = true;
		tile.OnMoveBegin += BoneTile_OnMoveBegin;
		tile.OnMoveEnd += BoneTile_OnMoveEnd;
		tile.OnClick += BoneTile_OnClick;
		TileUnselect();
		GameSounds.Play(SoundType.Tile);
	}

	public void TileUnselect()
	{
		if (selectTile != null)
		{
			if (this.OnUnselectTile != null)
			{
				this.OnUnselectTile(selectTile);
			}
			int num = IndexOf(selectTile);
			if (num > -1 && num < base.Count)
			{
				MoveIndexOf(num);
			}
			selectTile = null;
			idCoroutine = 0;
		}
	}

	public void TileSelect(BoneView tile)
	{
		if (this.OnSelectTile != null)
		{
			this.OnSelectTile(tile);
		}
		Vector3 localPosition = tile.node.localPosition;
		localPosition.y += pool.sizeTile.height * scaleInHand * 0.2f;
		tile.mover.Move(localPosition, DominoSettings.TimeMoveBone);
		tile.mover.Scale(scaleInHandVector * 1.2f, DominoSettings.TimeMoveBone);
		StartCoroutine(WaitForMouseButtonUp(tile));
	}

	private void BoneTile_OnClick(BoneView tile)
	{
		if (selectTile == null)
		{
			TileSelect(selectTile = tile);
			return;
		}
		BoneView other = selectTile;
		TileUnselect();
		if (tile.Equals(other))
		{
			selectTile = null;
		}
		else
		{
			TileSelect(selectTile = tile);
		}
	}

	private IEnumerator WaitForMouseButtonUp(BoneView tile)
	{
		int id = ++idCoroutine;
		yield return null;
		while (id == idCoroutine && tile == selectTile)
		{
			if (Input.GetMouseButtonUp(0))
			{
				yield return null;
				if (selectTile == tile && GetNearestBonePosition(tile, Input.mousePosition) && this.OnClickField != null)
				{
					this.OnClickField(selectTile, Input.mousePosition);
				}
			}
			yield return null;
		}
	}

	private void BoneTile_OnMoveBegin(BoneView tile)
	{
		if (this.OnMoveBegin != null)
		{
			this.OnMoveBegin(tile);
		}
	}

	private void BoneTile_OnMoveEnd(BoneView tile)
	{
		if (this.OnMoveEnd != null)
		{
			this.OnMoveEnd(tile);
		}
	}

	private IEnumerator BackToHandAnimation(int index)
	{
		if (index > -1)
		{
			MoveTile(base[index], Vector3.right * position[index]);
		}
		float delta = 0.1f * ((base.Count <= 8) ? 0.5f : 1f);
		for (int i = 0; i < base.Count; i++)
		{
			if (i != index)
			{
				MoveTile(base[i], Vector3.right * position[i]);
				yield return new WaitForSeconds(delta);
			}
		}
	}

	private void MoveTile(BoneView tile, Vector3 tilePosition)
	{
		if (tilePosition != tile.node.localPosition)
		{
			tile.mover.Scale(scaleInHandVector, DominoSettings.TimeMoveBone);
			tile.mover.Move(tilePosition, DominoSettings.TimeMoveBone);
		}
	}

	private int FindIndex(BoneView tile)
	{
		if (tile == null)
		{
			return -1;
		}
		return collection.FindIndex((BoneView x) => x.Id == tile.Id);
	}
}
