namespace com.playGenesis.VkUnityPlugin
{
	public struct VKCaptcha
	{
		public string id;

		public string url;

		public string key;
	}
}
