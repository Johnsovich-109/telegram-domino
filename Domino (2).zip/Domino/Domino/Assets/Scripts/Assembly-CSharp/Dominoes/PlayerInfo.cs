using System;
using ExitGames.Client.Photon;

namespace Dominoes
{
	public class PlayerInfo
	{
		private int exp;

		private string avatar;

		private string username;

		private int balance1;

		private int playerId;

		private int rank;

		private string state;

		private int score;

		private PhotonPlayer player;

		public int GlobalId
		{
			get
			{
				return playerId;
			}
			set
			{
				playerId = value;
			}
		}

		public int ID
		{
			get
			{
				return Player.ID;
			}
		}

		public int Balance
		{
			get
			{
				return balance1;
			}
			set
			{
				balance1 = value;
			}
		}

		public string Username
		{
			get
			{
				return username;
			}
			set
			{
				username = value;
			}
		}

		public string Avatar
		{
			get
			{
				return avatar;
			}
			set
			{
				avatar = value;
			}
		}

		public int Exp
		{
			get
			{
				return exp;
			}
			set
			{
				exp = value;
			}
		}

		public int Rank
		{
			get
			{
				return rank;
			}
			set
			{
				rank = value;
			}
		}

		public string State
		{
			get
			{
				return state;
			}
			set
			{
				state = value;
			}
		}

		public int Score
		{
			get
			{
				return score;
			}
			set
			{
				score = value;
			}
		}

		public PhotonPlayer Player
		{
			get
			{
				return player;
			}
			set
			{
				player = value;
			}
		}

		public bool IsInactive
		{
			get
			{
				return player.IsInactive;
			}
		}

		public PlayerInfo()
		{
		}

		public PlayerInfo(PhotonPlayer player)
		{
			this.player = player;
		}

		public PlayerInfo(PhotonPlayer player, Hashtable properties)
		{
			this.player = player;
			playerId = Convert.ToInt32(properties["id"]);
			exp = Convert.ToInt32(properties["exp"]);
			rank = Convert.ToInt32(properties["rank"]);
			score = Convert.ToInt32(properties["score"]);
			balance1 = Convert.ToInt32(properties["balance1"]);
			state = Convert.ToString(properties["state"]);
			avatar = Convert.ToString(properties["avatar"]);
			username = Convert.ToString(properties["username"]);
		}

		public override string ToString()
		{
			return string.Format("Id: {0}; name: {1}; avatar: {2};", ID, Username, Avatar);
		}
	}
}
