using System;
using System.Collections;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class RoundOverView : GameBehaviour
{
	public const float timeShow = 0.5f;

	public static RoundOverView instance;

	public float scaleInScreen = 1f;

	public Text[] textsScore;

	public RectTransform[] parents;

	public PlayersManager playersManager;

	public Image background;

	public Color colorHide = Color.clear;

	public Color colorShow = Color.black;

	public Color colorShowScore = Color.yellow;

	internal Vector2 sizeReal;

	private bool isShowAnimation;

	private DisplayState currentState = DisplayState.Hide;

	private RoundOverData roundData;

	public DisplayState State
	{
		get
		{
			return currentState;
		}
		set
		{
			currentState = value;
		}
	}

	public bool IsShow
	{
		get
		{
			return currentState == DisplayState.Show || currentState == DisplayState.Showing;
		}
	}

	public bool IsHide
	{
		get
		{
			return currentState == DisplayState.Hide || currentState == DisplayState.Hidding;
		}
	}

	internal Vector2 SizeTile
	{
		get
		{
			return new Vector2(DominoPool.instance.sizeTile.width, DominoPool.instance.sizeTile.height) * 1.1f;
		}
	}

	public event Action OnClick;

	public void Show(RoundOverData data)
	{
		if (IsHide)
		{
			currentState = DisplayState.Showing;
			base.ActiveSelf = true;
			roundData = data;
			GameSounds.Play(SoundType.RoundOver);
			StartCoroutine(Tools.ChangeColor(background, colorHide, colorShow, 0.5f, OnShowed));
			Text[] array = textsScore;
			foreach (Text text in array)
			{
				text.color = colorHide;
				text.text = string.Empty;
			}
		}
	}

	public void Hide()
	{
		if (IsShow)
		{
			currentState = DisplayState.Hidding;
			StartCoroutine(Tools.ChangeColor(background, colorShow, colorHide, 0.5f, OnHidden));
			Text[] array = textsScore;
			foreach (Text text in array)
			{
				StartCoroutine(Tools.ChangeColor(text, colorShowScore, colorHide, DominoSettings.TimeMoveBone));
			}
		}
	}

	public void Sync(RoundOverData data)
	{
		base.ActiveSelf = true;
		background.color = colorShow;
		currentState = DisplayState.Show;
		roundData = data;
		AlignParents(roundData);
		for (int i = 0; i < roundData.Count; i++)
		{
			RectTransform rectTransform = parents[i];
			RoundOverData.Player player = roundData[i];
			Vector2 vector = SizeTile * scaleInScreen;
			float num = Mathf.Clamp(rectTransform.rect.width / (float)(player.Count - 1), 0f, vector.x);
			Vector3 localPosition = Vector3.left * (num * (float)(player.Count - 1) * 0.5f);
			for (int j = 0; j < player.Count; j++)
			{
				BoneView boneView = player.CollectionTile[j];
				boneView.Show(player.CollectionBone[j]);
				boneView.node.SetParent(rectTransform);
				boneView.node.localRotation = Quaternion.identity;
				boneView.node.localPosition = localPosition;
				boneView.node.localScale = Vector3.one * scaleInScreen;
				localPosition.x += num;
			}
			textsScore[i].color = colorShowScore;
			textsScore[i].text = GetTextScore(roundData[i]);
		}
		for (int k = roundData.Count; k < textsScore.Length; k++)
		{
			textsScore[k].color = colorHide;
			textsScore[k].text = string.Empty;
		}
	}

	private IEnumerator ShowAnimation()
	{
		isShowAnimation = true;
		for (int i = 0; i < roundData.Count; i++)
		{
			StartCoroutine(ShowPlayerAnimation(parents[i], roundData[i]));
			StartCoroutine(Tools.ChangeColor(textsScore[i], colorHide, colorShowScore, DominoSettings.TimeMoveBone));
			textsScore[i].text = GetTextScore(roundData[i]);
			yield return new WaitForSeconds((float)roundData[i].Count * 0.1f);
		}
		isShowAnimation = false;
	}

	private IEnumerator ShowPlayerAnimation(RectTransform rect, RoundOverData.Player player)
	{
		Vector2 sizeReal = SizeTile * scaleInScreen;
		float delta = Mathf.Clamp(rect.rect.width / (float)(player.Count - 1), 0f, sizeReal.x);
		Vector3 start = Vector3.left * (delta * (float)(player.Count - 1) * 0.5f);
		for (int i = 0; i < player.Count; i++)
		{
			BoneView tile = player.CollectionTile[i];
			tile.Show(player.CollectionBone[i]);
			tile.node.SetParent(rect);
			tile.node.localRotation = Quaternion.identity;
			tile.mover.Move(start, DominoSettings.TimeMoveBone);
			tile.mover.Scale(scaleInScreen, DominoSettings.TimeMoveBone);
			start.x += delta;
			yield return new WaitForSeconds(0.1f);
		}
	}

	private void AlignParents(RoundOverData roundData)
	{
		for (int i = 1; i < roundData.Count; i++)
		{
			parents[i].position = new Vector3(playersManager.players[i].transform.position.x, parents[i].position.y);
		}
	}

	private void OnShowed()
	{
		currentState = DisplayState.Show;
		AlignParents(roundData);
		StartCoroutine(ShowAnimation());
	}

	private void OnHidden()
	{
		currentState = DisplayState.Hide;
		base.ActiveSelf = false;
	}

	private IEnumerator Autoplay()
	{
		float time = UnityEngine.Random.Range(3f, 6f);
		yield return new WaitForSeconds(time);
		if (IsShow)
		{
			ButtonClick();
		}
	}

	private string GetTextScore(RoundOverData.Player player)
	{
		return player.ScoreBones + " " + TextManager.GetString("Points").ToLower();
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		base.ActiveSelf = false;
	}

	private void Update()
	{
		if (currentState == DisplayState.Show && !isShowAnimation && Input.GetMouseButtonDown(0))
		{
			ButtonClick();
		}
	}

	private void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick();
		}
	}
}
