using System;
using System.Collections.Generic;
using com.playGenesis.VkUnityPlugin.MiniJSON;

namespace com.playGenesis.VkUnityPlugin
{
	[Serializable]
	public class Error : EventArgs
	{
		public string error_code;

		public string error_msg;

		public string fullJson;

		public static Error Deserialize(string json)
		{
			Dictionary<string, object> dictionary = Json.Deserialize(json) as Dictionary<string, object>;
			object value;
			if (dictionary.TryGetValue("error", out value))
			{
				Dictionary<string, object> dictionary2 = (Dictionary<string, object>)value;
				Error error = new Error();
				object value2;
				if (dictionary2.TryGetValue("error_code", out value2))
				{
					error.error_code = ((long)value2/*cast due to .constrained prefix*/).ToString();
				}
				object value3;
				if (dictionary2.TryGetValue("error_msg", out value3))
				{
					error.error_msg = (string)value3;
				}
				return error;
			}
			return null;
		}

		public static Error ParseSerializedFromFromNativeSdk(string errormessage)
		{
			string[] array = errormessage.Split('#');
			Error error = new Error();
			error.error_code = array[0];
			error.error_msg = array[1];
			return error;
		}

		public static Error ParseVkError(string resp)
		{
			if (string.IsNullOrEmpty(resp))
			{
				Error error = new Error();
				error.error_code = "404";
				error.error_msg = "No connection";
				return error;
			}
			Error error2 = Deserialize(resp);
			if (error2 != null && !string.IsNullOrEmpty(error2.error_code))
			{
				Error error3 = new Error();
				error3.error_code = error2.error_code;
				error3.error_msg = error2.error_msg;
				return error3;
			}
			return null;
		}
	}
}
