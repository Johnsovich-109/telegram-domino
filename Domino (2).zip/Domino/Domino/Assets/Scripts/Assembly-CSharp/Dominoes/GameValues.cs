using System;
using UnityEngine;

namespace Dominoes
{
	public class GameValues
	{
		private int? score;

		private int? balance;

		private int? points;

		public int Balance
		{
			get
			{
				int? num = balance;
				return (!num.HasValue) ? PlayerPrefs.GetInt("GameValueBalance", 0) : num.Value;
			}
			set
			{
				if (balance != value)
				{
					balance = value;
					PlayerPrefs.SetInt("GameValueBalance", value);
					if (this.OnChangeBalance != null)
					{
						this.OnChangeBalance(value);
					}
				}
			}
		}

		public int Score
		{
			get
			{
				int? num = score;
				return (!num.HasValue) ? PlayerPrefs.GetInt("GameValueScore", 0) : num.Value;
			}
			set
			{
				if (score != value)
				{
					score = value;
					PlayerPrefs.SetInt("GameValueScore", value);
					if (this.OnChangeScore != null)
					{
						this.OnChangeScore(value);
					}
				}
			}
		}

		public int Points
		{
			get
			{
				int? num = points;
				return (!num.HasValue) ? PlayerPrefs.GetInt("GameValuePoints", 0) : num.Value;
			}
			set
			{
				if (points != value)
				{
					points = value;
					PlayerPrefs.SetInt("GameValuePoints", value);
					if (this.OnChangePoints != null)
					{
						this.OnChangePoints(value);
					}
				}
			}
		}

		public event Action<int> OnChangeBalance;

		public event Action<int> OnChangePoints;

		public event Action<int> OnChangeScore;

		public GameValues()
		{
			score = null;
			balance = null;
			points = null;
		}

		public void Save()
		{
		}
	}
}
