using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKAlbum
	{
		public string id { get; set; }

		public string thumb_id { get; set; }

		public string owner_id { get; set; }

		public string title { get; set; }

		public string description { get; set; }

		public string created { get; set; }

		public string updated { get; set; }

		public int size { get; set; }

		public string thumb_src { get; set; }

		public VKPrivacy privacy_view { get; set; }

		public VKPrivacy privacy_comment { get; set; }

		public static VKAlbum Deserialize(object Album)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Album;
			VKAlbum vKAlbum = new VKAlbum();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKAlbum.id = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("thumb_id", out value2))
			{
				vKAlbum.thumb_id = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("owner_id", out value3))
			{
				vKAlbum.owner_id = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("title", out value4))
			{
				vKAlbum.title = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("description", out value5))
			{
				vKAlbum.description = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("created", out value6))
			{
				vKAlbum.created = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("updated", out value7))
			{
				vKAlbum.updated = (string)value7;
			}
			object value8;
			if (dictionary.TryGetValue("size", out value8))
			{
				vKAlbum.size = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("thumb_src", out value9))
			{
				vKAlbum.thumb_src = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("privacy_view", out value10))
			{
				vKAlbum.privacy_view = VKPrivacy.Deserialize(value10);
			}
			object value11;
			if (dictionary.TryGetValue("privacy_comment", out value11))
			{
				vKAlbum.privacy_comment = VKPrivacy.Deserialize(value11);
			}
			return vKAlbum;
		}
	}
}
