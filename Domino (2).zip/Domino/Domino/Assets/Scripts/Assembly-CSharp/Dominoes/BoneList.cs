namespace Dominoes
{
	public class BoneList : ListBone
	{
	}
}
