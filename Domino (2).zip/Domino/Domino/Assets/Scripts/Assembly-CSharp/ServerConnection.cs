public enum ServerConnection
{
	MasterServer = 0,
	GameServer = 1,
	NameServer = 2
}
