public enum MatchmakingMode : byte
{
	FillRoom = 0,
	SerialMatching = 1,
	RandomMatching = 2
}
