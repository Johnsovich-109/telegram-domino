using System;
using System.Text;

namespace Dominoes
{
	public class OnlineGame : SingleGame, ISingleGame, IOnlineGame
	{
		protected GameState stateOnline;

		protected DateTime turnPassedTime;

		protected TurnQueue queue;

		protected OnlineGameResult gameOverResult;

		protected int syncTime;

		protected bool isGameStarted;

		public float TurnPassedTime
		{
			get
			{
				return (float)(DateTime.Now - turnPassedTime).TotalSeconds;
			}
		}

		public Turn TurnCurrent
		{
			get
			{
				return queue.Peek;
			}
		}

		public OnlineGameResult GameOverResult
		{
			get
			{
				return gameOverResult;
			}
		}

		public int SyncTime
		{
			get
			{
				return syncTime;
			}
		}

		public HeapOnline heapOnline
		{
			get
			{
				return base.Heap as HeapOnline;
			}
		}

		public GameState StateOnline
		{
			get
			{
				return stateOnline;
			}
			set
			{
				stateOnline = value;
			}
		}

		public OnlineGame(ISingleGame single)
			: base(single)
		{
			base.Heap = new HeapOnline(base.NumberOfBoneValues);
			queue = new TurnQueue();
		}

		public override TurnData GetTurnData()
		{
			return new TurnDataOnline();
		}

		public override GameState Next()
		{
			queue.Next();
			return base.Next();
		}

		public override GameState Play(Turn turn)
		{
			if (turn.player.IsLocal)
			{
				return base.Play(turn);
			}
			bool skip = turn.Skip;
			base.Players.Current.Skip = skip;
			if (!skip)
			{
				base.Players.Last = turn.player;
				turn.player.PullRandom();
				base.Desk.Play(turn);
			}
			return base.State = GetStateGame();
		}

		public override Turn CreateTurn()
		{
			return base.CreateTurn();
		}

		public virtual void OnlineStart(int[] ids, int active, int serverId)
		{
			NewRound();
			isGameStarted = true;
			heapOnline.NewRound();
			base.Desk.NewRound();
			base.Players.NewRound();
			base.Players[0].Push(heapOnline.PullBones(ids));
			for (int i = 1; i < base.Players.Count; i++)
			{
				base.Players[i].Push(base.Heap.PullRandom(base.NumberBonesGive));
			}
			base.Players.Index = active;
			queue.Clear();
			base.State = GameState.Play;
			stateOnline = base.State;
			turnPassedTime = DateTime.Now;
			DebugF.Log(" >> OnlineStart. Player active {0}", active);
		}

		public virtual void OnlineAdd(int[] ids, int count, int senderId)
		{
			Turn turn = queue.Check(base.Players[senderId]);
			if (senderId == 0)
			{
				turn.adding = heapOnline.PullBones(ids);
			}
			else
			{
				turn.adding = heapOnline.PullRandom(count);
			}
			DebugF.Log(" >> OnlineAdd. Player {0}; Count: {1}; ids: {2}; ", senderId, count, Utils.ToString(ids));
		}

		public virtual void OnlinePlay(int boneId, int branch, int senderId)
		{
			Turn turn = queue.Check(base.Players[senderId]);
			Bone bone = heapOnline.GetBone(boneId);
			turn.autoplay = senderId == 0;
			turn.Add(bone, branch);
			turn.CompletedOnline = true;
			turnPassedTime = DateTime.Now;
			DebugF.Log(" >> OnlinePlay. Player {0}; Bone {1} ({2}) in {3} ", senderId, boneId, bone.ToString(), branch);
		}

		public virtual void OnlineSkip(int senderId)
		{
			Turn turn = queue.Check(base.Players[senderId]);
			turn.autoplay = senderId == 0;
			turn.CompletedOnline = true;
			turnPassedTime = DateTime.Now;
			DebugF.Log(" >> OnlineSkip. Player {0}; ", senderId);
		}

		public virtual void OnlineSync(GameSync data)
		{
			queue.Clear();
			if (data.state > GameState.Start)
			{
				heapOnline.NewRound();
				if (!isGameStarted && (data.state & GameState.Play) > GameState.Start)
				{
					isGameStarted = true;
					base.Desk.NewRound();
					base.Players.NewRound();
				}
				SyncPlayers(data, heapOnline);
				SyncDesk(data, heapOnline);
				syncTime = data.time;
				base.State = data.state;
				stateOnline = base.State;
			}
			DebugF.Log(" >> OnlineSync. ");
		}

		public virtual void OnlineRoundOver(OnlineRoundResult data)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Player player in base.Players)
			{
				player.Score.Bones = 0;
				player.Score.Round = data.ScoreRound[player.Id];
				player.Score.Game = data.ScoreGame[player.Id];
				player.Score.PlayWon = 0;
				player.Score.Memory = data.ScoreMemory[player.Id];
				player.Score.Round -= player.Score.PlayWon;
				if (!player.IsLocal)
				{
					player.Clear();
					player.Push(heapOnline.GetBones(data.Opponents[player.Id]));
				}
				foreach (Bone item in player)
				{
					player.Score.Bones += item.Value;
				}
				stringBuilder.AppendLine("Player: " + player.Id);
				stringBuilder.AppendLine(player.Score.ToString());
			}
			base.State = (GameState)(2 | ((!data.IsBlocked) ? 4 : 8));
			stateOnline = base.State;
			DebugF.Log(" >> OnlineRoundOver");
			DebugF.LogError(stringBuilder.ToString());
		}

		public virtual void OnlineGameOver(OnlineGameResult data)
		{
			if (base.Scores.Count != data.Count)
			{
				throw new Exception("Error: Invalid number of participants!");
			}
			for (int i = 0; i < base.Scores.Count; i++)
			{
				base.Scores[i].Balance = data.Balances[i];
				base.Scores[i].BalanceChanges = data.BalanceChanges[i];
				base.Scores[i].DiffRating = data.DiffRating[i];
				base.Scores[i].CurrentRating = data.CurrentRating[i];
			}
			switch (data.Status)
			{
			case "surrender":
				base.State = GameState.GameOver;
				break;
			case "normal":
				base.State = (GameState)18;
				break;
			}
			gameOverResult = data;
			stateOnline = base.State;
			DebugF.Log(" >> OnlineGameOver ");
		}

		private void SyncDesk(GameSync data, HeapOnline heapOnline)
		{
			ListBone listBone = new ListBone();
			for (int i = 0; i < data.desk.Length; i++)
			{
				for (int j = 0; j < data.desk[i].Length; j++)
				{
					int id = data.desk[i][j];
					if (!listBone.Exists((Bone x) => x.Id == id))
					{
						listBone.Push(heapOnline.PullBone(id));
					}
				}
			}
			base.Desk.Sync(data.desk, listBone);
		}

		private void SyncPlayers(GameSync data, HeapOnline heapOnline)
		{
			if ((data.state & GameState.RoundOver) > GameState.Start)
			{
				for (int i = 0; i < base.Players.Count; i++)
				{
					base.Players[i].Sync(heapOnline.PullBones(data.idsBoneByPlayers[i]));
				}
			}
			else
			{
				base.Players[0].Sync(heapOnline.PullBones(data.idsBone));
				for (int j = 1; j < base.Players.Count; j++)
				{
					base.Players[j].Sync(base.Heap.PullRandom(data.players[j]));
				}
			}
			base.Players.Index = data.activePlayer;
			for (int k = 0; k < base.Players.Count; k++)
			{
				base.Players[k].Score.Game = data.scoresGame[k];
				base.Players[k].Score.Round = data.scoresRound[k];
				base.Players[k].Score.PlayWon = data.scoresWon[k];
				base.Players[k].Score.Memory = data.scoresMemory[k];
			}
			if ((data.state & GameState.RoundOver) <= GameState.Start)
			{
				return;
			}
			foreach (Player player in base.Players)
			{
				foreach (Bone item in player)
				{
					player.Score.Bones += item.Value;
				}
			}
		}
	}
}
