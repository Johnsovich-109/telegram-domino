public enum SoundType
{
	Button = 0,
	GameOver = 1,
	RoundOver = 2,
	Scoring = 3,
	Select = 4,
	Skip = 5,
	Tile = 6,
	Timer = 7
}
