using System;
using System.Linq;

namespace Dominoes
{
	public class ScoresController
	{
		public readonly int Count;

		private PlayerScores[] scores;

		private int roundId;

		public PlayerScores this[int index]
		{
			get
			{
				return scores[index];
			}
		}

		public int RoundId
		{
			get
			{
				return roundId;
			}
			set
			{
				roundId = value;
			}
		}

		public ScoresController(PlayersController players)
		{
			Count = players.Count;
			scores = new PlayerScores[Count];
			for (int i = 0; i < Count; i++)
			{
				scores[i] = players[i].Score;
			}
		}

		public void NewRound()
		{
			for (int i = 0; i < Count; i++)
			{
				scores[i].RoundNew();
			}
		}

		public void RoundOver(GameState state)
		{
			roundId++;
			bool blocked = (state & GameState.Block) > GameState.Start;
			for (int i = 0; i < Count; i++)
			{
				this[i].RoundOver(blocked);
			}
		}

		internal int Max(Func<PlayerScores, int> predicate)
		{
			return scores.Max(predicate);
		}

		internal int Min(Func<PlayerScores, int> predicate)
		{
			return scores.Min(predicate);
		}

		internal int IndexMax(Func<PlayerScores, int> predicate)
		{
			if (scores == null || scores.Length == 0)
			{
				return -1;
			}
			return MaxInternal(predicate);
		}

		internal int IndexMin(Func<PlayerScores, int> predicate)
		{
			if (scores == null || scores.Length == 0)
			{
				return -1;
			}
			return MinInternal(predicate);
		}

		private int MaxInternal(Func<PlayerScores, int> predicate)
		{
			int num = predicate(scores[0]);
			int result = 0;
			for (int i = 0; i < scores.Length; i++)
			{
				int num2 = predicate(scores[i]);
				if (num < num2)
				{
					num = num2;
					result = i;
				}
			}
			return result;
		}

		private int MinInternal(Func<PlayerScores, int> predicate)
		{
			int num = predicate(scores[0]);
			int result = 0;
			for (int i = 0; i < scores.Length; i++)
			{
				int num2 = predicate(scores[i]);
				if (num > num2)
				{
					num = num2;
					result = i;
				}
			}
			return result;
		}
	}
}
