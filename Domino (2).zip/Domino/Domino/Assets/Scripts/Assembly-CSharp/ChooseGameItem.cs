using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ChooseGameItem : MonoBehaviour
{
	public Image imageIcon;

	public Text textTitle;

	private bool check;

	private GameInfo gameInfo;

	public GameInfo Info
	{
		get
		{
			return gameInfo;
		}
		set
		{
			gameInfo = value;
			imageIcon.sprite = SpriteCollection.GetGameIcon(value.Name);
			textTitle.text = TextManager.GetString(value.Name);
		}
	}

	public event Action<ChooseGameItem> OnChoose;

	public void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnChoose != null)
		{
			this.OnChoose(this);
		}
	}
}
