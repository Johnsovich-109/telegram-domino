namespace Dominoes
{
	public enum GameState
	{
		Start = 0,
		Play = 1,
		RoundOver = 2,
		Won = 4,
		Block = 8,
		GameOver = 0x10,
		Surrender = 0x20
	}
}
