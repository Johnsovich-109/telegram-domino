public class GameCanvas : CanvasManager
{
	public static GameCanvas instance;

	public PanelBranchValues branchValues;

	public DeskView table;

	public PlayersManager players;

	public HeapBox heap;

	public MenuComponent menu;

	public GameMessageSync messageSync;

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		Reset();
	}

	public void NewGame(int branches, int count, string gameName)
	{
		heap.NewGame();
		table.NewGame(branches);
		table.GameName = gameName;
		players.StartGame(count);
		PlayerPanel[] array = players.players;
		foreach (PlayerPanel playerPanel in array)
		{
			playerPanel.avatar.ShowJoin();
		}
	}
}
