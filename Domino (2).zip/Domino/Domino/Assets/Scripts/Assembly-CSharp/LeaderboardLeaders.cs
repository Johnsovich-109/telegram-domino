using UnityEngine.UI;

public class LeaderboardLeaders : GameBehaviour
{
	public LeaderboardPlayerItem[] players;

	public Text textTitle;

	private string scoreLocalized;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public void SetVisibility(bool enable)
	{
		LeaderboardPlayerItem[] array = players;
		foreach (LeaderboardPlayerItem leaderboardPlayerItem in array)
		{
			leaderboardPlayerItem.ActiveSelf = enable;
		}
	}

	public void SetData(ResponseLeaderboardPlayer[] topPlayers)
	{
		int i;
		for (i = 0; i < players.Length && i < topPlayers.Length; i++)
		{
			SetData(players[i], topPlayers[i]);
		}
		for (; i < players.Length; i++)
		{
			players[i].ActiveSelf = false;
		}
	}

	private void Start()
	{
		scoreLocalized = TextManager.GetString("Score") + ": ";
		Title = TextManager.GetString(Title).ToUpper();
	}

	private void SetData(LeaderboardPlayerItem playerView, ResponseLeaderboardPlayer playerData)
	{
		string username = ((playerData.username.Length <= 0) ? "No name" : playerData.username);
		playerView.AvatarURL = playerData.avatar;
		playerView.Username = username;
		playerView.Score = scoreLocalized + playerData.score.ToString("### ### ##0").Trim();
	}
}
