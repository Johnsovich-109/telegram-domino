public class OSNotificationAction
{
	public enum ActionType
	{
		Opened = 0,
		ActionTaken = 1
	}

	public string actionID;

	public ActionType type;
}
