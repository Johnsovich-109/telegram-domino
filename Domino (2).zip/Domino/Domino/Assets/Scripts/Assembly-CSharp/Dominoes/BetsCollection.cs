using System.Collections.Generic;

namespace Dominoes
{
	public class BetsCollection : List<BetItem>
	{
		public BetsCollection()
			: base(4)
		{
			Add(new BetItem("Beginers", 0, 0));
			Add(new BetItem("Rookies", 100, 0));
			Add(new BetItem("Professional", 150, 0));
			Add(new BetItem("Elite", 150, 0));
		}

		public int GetFinalScore(int bet)
		{
			BetItem betItem = Find((BetItem x) => x.Bet == bet);
			if (betItem == null)
			{
				return -1;
			}
			return betItem.Score;
		}
	}
}
