public class OSNotificationOpenedResult
{
	public OSNotificationAction action;

	public OSNotification notification;
}
