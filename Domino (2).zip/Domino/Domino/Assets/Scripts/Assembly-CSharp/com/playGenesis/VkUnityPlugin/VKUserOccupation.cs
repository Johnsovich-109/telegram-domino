using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUserOccupation
	{
		public static readonly string OCCUPATION_TYPE_WORK = "work";

		public static readonly string OCCUPATION_TYPE_SCHOOL = "school";

		public static readonly string OCCUPATION_TYPE_UNIVERSITY = "university";

		public string type { get; set; }

		public long id { get; set; }

		public string name { get; set; }

		public static VKUserOccupation Deserialize(object UserOccupation)
		{
			VKUserOccupation vKUserOccupation = new VKUserOccupation();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)UserOccupation;
			object value;
			if (dictionary.TryGetValue("type", out value))
			{
				vKUserOccupation.type = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("id", out value2))
			{
				vKUserOccupation.id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("name", out value3))
			{
				vKUserOccupation.name = (string)value3;
			}
			return vKUserOccupation;
		}
	}
}
