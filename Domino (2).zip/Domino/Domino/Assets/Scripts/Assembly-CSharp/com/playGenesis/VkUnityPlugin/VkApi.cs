using System;
using System.Collections;
using UnityEngine;

namespace com.playGenesis.VkUnityPlugin
{
	public class VkApi : MonoBehaviour
	{
		public bool IsUserLoggedIn;

		public string VkRequestUrlBase = "https://api.vk.com/method/";

		public static VkApi VkApiInstance;

		public static VKToken CurrentToken;

		public static VkSettings VkSetts;

		public static Downloader Downloader;

		public LoginLogoutBridge nativeBridge = new LoginLogoutBridge();

		private bool loginProccessSterted;

		public static VkApi instance;

		public bool LoginProccessSterted
		{
			get
			{
				return loginProccessSterted;
			}
			set
			{
				loginProccessSterted = value;
			}
		}

		public event EventHandler<Error> AccessDenied;

		public event EventHandler<VKToken> ReceivedNewToken;

		public event Action LoggedIn;

		public event Action LoggedOut;

		private event Action<VKRequest> GlobalErrorHandler;

		public void KillAllReqeusts()
		{
			StopAllCoroutines();
		}

		public void Login()
		{
			if (!loginProccessSterted)
			{
				nativeBridge.Login();
				StartCoroutine(LockLogin5Sec());
			}
		}

		private IEnumerator LockLogin5Sec()
		{
			loginProccessSterted = true;
			yield return new WaitForSeconds(5f);
			loginProccessSterted = false;
		}

		public void Logout()
		{
			nativeBridge.Logout();
		}

		public void onReceiveNewToken(VKToken e)
		{
			CurrentToken.access_token = e.access_token;
			CurrentToken.expires_in = e.expires_in;
			CurrentToken.tokenRecievedTime = e.tokenRecievedTime;
			CurrentToken.user_id = e.user_id;
			CurrentToken.Save();
			if (this.ReceivedNewToken != null)
			{
				this.ReceivedNewToken(this, e);
			}
			onLoggedIn();
			Debug.Log("New token is" + e.access_token);
		}

		public void onLoggedIn()
		{
			StartCoroutine(WaitAndGoOn());
		}

		private IEnumerator WaitAndGoOn()
		{
			while (string.IsNullOrEmpty(CurrentToken.access_token))
			{
				yield return null;
			}
			IsUserLoggedIn = true;
			if (this.LoggedIn != null)
			{
				this.LoggedIn();
			}
		}

		public void onLoggedOut()
		{
			IsUserLoggedIn = false;
			if (this.LoggedOut != null)
			{
				this.LoggedOut();
			}
			VKToken.ResetToken();
		}

		public void onAccessDenied(Error e)
		{
			if (this.AccessDenied != null)
			{
				this.AccessDenied(this, e);
			}
		}

		public void CheckEditorSetup()
		{
			if (string.IsNullOrEmpty(CurrentToken.access_token) || !VKToken.IsValidToken(CurrentToken))
			{
				VkSetts.ProcessAuthUrl();
			}
			if (!VKToken.IsValidToken(CurrentToken))
			{
				Debug.LogError("Token has expired, please relogin to vk in editor");
				Debug.Break();
			}
		}

		public void SubscribeToGlobalErrorEvent(Action<VKRequest> handler)
		{
			if (this.GlobalErrorHandler != null)
			{
				Delegate[] invocationList = this.GlobalErrorHandler.GetInvocationList();
				Delegate[] array = invocationList;
				foreach (Delegate @delegate in array)
				{
					GlobalErrorHandler -= @delegate as Action<VKRequest>;
				}
			}
			GlobalErrorHandler += handler;
		}

		public void UnsubscribeFromGlobalErrorEvent(Action<VKRequest> handler)
		{
			GlobalErrorHandler -= handler;
		}

		private void InitToken()
		{
			CurrentToken = VKToken.LoadPersistent();
		}

		private void Awake()
		{
			instance = this;
			VkSetts = Resources.Load<VkSettings>("VkSettings");
			InitToken();
			UnityEngine.Object.DontDestroyOnLoad(base.transform.gameObject);
			if (VkApiInstance == null)
			{
				VkApiInstance = this;
			}
			if (Downloader == null)
			{
				Downloader = GetComponent<Downloader>();
			}
			if (VKToken.IsValidToken(CurrentToken))
			{
				IsUserLoggedIn = true;
			}
			else
			{
				IsUserLoggedIn = false;
			}
		}

		private WWW GenerateWWWForm(VKRequest httprequest)
		{
			WWWForm wWWForm = new WWWForm();
			wWWForm.AddBinaryData("file", (byte[])httprequest.data[0], (string)httprequest.data[1], (string)httprequest.data[2]);
			return new WWW(Uri.EscapeUriString(httprequest.fullurl), wWWForm);
		}

		private WWW GenerateWWWForm(VKRequest httprequest, FileForUpload file)
		{
			WWWForm wWWForm = new WWWForm();
			wWWForm.AddBinaryData("file", file.data, file.filename, file.mimeType);
			return new WWW(Uri.EscapeUriString(httprequest.fullurl), wWWForm);
		}

		private void HandleTokenExpired(VKRequest httprequest)
		{
			Debug.Log("Invalid token. Are you logged in?");
			httprequest.response = string.Empty;
			httprequest.error = new Error
			{
				error_code = "401",
				error_msg = "invalid token"
			};
			if (this.GlobalErrorHandler != null)
			{
				this.GlobalErrorHandler(httprequest);
			}
			else if (httprequest.CallBackFunction != null)
			{
				httprequest.CallBackFunction(httprequest);
			}
		}

		private void HandleWWWError(WWW www, VKRequest httprequest)
		{
			Error error = new Error();
			error.error_code = "404";
			error.error_msg = www.error;
			Error error2 = error;
			httprequest.response = www.text;
			httprequest.error = error2;
			if (this.GlobalErrorHandler != null)
			{
				this.GlobalErrorHandler(httprequest);
			}
			else if (httprequest.CallBackFunction != null)
			{
				httprequest.CallBackFunction(httprequest);
			}
		}

		private void HandleVKError(WWW www, VKRequest httprequest)
		{
			Error error = Error.ParseVkError(www.text);
			httprequest.response = www.text;
			httprequest.error = error;
			if (this.GlobalErrorHandler != null)
			{
				this.GlobalErrorHandler(httprequest);
			}
			else if (httprequest.CallBackFunction != null)
			{
				httprequest.CallBackFunction(httprequest);
			}
		}

		private void HandleNoError(WWW www, VKRequest httprequest)
		{
			httprequest.response = www.text;
			if (httprequest.CallBackFunction != null)
			{
				httprequest.CallBackFunction(httprequest);
			}
		}

		private void HandleResponse(WWW www, VKRequest httpRequest)
		{
			Error error = Error.ParseVkError(www.text);
			if (!string.IsNullOrEmpty(www.error))
			{
				HandleWWWError(www, httpRequest);
			}
			if (string.IsNullOrEmpty(www.error) && error != null)
			{
				HandleVKError(www, httpRequest);
			}
			if (string.IsNullOrEmpty(www.error) && error == null)
			{
				HandleNoError(www, httpRequest);
			}
		}

		public void Call(VKRequest httprequest)
		{
			httprequest.error = null;
			StartCoroutine(_Call(httprequest));
		}

		private IEnumerator _Call(VKRequest httprequest)
		{
			httprequest.url = ((!httprequest.url.Contains("?")) ? (httprequest.url + "?") : httprequest.url);
			if (string.IsNullOrEmpty(httprequest.fullurl))
			{
				if (httprequest.url.StartsWith("http"))
				{
					httprequest.fullurl = httprequest.url;
				}
				else
				{
					httprequest.fullurl = Utilities.GenerateFullHttpReqString(httprequest.url);
				}
			}
			if (VKToken.IsValidToken(CurrentToken))
			{
				WWW www = new WWW(httprequest.fullurl);
				yield return www;
				HandleResponse(www, httprequest);
			}
			else
			{
				HandleTokenExpired(httprequest);
			}
		}

		public void UploadToserverCall(VKRequest httprequest)
		{
			if (string.IsNullOrEmpty(httprequest.fullurl))
			{
				if (httprequest.url.StartsWith("http"))
				{
					httprequest.fullurl = httprequest.url;
				}
				else
				{
					httprequest.fullurl = Utilities.GenerateFullHttpReqString(httprequest.url);
				}
			}
			StartCoroutine(_UploadToserverCall(httprequest));
		}

		public void UploadToserverCall(VKRequest requestString, FileForUpload file)
		{
			StartCoroutine(_UploadToserverCall(requestString, file));
		}

		private IEnumerator _UploadToserverCall(VKRequest httprequest)
		{
			WWW www = GenerateWWWForm(httprequest);
			yield return www;
			HandleResponse(www, httprequest);
		}

		private IEnumerator _UploadToserverCall(VKRequest httprequest, FileForUpload file)
		{
			WWW www = GenerateWWWForm(httprequest, file);
			yield return www;
			HandleResponse(www, httprequest);
		}
	}
}
