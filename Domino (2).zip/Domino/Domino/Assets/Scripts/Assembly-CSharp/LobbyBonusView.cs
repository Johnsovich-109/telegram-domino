using System.Collections;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class LobbyBonusView : MonoBehaviour
{
	public static LobbyBonusView instance;

	public Text textCoins;

	public Text textTitle;

	public Image imageChecked;

	public Image[] imageLevels;

	public Sprite spriteBonusB;

	public Sprite spriteBonusA;

	private float timer;

	private int bonusLevel;

	private bool isPlay;

	private bool isTimer;

	public string Coins
	{
		get
		{
			return textCoins.text;
		}
		set
		{
			textCoins.text = value;
		}
	}

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public void Show(Bonus bonus)
	{
		Coins = " + " + bonus.Reward;
		BonusState(bonus.IsEnable);
		BonusLevel(bonus.Level);
		if (bonus.IsEnable)
		{
			isTimer = false;
			return;
		}
		timer = bonus.Timer;
		if (!isPlay)
		{
			StartCoroutine(PlayInternal());
		}
	}

	public void BonusLevel(int level)
	{
		if (bonusLevel == level)
		{
			return;
		}
		bonusLevel = level;
		for (int i = 0; i < imageLevels.Length; i++)
		{
			bool flag = i < level;
			imageLevels[i].enabled = flag;
			if (flag)
			{
				imageLevels[i].sprite = ((i != 0) ? spriteBonusA : spriteBonusB);
			}
		}
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		BonusLevel(-1);
	}

	private void BonusState(bool enable)
	{
		if (enable)
		{
			Title = TextManager.GetString("Get bonus").ToUpper();
		}
		imageChecked.enabled = enable;
	}

	private IEnumerator PlayInternal()
	{
		float delta = Time.time;
		isTimer = true;
		isPlay = true;
		Title = GetTime(Mathf.RoundToInt(timer));
		while (isTimer && timer > 0f)
		{
			timer -= Time.time - delta;
			Title = GetTime(Mathf.RoundToInt(timer));
			delta = Time.time;
			yield return new WaitForSeconds(1f);
		}
		if (isTimer)
		{
			BonusState(true);
		}
		isPlay = false;
	}

	private string GetTime(int value)
	{
		int num = value % 60;
		int num2 = value / 60 % 60;
		int num3 = value / 3600;
		return num3.ToString("0") + ":" + num2.ToString("00") + ":" + num.ToString("00");
	}
}
