using System.Collections.Generic;
using MiniJSON;

public class VKFriendsList : List<UserProfile>
{
	public VKFriendsList(string response)
	{
		Dictionary<string, object> dictionary = Json.Deserialize(response) as Dictionary<string, object>;
		Dictionary<string, object> dictionary2 = dictionary["response"] as Dictionary<string, object>;
		long num = (long)dictionary2["count"];
		List<object> list = dictionary2["items"] as List<object>;
		if (num == list.Count)
		{
			Fill(list);
		}
	}

	public VKFriendsList(IEnumerable<UserProfile> collection)
		: base(collection)
	{
	}

	private void Fill(List<object> items)
	{
		foreach (object item in items)
		{
			Dictionary<string, object> dict = item as Dictionary<string, object>;
			Add(new UserProfile(dict));
		}
	}

	public string[] GetIDs()
	{
		string[] array = new string[base.Count];
		for (int i = 0; i < base.Count; i++)
		{
			array[i] = base[i].id.ToString();
		}
		return array;
	}
}
