using UnityEngine;
using UnityEngine.UI;

public class LeaderboardPlayerItem : GameBehaviour
{
	public Text textScore;

	public Text textName;

	public Text textPlace;

	public Text titlePlace;

	public Image imageAvatar;

	public Sprite spriteAvatarDafault;

	private string score;

	private string username;

	private string place;

	private string avatarURL;

	public string Score
	{
		get
		{
			return textScore.text;
		}
		set
		{
			textScore.text = value;
		}
	}

	public string Username
	{
		get
		{
			return textName.text;
		}
		set
		{
			textName.text = value;
		}
	}

	public string Place
	{
		get
		{
			return textPlace.text;
		}
		set
		{
			textPlace.text = value;
		}
	}

	public string AvatarURL
	{
		get
		{
			return avatarURL;
		}
		set
		{
			if (avatarURL != value)
			{
				avatarURL = value;
				if (string.IsNullOrEmpty(value))
				{
					SetDefault();
				}
				else if (!SpriteDownloader.GetAvatar(value, HandleAvatarLoader))
				{
					SetDefault();
				}
			}
		}
	}

	private void SetDefault()
	{
		HandleAvatarLoader(spriteAvatarDafault);
	}

	private void Start()
	{
		if ((bool)titlePlace)
		{
			titlePlace.text = TextManager.GetString("Place");
		}
	}

	private void HandleAvatarLoader(Sprite sprite)
	{
		imageAvatar.sprite = sprite;
	}
}
