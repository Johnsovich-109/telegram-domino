using System;
using System.Collections.Generic;
using System.Text;

namespace Dominoes
{
	public class ListBone : List<Bone>
	{
		private const int capacityDefault = 14;

		public ListBone()
			: base(14)
		{
		}

		public ListBone(int capacity)
			: base(capacity)
		{
		}

		public ListBone(params Bone[] args)
			: base((IEnumerable<Bone>)args)
		{
		}

		public ListBone(IEnumerable<Bone> collection)
			: base(collection)
		{
		}

		public void Initialization(IEnumerable<Bone> initBones)
		{
			Clear();
			AddRange(initBones);
		}

		public Bone FindById(int boneId)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].Id == boneId)
				{
					return base[i];
				}
			}
			return null;
		}

		public Bone Push(Bone bone)
		{
			Add(bone);
			return bone;
		}

		public void Push(IEnumerable<Bone> collection)
		{
			AddRange(collection);
		}

		public Bone Pull(Bone bone)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].Equals(bone))
				{
					return PullInternal(i);
				}
			}
			return null;
		}

		public Bone Pull(int idBone)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].Id == idBone)
				{
					return PullInternal(i);
				}
			}
			return null;
		}

		public Bone PullLast()
		{
			if (base.Count > 0)
			{
				return PullInternal(base.Count - 1);
			}
			return null;
		}

		public Bone PullFirst()
		{
			if (base.Count > 0)
			{
				return PullInternal(0);
			}
			return null;
		}

		public ListBone PullRange(int index, int count)
		{
			if (index + count > base.Count)
			{
				throw new Exception("The collection of fewer items than you need");
			}
			ListBone listBone = new ListBone(count);
			listBone.AddRange(GetRange(index, count));
			RemoveRange(index, count);
			return listBone;
		}

		public ListBone PullRange(int[] ids)
		{
			if (ids == null || ids.Length == 0)
			{
				return null;
			}
			ListBone listBone = new ListBone(ids.Length);
			for (int i = 0; i < ids.Length; i++)
			{
				listBone.Add(Pull(ids[i]));
			}
			return listBone;
		}

		public Bone PullRandom()
		{
			if (base.Count == 0)
			{
				return null;
			}
			Random randomValue = Utils.RandomValue;
			int index = randomValue.Next() % base.Count;
			return PullInternal(index);
		}

		public ListBone PullRandom(int count)
		{
			if (count > base.Count)
			{
				throw new Exception("The collection of fewer items than you need: " + count + " (" + base.Count + ") ");
			}
			ListBone listBone = new ListBone(count);
			Random randomValue = Utils.RandomValue;
			while (listBone.Count < count)
			{
				int index = randomValue.Next() % base.Count;
				listBone.Add(PullInternal(index));
			}
			return listBone;
		}

		private Bone PullInternal(int index)
		{
			Bone result = base[index];
			RemoveAt(index);
			return result;
		}

		public Bone GetMinBone()
		{
			if (base.Count == 0)
			{
				return null;
			}
			int index = 0;
			int value = base[0].Value;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Value < value)
				{
					value = base[index = i].Value;
				}
			}
			return base[index];
		}

		public Bone GetMaxBone()
		{
			if (base.Count == 0)
			{
				return null;
			}
			int index = 0;
			int value = base[0].Value;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Value > value)
				{
					value = base[index = i].Value;
				}
			}
			return base[index];
		}

		public bool Exists(Bone bone)
		{
			if (bone == null)
			{
				return false;
			}
			for (int i = 0; i < base.Count; i++)
			{
				if (bone.Equals(base[i]))
				{
					return true;
				}
			}
			return false;
		}

		public override string ToString()
		{
			if (base.Count == 0)
			{
				return "BoneList is empty";
			}
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < base.Count; i++)
			{
				stringBuilder.Append(string.Concat(base[i], " "));
			}
			return stringBuilder.ToString();
		}
	}
}
