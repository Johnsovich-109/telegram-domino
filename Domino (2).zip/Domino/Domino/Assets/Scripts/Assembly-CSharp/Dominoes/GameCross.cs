namespace Dominoes
{
	public class GameCross : GameManager
	{
		private const int _numberBranches = 4;

		private const int _numberOfBoneValues = 7;

		public GameCross(int players)
			: base(players, 4, 7)
		{
			numberBonesGive = ((players != 2) ? 5 : 7);
			finalScore = 101;
			startDoubleArray = new int[7] { 6, 5, 4, 3, 2, 1, 0 };
		}

		public override bool CheckLocalWin()
		{
			return players.Local.Score.GameTotal < finalScore;
		}
	}
}
