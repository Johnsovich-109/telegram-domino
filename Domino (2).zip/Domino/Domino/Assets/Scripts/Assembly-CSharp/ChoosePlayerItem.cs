using System;
using UnityEngine;
using UnityEngine.UI;

public class ChoosePlayerItem : MonoBehaviour
{
	public Text textTitle;

	public int countPlayer;

	public event Action<ChoosePlayerItem> OnChoice;

	public void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnChoice != null)
		{
			this.OnChoice(this);
		}
	}

	private void Start()
	{
		textTitle.text = countPlayer + " " + TextManager.GetString("Players").ToUpper();
	}
}
