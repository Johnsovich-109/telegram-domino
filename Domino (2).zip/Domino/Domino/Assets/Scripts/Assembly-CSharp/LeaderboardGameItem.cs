using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class LeaderboardGameItem : MonoBehaviour
{
	public Text textTitle;

	public Sprite spriteInactive;

	public Sprite spriteActive;

	public Button button;

	public Image imageButton;

	public Image imageIcon;

	private GameInfo gameInfo;

	private bool isSelect;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public Sprite Icon
	{
		get
		{
			return imageIcon.sprite;
		}
		set
		{
			imageIcon.sprite = value;
		}
	}

	public bool IsSelect
	{
		get
		{
			return isSelect;
		}
		set
		{
			isSelect = value;
			imageButton.sprite = ((!value) ? spriteInactive : spriteActive);
			button.enabled = !value;
		}
	}

	public GameInfo GameInfo
	{
		get
		{
			return gameInfo;
		}
		set
		{
			gameInfo = value;
		}
	}

	public event Action<LeaderboardGameItem> OnClick;

	private void Start()
	{
		button.onClick.AddListener(ButtonClick);
	}

	public void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(this);
		}
	}
}
