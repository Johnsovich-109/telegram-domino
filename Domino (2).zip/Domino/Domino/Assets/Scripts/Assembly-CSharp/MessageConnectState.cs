using System;
using UnityEngine;
using UnityEngine.UI;

public class MessageConnectState : PopupBehaviour
{
	public enum TypeMessage
	{
		Connecting = 0,
		Reconnecting = 1,
		Joining = 2,
		Wait = 3
	}

	public Text textMessage;

	public Image imageIcon;

	public Sprite spriteJoin;

	public Sprite spriteReconnect;

	public Sprite spriteWait;

	public Transform loader;

	public float deltaTimeLoader = 0.1f;

	private float counterTime;

	public string Message
	{
		get
		{
			return textMessage.text;
		}
		set
		{
			textMessage.text = value;
		}
	}

	public event Action<string> OnClick;

	public void Show(TypeMessage typeMessage)
	{
		imageIcon.sprite = GetSprite(typeMessage);
		imageIcon.SetNativeSize();
		Message = GetMessage(typeMessage);
		base.Show();
	}

	public override void Hide()
	{
		base.Hide();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		Reset();
	}

	private void Update()
	{
		if (base.IsShow && (counterTime += Time.deltaTime) > deltaTimeLoader)
		{
			counterTime -= deltaTimeLoader;
			loader.Rotate(0f, 0f, -43f);
		}
	}

	private Sprite GetSprite(TypeMessage message)
	{
		switch (message)
		{
		case TypeMessage.Connecting:
			return spriteReconnect;
		case TypeMessage.Reconnecting:
			return spriteReconnect;
		case TypeMessage.Joining:
			return spriteJoin;
		case TypeMessage.Wait:
			return spriteWait;
		default:
			return null;
		}
	}

	private string GetMessage(TypeMessage typeMessage)
	{
		switch (typeMessage)
		{
		case TypeMessage.Connecting:
		case TypeMessage.Reconnecting:
			return TextManager.GetString("Connecting");
		case TypeMessage.Joining:
		case TypeMessage.Wait:
			return TextManager.GetString("Waiting");
		default:
			return typeMessage.ToString();
		}
	}
}
