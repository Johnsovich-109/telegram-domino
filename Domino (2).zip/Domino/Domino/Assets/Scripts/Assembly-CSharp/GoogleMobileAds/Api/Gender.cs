namespace GoogleMobileAds.Api
{
	public enum Gender
	{
		Unknown = 0,
		Male = 1,
		Female = 2
	}
}
