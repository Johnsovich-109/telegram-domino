using System;
using System.Collections.Generic;
using UnityEngine;
using com.playGenesis.VkUnityPlugin.MiniJSON;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKShare
	{
		private VkApi vkapi;

		private string _text;

		private List<ShareImage> _images;

		private string _link;

		private int _imagesToUpload;

		private List<long> _photoIds = new List<long>();

		private long _group_id;

		public static int RepeatRequest = 5;

		private Action<VKRequest> _callbackFunction;

		public VKShare(Action<VKRequest> CallbackFunction, string text = "", List<ShareImage> images = null, string link = "", long group_id = 0L)
		{
			vkapi = VkApi.VkApiInstance;
			_text = text;
			_images = images;
			_link = link;
			_group_id = group_id;
			if (CallbackFunction == null)
			{
				CallbackFunction = delegate
				{
					Debug.LogError("The Callback Function is not optional in VkShare");
				};
			}
			_callbackFunction = CallbackFunction;
		}

		public void Share()
		{
			if (_images == null)
			{
				PostToWall(RepeatRequest);
				return;
			}
			_imagesToUpload = _images.Count;
			string text = ((_group_id != 0) ? ("group_id=" + _group_id) : string.Empty);
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "photos.getWallUploadServer?" + text;
			vKRequest.data = new object[1] { RepeatRequest };
			vKRequest.CallBackFunction = GotWallUploadServer;
			VKRequest httprequest = vKRequest;
			vkapi.Call(httprequest);
		}

		private void GotWallUploadServer(VKRequest arg1)
		{
			if (arg1.error != null)
			{
				_callbackFunction(arg1);
				return;
			}
			Dictionary<string, object> dictionary = Json.Deserialize(arg1.response) as Dictionary<string, object>;
			Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary["response"];
			string fullurl = (string)dictionary2["upload_url"];
			foreach (ShareImage image in _images)
			{
				FileForUpload fileForUpload = new FileForUpload();
				fileForUpload.data = image.data;
				fileForUpload.filename = image.imageName;
				fileForUpload.mimeType = (string)image.imagetype;
				FileForUpload fileForUpload2 = fileForUpload;
				VKRequest vKRequest = new VKRequest();
				vKRequest.fullurl = fullurl;
				vKRequest.CallBackFunction = PhotoHasBeenUploaded;
				vKRequest.data = new object[2] { RepeatRequest, fileForUpload2 };
				VKRequest requestString = vKRequest;
				vkapi.UploadToserverCall(requestString, fileForUpload2);
			}
		}

		private void PhotoHasBeenUploaded(VKRequest arg1)
		{
			if (arg1.error != null)
			{
				_callbackFunction(arg1);
				return;
			}
			Dictionary<string, object> dictionary = Json.Deserialize(arg1.response) as Dictionary<string, object>;
			long num = (long)dictionary["server"];
			string text = (string)dictionary["photo"];
			string text2 = (string)dictionary["hash"];
			string text3 = ((_group_id != 0) ? ("&group_id=" + _group_id) : string.Empty);
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "photos.saveWallPhoto?photo=" + text + "&server=" + num + "&hash=" + text2 + text3;
			vKRequest.CallBackFunction = OnPhotoSaved;
			vKRequest.data = new object[1] { RepeatRequest };
			VKRequest httprequest = vKRequest;
			vkapi.Call(httprequest);
		}

		private void OnPhotoSaved(VKRequest arg1)
		{
			if (arg1.error != null)
			{
				_callbackFunction(arg1);
				return;
			}
			Dictionary<string, object> dictionary = Json.Deserialize(arg1.response) as Dictionary<string, object>;
			List<object> list = (List<object>)dictionary["response"];
			VKPhoto vKPhoto = VKPhoto.Deserialize(list[0]);
			_photoIds.Add(vKPhoto.id);
			_imagesToUpload--;
			if (_imagesToUpload == 0)
			{
				PostToWall(RepeatRequest);
			}
		}

		private string GenerateAttachementsForWall()
		{
			string text = string.Empty;
			string text2 = ((_group_id != 0) ? ("-" + _group_id) : VkApi.CurrentToken.user_id);
			foreach (long photoId in _photoIds)
			{
				text = text + "photo" + text2 + "_" + photoId + ",";
			}
			return text.Substring(0, text.Length - 1);
		}

		private void PostToWall(int attemptsLeft)
		{
			string text = "wall.post?";
			if (!string.IsNullOrEmpty(_text))
			{
				text = text + "message=" + _text;
			}
			if (_images != null)
			{
				text = text + "&attachments=" + GenerateAttachementsForWall();
			}
			if (_link != null)
			{
				text = text + "," + _link;
			}
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = text;
			vKRequest.CallBackFunction = WhenPosted;
			vKRequest.data = new object[1] { attemptsLeft };
			VKRequest httprequest = vKRequest;
			vkapi.Call(httprequest);
		}

		private void WhenPosted(VKRequest arg1)
		{
			_callbackFunction(arg1);
			Debug.Log("Finished Sharing");
		}
	}
}
