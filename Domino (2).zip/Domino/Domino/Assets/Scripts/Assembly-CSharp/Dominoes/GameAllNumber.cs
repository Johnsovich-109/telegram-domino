using System;

namespace Dominoes
{
	public abstract class GameAllNumber : GameManager, ISingleGame
	{
		protected const int _numberBranches = 4;

		protected const int _numberOfBoneValues = 7;

		protected int playNumber;

		protected GameAllNumber(int players, int number)
			: base(players, 4, 7)
		{
			scoreBranches = new ScoreBranches(desk, number);
			playNumber = number;
			numberBonesGive = ((players != 2) ? 5 : 7);
			finalScore = 100;
			startDoubleArray = new int[7] { 6, 5, 4, 3, 2, 1, 0 };
		}

		public override ListBone GetAvailablePlayer()
		{
			if (desk.IsEmpty)
			{
				return new ListBone(players.Current);
			}
			return GetAvailable(players.Current);
		}

		public override Turn CreateTurn()
		{
			ListBone availablePlayer = GetAvailablePlayer();
			Bone bone = null;
			int num = 0;
			int branch = 0;
			int summ = scoreBranches.Summ;
			foreach (Bone item in availablePlayer)
			{
				foreach (Branch item2 in desk.BranchAvailable)
				{
					if (item2.IsInit && item2.head.Pairing(item))
					{
						int num2 = summ + Opposite(item, item2.head.value);
						if (num2 % playNumber == 0 && num2 > num)
						{
							num = num2;
							bone = item;
							branch = item2.id;
						}
					}
				}
			}
			if (bone != null)
			{
				return new Turn(players.Current, bone, branch);
			}
			return base.CreateTurn();
		}

		public override GameState Scoring()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			while (num2 < players.Count)
			{
				foreach (Bone item in players[num2])
				{
					num3 += item.Value;
				}
				num += num3;
				players[num2].Score.Bones = (players[num2].Score.Temp = num3);
				num2++;
				num3 = 0;
			}
			int index = players.GetScoreTempMin();
			if ((state & GameState.Won) > GameState.Start)
			{
				index = players.Last.Id;
			}
			int num4 = AllNumberAround(num - players[index].Score.Temp * 2);
			players[index].Score.Round += ((num4 > 0) ? num4 : 0);
			for (int i = 0; i < players.Count; i++)
			{
				players[i].Score.Game += players[i].Score.RoundTotal;
				players[i].Score.PlayWon = 0;
			}
			if (CheckGameOver())
			{
				state = (GameState)18;
			}
			return state;
		}

		public override GameState Play(Turn turn)
		{
			state = base.Play(turn);
			base.ScoreBranches.Play(turn.Skip);
			players.Current.Score.PlayWon += base.ScoreBranches.Won;
			return state;
		}

		public override GameState GetStateGame()
		{
			if (CheckGameOver())
			{
				return GameState.GameOver;
			}
			return base.GetStateGame();
		}

		private int AllNumberAround(int score)
		{
			return (int)Math.Round((double)score / (double)playNumber) * playNumber;
		}

		private int Opposite(Bone bone, int value)
		{
			if (bone.IsDouble)
			{
				return bone.SideA - value;
			}
			if (bone.SideA == value)
			{
				return bone.SideB - value;
			}
			return bone.SideA - value;
		}
	}
}
