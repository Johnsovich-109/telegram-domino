using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using com.playGenesis.VkUnityPlugin;
using com.playGenesis.VkUnityPlugin.MiniJSON;

public class CaptchaDialog : QueueWorker<VKRequest>
{
	public Image captchaImage;

	public InputField captchaText;

	private Downloader dnl;

	private VKCaptcha captchaData;

	private string lastaddedCaptchaParams;

	private void Start()
	{
		dnl = Object.FindObjectOfType<Downloader>();
		captchaImage = base.transform.GetChild(0).GetComponent<Image>();
		captchaText = GetComponentInChildren<InputField>();
		captchaText.DeactivateInputField();
	}

	private void ParseCaptchaIdAndUrl(string response)
	{
		Dictionary<string, object> dictionary = Json.Deserialize(response) as Dictionary<string, object>;
		Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary["error"];
		string id = (string)dictionary2["captcha_sid"];
		string url = (string)dictionary2["captcha_img"];
		captchaData.url = url;
		captchaData.id = id;
	}

	protected override void StartProcessing()
	{
		ParseCaptchaIdAndUrl(_current.Element.response);
		if (dnl == null)
		{
			dnl = Object.FindObjectOfType<Downloader>();
		}
		DownloadRequest downloadRequest = new DownloadRequest();
		downloadRequest.url = captchaData.url;
		downloadRequest.onFinished = OnGotCaptchaImage;
		DownloadRequest d = downloadRequest;
		dnl.download(d);
	}

	private void OnGotCaptchaImage(DownloadRequest d)
	{
		if (d.DownloadResult.error == null)
		{
			Rect rect = new Rect(0f, 0f, 130f, 50f);
			Texture2D texture = d.DownloadResult.texture;
			captchaImage.sprite = Sprite.Create(texture, rect, new Vector2(0.5f, 0.5f));
			captchaText.ActivateInputField();
			captchaText.text = string.Empty;
			base.gameObject.SetActive(true);
		}
	}

	public void OnCaptchaEntered(string s)
	{
		captchaData.key = captchaText.text;
		if (_current.Element.url.Contains("captcha_sid"))
		{
			_current.Element.url = _current.Element.url.Replace(lastaddedCaptchaParams, "&captcha_sid=" + captchaData.id + "&captcha_key=" + captchaData.key);
			lastaddedCaptchaParams = "&captcha_sid=" + captchaData.id + "&captcha_key=" + captchaData.key;
		}
		else
		{
			lastaddedCaptchaParams = "&captcha_sid=" + captchaData.id + "&captcha_key=" + captchaData.key;
			VKRequest element = _current.Element;
			string url = element.url;
			element.url = url + "&captcha_sid=" + captchaData.id + "&captcha_key=" + captchaData.key;
		}
		_current.Element.fullurl = null;
		VkApi.VkApiInstance.Call(_current.Element);
		Debug.Log(_current.Element.url);
		base.gameObject.SetActive(false);
		ProccessNext();
	}
}
