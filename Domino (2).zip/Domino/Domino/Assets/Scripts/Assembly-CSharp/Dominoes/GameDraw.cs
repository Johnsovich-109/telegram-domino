namespace Dominoes
{
	public class GameDraw : GameManager
	{
		protected const int _numberBranches = 2;

		protected const int _numberOfBoneValues = 7;

		public GameDraw(int players)
			: base(players, 2, 7)
		{
			numberBonesGive = 7;
			finalScore = 100;
			startDoubleArray = new int[7] { 6, 5, 4, 3, 2, 1, 0 };
		}

		public override GameState Scoring()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			while (num2 < players.Count)
			{
				foreach (Bone item in players[num2])
				{
					num3 += item.Value;
				}
				players[num2].Score.Temp = num3;
				players[num2].Score.Bones = num3;
				num += num3;
				num2++;
				num3 = 0;
			}
			if ((state & GameState.Block) > GameState.Start)
			{
				int scoreTempMin = players.GetScoreTempMin();
				players[scoreTempMin].Score.Round = num - players[scoreTempMin].Score.Temp * 2;
				players[scoreTempMin].Score.Game += players[scoreTempMin].Score.Round;
			}
			else
			{
				players.Last.Score.Round = num;
				players.Last.Score.Game += num;
			}
			if (CheckGameOver())
			{
				return state |= GameState.GameOver;
			}
			return state;
		}
	}
}
