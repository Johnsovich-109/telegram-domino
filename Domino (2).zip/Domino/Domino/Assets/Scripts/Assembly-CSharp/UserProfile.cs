using System.Collections.Generic;
using Dominoes;

public class UserProfile : FriendData
{
	public string deactivated;

	public UserProfile(Dictionary<string, object> dict)
	{
		object value;
		if (dict.TryGetValue("id", out value))
		{
			id = value.ToString();
		}
		if (dict.TryGetValue("first_name", out value))
		{
			username = (string)value;
		}
		if (dict.TryGetValue("last_name", out value))
		{
			username = username + " " + (string)value;
		}
		if (dict.TryGetValue("photo_50", out value))
		{
			avatar = (string)value;
		}
		if (dict.TryGetValue("photo_200", out value))
		{
			avatar = (string)value;
		}
		if (dict.TryGetValue("deactivated", out value))
		{
			deactivated = (string)value;
		}
	}

	public UserProfile(IDictionary<string, object> dict)
	{
		object value;
		if (dict.TryGetValue("id", out value))
		{
			id = (string)value;
		}
		if (dict.TryGetValue("name", out value))
		{
			username = (string)value;
		}
		if (dict.ContainsKey("picture"))
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)dict["picture"];
			Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary["data"];
			avatar = (string)dictionary2["url"];
		}
	}

	public override string ToString()
	{
		return "UserProfile. ID: '" + id + "', uName: '" + username + "', Avatar: '" + avatar + "'.";
	}
}
