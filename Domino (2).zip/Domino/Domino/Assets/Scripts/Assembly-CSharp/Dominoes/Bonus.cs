using System;
using UnityEngine;

namespace Dominoes
{
	public class Bonus
	{
		public bool IsEnable;

		private int[] bonusValues = new int[4] { 100, 150, 250, 500 };

		public int CountLevel
		{
			get
			{
				return bonusValues.Length;
			}
		}

		public int Reward
		{
			get
			{
				return PlayerPrefs.GetInt("bonus_revard", 0);
			}
			set
			{
				PlayerPrefs.SetInt("bonus_revard", value);
			}
		}

		public int Level
		{
			get
			{
				return PlayerPrefs.GetInt("bonus_level", 0);
			}
			set
			{
				PlayerPrefs.SetInt("bonus_level", value);
			}
		}

		public int Timer
		{
			get
			{
				int @int = PlayerPrefs.GetInt("bonus_timer", 0);
				long num = long.Parse(PlayerPrefs.GetString("bonus_timer_update", "0"));
				if (num == 0)
				{
					return -1;
				}
				return @int - (int)(DateTime.Now - DateTime.FromBinary(num)).TotalSeconds;
			}
			set
			{
				PlayerPrefs.SetInt("bonus_timer", value);
				PlayerPrefs.SetString("bonus_timer_update", DateTime.Now.ToBinary().ToString());
			}
		}

		public void Set(int timer, int level, int reward)
		{
			Set(timer, timer == 0, level, reward);
		}

		public void Set(int timer, bool enable, int level, int reward)
		{
			Timer = timer;
			IsEnable = enable;
			Level = level;
			Reward = reward;
		}

		public void Save()
		{
		}
	}
}
