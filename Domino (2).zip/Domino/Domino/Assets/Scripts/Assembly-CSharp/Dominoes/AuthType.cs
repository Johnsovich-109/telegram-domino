namespace Dominoes
{
	public enum AuthType
	{
		None = -1,
		Self = 0,
		GooglePlay = 1,
		Vkontakte = 2,
		Facebook = 3,
		GameCenter = 4,
		Twitter = 5,
		WindowsPhone = 6,
		Email = 7
	}
}
