namespace Dominoes
{
	public class GameKozel : GameManager
	{
		private const int _numberBranches = 2;

		private const int _numberOfBoneValues = 7;

		public GameKozel(int players)
			: base(players, 2, 7)
		{
			numberBonesGive = 7;
			finalScore = 100;
			startDoubleArray = new int[7] { 1, 2, 3, 4, 5, 6, 0 };
			heap.Limit = 1;
		}

		public override GameState Scoring()
		{
			for (int i = 0; i < players.Count; i++)
			{
				int num = 0;
				for (int j = 0; j < players[i].Count; j++)
				{
					num += players[i][j].Value;
				}
				if (players[i].Count == 1 && num == 0)
				{
					num = 10;
				}
				players[i].Score.Bones = num;
				if (num > 12 || players[i].Score.Game > 0)
				{
					players[i].Score.Round = players[i].Score.Memory + num;
					players[i].Score.Memory = 0;
					players[i].Score.Game += players[i].Score.Round;
				}
				else
				{
					players[i].Score.Memory += num;
					players[i].Score.Round = 0;
				}
			}
			if ((state & GameState.Block) == 0)
			{
				players.Last.Score.Memory = 0;
			}
			if (CheckGameOver())
			{
				state = (GameState)18;
			}
			return state;
		}

		public override bool CheckLocalWin()
		{
			return players.Local.Score.GameTotal < finalScore;
		}
	}
}
