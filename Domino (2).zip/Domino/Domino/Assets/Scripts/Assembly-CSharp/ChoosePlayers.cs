using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChoosePlayers : PopupBehaviour
{
	public ChoosePlayerItem[] players;

	public Text textTitle;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<int> OnChoosePlayers;

	public event Action<string> OnButtonClick;

	public void Init(params int[] counts)
	{
		if (players == null || players.Length == 0)
		{
			throw new Exception("Error: incorrent initialized players");
		}
		if (counts.Length < 1)
		{
			throw new Exception("Error: incorrect players");
		}
		ArrayAlignment(counts.Length);
		SetPlayers(counts);
	}

	private void SetPlayers(int[] rates)
	{
	}

	private void ArrayAlignment(int rates)
	{
		List<ChoosePlayerItem> list = new List<ChoosePlayerItem>(players);
		while (list.Count < rates)
		{
			list.Add(CreateChooseRateItem(list[0]));
		}
		while (list.Count > rates)
		{
			RemoveChooseRateItem(list, 0);
		}
		players = list.ToArray();
	}

	private void RemoveChooseRateItem(List<ChoosePlayerItem> list, int index)
	{
		ChoosePlayerItem choosePlayerItem = list[index];
		list.RemoveAt(index);
		choosePlayerItem.OnChoice -= Player_OnChoice;
		UnityEngine.Object.DestroyObject(choosePlayerItem.gameObject);
	}

	private ChoosePlayerItem CreateChooseRateItem(ChoosePlayerItem prototype)
	{
		ChoosePlayerItem choosePlayerItem = UnityEngine.Object.Instantiate(prototype);
		choosePlayerItem.transform.SetParent(prototype.transform.parent);
		choosePlayerItem.transform.localScale = prototype.transform.localScale;
		choosePlayerItem.OnChoice += Player_OnChoice;
		return choosePlayerItem;
	}

	public override void Show()
	{
		base.ActiveSelf = true;
		base.Show();
	}

	protected override void OnHidden()
	{
		base.ActiveSelf = false;
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}

	private void Start()
	{
		ChoosePlayerItem[] array = players;
		foreach (ChoosePlayerItem choosePlayerItem in array)
		{
			choosePlayerItem.OnChoice += Player_OnChoice;
		}
		Title = TextManager.GetString("Choose players");
		base.ActiveSelf = false;
	}

	private void Player_OnChoice(ChoosePlayerItem sender)
	{
		if (this.OnChoosePlayers != null)
		{
			this.OnChoosePlayers(sender.countPlayer);
		}
	}
}
