using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class Place
	{
		public string title { get; set; }

		public string address { get; set; }

		public double latitude { get; set; }

		public double longitude { get; set; }

		public string country { get; set; }

		public string city { get; set; }

		public string icon { get; set; }

		public string type { get; set; }

		public long group_id { get; set; }

		public string group_photo { get; set; }

		public int checkins { get; set; }

		public long updated { get; set; }

		public static Place Deserialize(object place)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)place;
			Place place2 = new Place();
			object value;
			if (dictionary.TryGetValue("title", out value))
			{
				place2.title = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("address", out value2))
			{
				place2.address = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("latitude", out value3))
			{
				place2.latitude = (double)value3;
			}
			object value4;
			if (dictionary.TryGetValue("longitude", out value4))
			{
				place2.longitude = (double)value4;
			}
			object value5;
			if (dictionary.TryGetValue("country", out value5))
			{
				place2.country = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("icon", out value6))
			{
				place2.icon = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("type", out value7))
			{
				place2.type = (string)value;
			}
			object value8;
			if (dictionary.TryGetValue("group_id", out value8))
			{
				place2.group_id = (long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("group_photo", out value9))
			{
				place2.group_photo = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("checkins", out value10))
			{
				place2.checkins = (int)(long)value10;
			}
			object value11;
			if (dictionary.TryGetValue("updated", out value11))
			{
				place2.updated = (long)value11;
			}
			return place2;
		}
	}
}
