public interface IGameState : IState
{
	void OnReset();
}
