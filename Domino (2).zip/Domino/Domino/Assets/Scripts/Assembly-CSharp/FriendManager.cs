using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using com.playGenesis.VkUnityPlugin;

public class FriendManager : MonoBehaviour
{
	public Text t;

	public Image i;

	public Sprite noPhoto;

	public static List<VKFriedImage> fImages = new List<VKFriedImage>();

	private VKUser _friend;

	public VKUser friend
	{
		get
		{
			return _friend;
		}
		set
		{
			if (value == null)
			{
				base.gameObject.SetActive(false);
				return;
			}
			_friend = value;
			base.gameObject.SetActive(true);
			t.text = _friend.first_name + " " + _friend.last_name;
			GetImageFromCacheOrDownload(value.id);
		}
	}

	private void GetImageFromCacheOrDownload(long id)
	{
		VKFriedImage vKFriedImage = fImages.Find((VKFriedImage i) => i.VKUserId == id);
		if (vKFriedImage != null && vKFriedImage.Img != null)
		{
			setUpImage(vKFriedImage.Img);
			return;
		}
		if (!string.IsNullOrEmpty(friend.photo_200))
		{
			DownloadFriendImage(friend.photo_200, friend.id);
			return;
		}
		i.sprite = noPhoto;
		fImages.Add(new VKFriedImage
		{
			VKUserId = id,
			Img = null
		});
	}

	private void DownloadFriendImage(string url, long id)
	{
		Action<DownloadRequest> onFinished = delegate(DownloadRequest d)
		{
			long num = (long)d.CustomData[0];
			if (d.DownloadResult.error == null && friend.id == num)
			{
				setUpImage(d.DownloadResult.texture);
				UnityEngine.Object.Destroy(d.DownloadResult.texture);
				fImages.Add(new VKFriedImage
				{
					VKUserId = num,
					Img = i.sprite.texture
				});
			}
		};
		DownloadRequest downloadRequest = new DownloadRequest();
		downloadRequest.url = url;
		downloadRequest.onFinished = onFinished;
		downloadRequest.CustomData = new object[1] { id };
		DownloadRequest d2 = downloadRequest;
		VkApi.Downloader.download(d2);
	}

	public void setUpImage(byte[] photo)
	{
		Texture2D texture2D = new Texture2D(200, 200);
		texture2D.LoadImage(photo);
		i.sprite = Sprite.Create(texture2D, new Rect(0f, 0f, 200f, 200f), new Vector2(0.5f, 0.5f));
		UnityEngine.Object.Destroy(texture2D);
	}

	public void setUpImage(Texture2D photo)
	{
		if (i.sprite != noPhoto)
		{
			UnityEngine.Object.DestroyObject(i.sprite);
		}
		i.sprite = Sprite.Create(photo, new Rect(0f, 0f, 200f, 200f), new Vector2(0.5f, 0.5f));
	}

	public virtual void Invite()
	{
		if (friend != null)
		{
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "apps.sendRequest?user_id=" + friend.id + "&text=hello_from_vk_plugin2&type=invite&name=sayhello";
			vKRequest.CallBackFunction = OnAppSendRequest;
			VKRequest httprequest = vKRequest;
			VkApi.VkApiInstance.Call(httprequest);
		}
	}

	public virtual void OnAppSendRequest(VKRequest r)
	{
		if (r.error != null)
		{
			GlobalErrorHandler.Instance.Notification.Notify(r);
		}
		else
		{
			Debug.Log(r.response);
		}
	}
}
