namespace com.playGenesis.VkUnityPlugin
{
	public class GetUploadServerResp
	{
		public string upload_url { get; set; }

		public int album_id { get; set; }

		public int user_id { get; set; }
	}
}
