public interface IState
{
	bool IsActive { get; set; }

	string GetName { get; }

	void OnInit();

	void OnEnter(string oldState, object args);

	void OnUpdate(float deltaTime);

	void OnExit(string newState);

	void OnInvite();

	void OnEscape();
}
