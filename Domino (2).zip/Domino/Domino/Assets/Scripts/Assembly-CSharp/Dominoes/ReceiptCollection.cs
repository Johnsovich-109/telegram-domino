using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Dominoes
{
	public class ReceiptCollection
	{
		private const string keyReceipts = "receipts";

		private const string keyTransactions = "receiptId_";

		private const string keyDefenition = "receiptDf_";

		private List<string> list;

		public int Count
		{
			get
			{
				return list.Count;
			}
		}

		public ReceiptCollection()
		{
			list = new List<string>();
			LoadReceipts();
		}

		public string GetReceipt(string transactionId)
		{
			return PlayerPrefs.GetString("receiptId_" + transactionId);
		}

		public string GetDefenition(string transactionId)
		{
			return PlayerPrefs.GetString("receiptDf_" + transactionId);
		}

		private void SetReceipt(string transactionId, string defenition)
		{
			PlayerPrefs.SetString("receiptId_" + transactionId, defenition);
		}

		private void SetDefenition(string transactionId, string defenition)
		{
			PlayerPrefs.SetString("receiptDf_" + transactionId, defenition);
		}

		public void Add(string transactionId, string receipt, string defenition)
		{
			list.Add(transactionId);
			SetReceipt(transactionId, receipt);
			SetDefenition(transactionId, defenition);
			SaveReceipts();
		}

		public bool ContainsId(string transactionId)
		{
			return list.Exists((string x) => x == transactionId);
		}

		public void Remove(string transactionId)
		{
			list.Remove(transactionId);
			PlayerPrefs.DeleteKey("receipts" + transactionId);
			PlayerPrefs.DeleteKey("receiptId_" + transactionId);
			PlayerPrefs.DeleteKey("receiptDf_" + transactionId);
			SaveReceipts();
		}

		public string PullID()
		{
			if (list.Count > 0)
			{
				return list[0];
			}
			return null;
		}

		private void LoadReceipts()
		{
			string @string = PlayerPrefs.GetString("receipts");
			list.Clear();
			if (@string.Length > 0)
			{
				list.AddRange(@string.Split('|'));
			}
		}

		private void SaveReceipts()
		{
			PlayerPrefs.SetString("receipts", ToString(list, "|"));
		}

		private string ToString(List<string> list, string separator)
		{
			if (list.Count == 0)
			{
				return string.Empty;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(list[0]);
			for (int i = 1; i < list.Count; i++)
			{
				stringBuilder.Append(separator + list[i]);
			}
			return stringBuilder.ToString();
		}
	}
}
