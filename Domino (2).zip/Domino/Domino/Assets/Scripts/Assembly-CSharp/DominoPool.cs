using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DominoPool : MonoBehaviour
{
	private const int capacityTile = 28;

	private const int capacityPoint = 150;

	private const int capacityPhantom = 4;

	public static DominoPool instance;

	public Rect sizeTile;

	public BoneView prototypeTile;

	public BonePoint prototypePoint;

	public BonePhantom prototypePhantom;

	private Transform parentTiles;

	private Transform parentPoints;

	private Transform parentPhantom;

	private List<BoneView> collectionTiles;

	private List<BonePoint> collectionPoints;

	private List<BonePhantom> collectionPhantom;

	private Stack<BoneView> unusedTiles;

	private Stack<BonePoint> unusedPoint;

	private Stack<BonePhantom> unusedPhantom;

	public void Revert()
	{
		if (collectionTiles.Count > unusedTiles.Count)
		{
			foreach (BoneView collectionTile in collectionTiles)
			{
				collectionTile.Hide();
				collectionTile.node.localRotation = Quaternion.identity;
				collectionTile.node.SetParent(parentTiles);
			}
			unusedTiles = new Stack<BoneView>(collectionTiles);
		}
		if (collectionPoints.Count > unusedPoint.Count)
		{
			foreach (BonePoint collectionPoint in collectionPoints)
			{
				collectionPoint.Revert();
				collectionPoint.node.SetParent(parentPoints);
			}
			unusedPoint = new Stack<BonePoint>(collectionPoints);
		}
		if (collectionPhantom.Count <= unusedPhantom.Count)
		{
			return;
		}
		foreach (BonePhantom item in collectionPhantom)
		{
			item.Revert();
			item.node.SetParent(parentPhantom);
		}
		unusedPhantom = new Stack<BonePhantom>(collectionPhantom);
	}

	public BoneView PullTile()
	{
		if (unusedTiles.Count == 0)
		{
			CreateTile();
		}
		return unusedTiles.Pop();
	}

	public BoneView[] PullTiles(int length)
	{
		while (unusedTiles.Count < length)
		{
			CreateTile();
		}
		BoneView[] array = new BoneView[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = unusedTiles.Pop();
		}
		return array;
	}

	public BonePoint PullPoint()
	{
		if (unusedPoint.Count == 0)
		{
			CreatePoint();
		}
		return unusedPoint.Pop();
	}

	public BonePoint[] PullPoint(int length)
	{
		while (unusedPoint.Count < length)
		{
			CreatePoint();
		}
		BonePoint[] array = new BonePoint[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = unusedPoint.Pop();
		}
		return array;
	}

	public BonePhantom PullPhantom()
	{
		if (unusedPhantom.Count == 0)
		{
			CreatePhantom();
		}
		return unusedPhantom.Pop();
	}

	public BonePhantom[] PullPhantom(int length)
	{
		while (unusedPhantom.Count < length)
		{
			CreatePhantom();
		}
		BonePhantom[] array = new BonePhantom[length];
		for (int i = 0; i < length; i++)
		{
			array[i] = unusedPhantom.Pop();
		}
		return array;
	}

	public void PushPoint(BonePoint point)
	{
		unusedPoint.Push(point);
		point.node.SetParent(parentPoints);
		point.IsShow = false;
	}

	public void PushPoint(IEnumerable<BonePoint> collection)
	{
		foreach (BonePoint item in collection)
		{
			PushPoint(item);
		}
	}

	public void PushPhantom(BonePhantom phantom)
	{
		unusedPhantom.Push(phantom);
		phantom.node.SetParent(parentPhantom);
		phantom.IsShow = false;
	}

	public void PushPhantom(IEnumerable<BonePhantom> collection)
	{
		foreach (BonePhantom item in collection)
		{
			PushPhantom(item);
		}
	}

	private void Awake()
	{
		instance = this;
		unusedTiles = new Stack<BoneView>(28);
		unusedPoint = new Stack<BonePoint>(150);
		unusedPhantom = new Stack<BonePhantom>(4);
		collectionTiles = new List<BoneView>(28);
		collectionPoints = new List<BonePoint>(150);
		collectionPhantom = new List<BonePhantom>(4);
	}

	private void Start()
	{
		prototypePoint.Init();
		prototypeTile.Init();
		prototypePhantom.Init();
		sizeTile = prototypeTile.nodeUI.rect;
		parentPoints = prototypePoint.transform.parent;
		parentTiles = prototypeTile.transform.parent;
		parentPhantom = prototypePhantom.transform.parent;
		collectionTiles.Add(prototypeTile);
		collectionPoints.Add(prototypePoint);
		collectionPhantom.Add(prototypePhantom);
		unusedTiles.Push(prototypeTile);
		unusedPoint.Push(prototypePoint);
		unusedPhantom.Push(prototypePhantom);
		StartCoroutine(AutoGenerationTile(28));
		StartCoroutine(AutoGenerationPoint(150));
	}

	private IEnumerator AutoGenerationTile(int capacity)
	{
		while (collectionTiles.Count < capacity)
		{
			CreateTile();
			yield return null;
		}
	}

	private IEnumerator AutoGenerationPoint(int capacity)
	{
		while (collectionPoints.Count < capacity)
		{
			CreatePoint();
			yield return null;
		}
	}

	private void CreateTile()
	{
		BoneView boneView = Object.Instantiate(prototypeTile);
		boneView.Init();
		boneView.node.SetParent(parentTiles);
		boneView.name = "Tile";
		boneView.Revert();
		collectionTiles.Add(boneView);
		unusedTiles.Push(boneView);
	}

	private void CreatePoint()
	{
		BonePoint bonePoint = Object.Instantiate(prototypePoint);
		bonePoint.Init();
		bonePoint.node.SetParent(parentPoints);
		bonePoint.name = "Point";
		bonePoint.Revert();
		collectionPoints.Add(bonePoint);
		unusedPoint.Push(bonePoint);
	}

	private void CreatePhantom()
	{
		BonePhantom bonePhantom = Object.Instantiate(prototypePhantom);
		bonePhantom.Init();
		bonePhantom.node.SetParent(parentPhantom);
		bonePhantom.name = "Phantom";
		bonePhantom.Revert();
		collectionPhantom.Add(bonePhantom);
		unusedPhantom.Push(bonePhantom);
	}
}
