using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteDownloader : MonoBehaviour
{
	private struct LoadItem
	{
		public string hash;

		public string url;

		public Action<Sprite> callback;

		public LoadItem(string hash, string url, Action<Sprite> callback)
		{
			this.hash = hash;
			this.url = url;
			this.callback = callback;
		}
	}

	public class Cache
	{
		public class CacheItem
		{
			public uint uid;

			public string name;

			public Sprite sprite;

			public CacheItem(uint uid, string name, Sprite sprite)
			{
				this.uid = uid;
				this.name = name;
				this.sprite = sprite;
			}

			public override string ToString()
			{
				return name + " " + uid;
			}
		}

		private uint uid;

		private List<CacheItem> items;

		private int maxSize;

		public Sprite this[string key]
		{
			get
			{
				CacheItem cacheItem = items.Find((CacheItem x) => x.name == key);
				if (cacheItem == null)
				{
					return null;
				}
				cacheItem.uid = ++uid;
				return cacheItem.sprite;
			}
			set
			{
				CacheItem cacheItem = items.Find((CacheItem x) => x.name == key);
				if (cacheItem != null)
				{
					cacheItem.sprite = value;
					cacheItem.uid = ++uid;
				}
				if (items.Count >= maxSize)
				{
					Remove();
				}
				items.Add(new CacheItem(++uid, key, value));
			}
		}

		public Cache(int maxSize)
		{
			this.maxSize = maxSize;
			items = new List<CacheItem>(maxSize);
		}

		private void Remove()
		{
			if (items.Count <= 0)
			{
				return;
			}
			int index = 0;
			CacheItem cacheItem = items[index];
			for (int i = 1; i < items.Count; i++)
			{
				if (items[i].uid < cacheItem.uid)
				{
					index = i;
					cacheItem = items[index];
				}
			}
			items.RemoveAt(index);
		}
	}

	public Sprite avatarDefault;

	public Sprite avatarJoin;

	public Sprite avatarDisconnect;

	public static SpriteDownloader instance;

	private static Queue<LoadItem> queueLoader = new Queue<LoadItem>();

	private static Cache cache;

	public static Sprite AvatarDefault
	{
		get
		{
			return instance.avatarDefault;
		}
	}

	public static Sprite AvatarJoin
	{
		get
		{
			return instance.avatarJoin;
		}
	}

	public static Sprite AvatarDisconnect
	{
		get
		{
			return instance.avatarDisconnect;
		}
	}

	public static bool GetAvatar(string avatarURL, Action<Sprite> callback)
	{
		string empty = string.Empty;
		Sprite sprite = cache[avatarURL];
		if (sprite != null && callback != null)
		{
			callback(sprite);
			return true;
		}
		LoadItem item = new LoadItem(empty, avatarURL, callback);
		queueLoader.Enqueue(item);
		return false;
	}

	public Sprite CreateSprite(Texture2D texture)
	{
		return Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f));
	}

	private void Awake()
	{
		instance = this;
		cache = new Cache(100);
	}

	private void Update()
	{
		if (queueLoader.Count > 0)
		{
			StartCoroutine(LoadAvatar(queueLoader.Dequeue()));
		}
	}

	private IEnumerator LoadAvatar(LoadItem loadItem)
	{
		WWW www = new WWW(loadItem.url);
		yield return www;
		Sprite sprite = null;
		if (www.error == null)
		{
			sprite = CreateSprite(www.texture);
			cache[loadItem.url] = sprite;
		}
		if (loadItem.callback != null)
		{
			loadItem.callback(sprite);
		}
	}
}
