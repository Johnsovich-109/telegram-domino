using System.Collections.Generic;

public class ResponseLeaderboard : ResponseBase
{
	public readonly string type;

	public readonly ResponseLeaderboardPlayer player;

	public readonly ResponseLeaderboardPlayer[] top;

	public readonly ResponseLeaderboardPlayer[] scores;

	public ResponseLeaderboard(Dictionary<string, object> dict)
		: base(dict)
	{
		object value;
		if (dict.TryGetValue("type", out value))
		{
			type = (string)value;
		}
		if (dict.TryGetValue("player", out value))
		{
			player = new ResponseLeaderboardPlayer(value as Dictionary<string, object>);
		}
		if (dict.TryGetValue("top", out value))
		{
			top = GetPlayersArray(value as List<object>);
		}
		if (dict.TryGetValue("scores", out value))
		{
			scores = GetPlayersArray(value as List<object>);
		}
	}

	private ResponseLeaderboardPlayer[] GetPlayersArray(List<object> list)
	{
		ResponseLeaderboardPlayer[] array = new ResponseLeaderboardPlayer[list.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = new ResponseLeaderboardPlayer(list[i] as Dictionary<string, object>);
		}
		return array;
	}
}
