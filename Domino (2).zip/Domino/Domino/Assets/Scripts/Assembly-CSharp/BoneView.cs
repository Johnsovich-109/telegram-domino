using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BoneView : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IEventSystemHandler
{
	private const int capacity = 8;

	private const float margin = 0.26f;

	private const float padding = 4.25f;

	[HideInInspector]
	public Transform node;

	[HideInInspector]
	public RectTransform nodeUI;

	public Image imageTile;

	public SmoothMover mover;

	public Button button;

	public CanvasScaler canvaScaler;

	public Sprite spriteBack;

	public Sprite spriteFore;

	internal int TestRotate;

	internal Vector3 TestPosition;

	internal Vector3 TestScale;

	private DominoPool pool;

	private Bone currentBone;

	private List<BonePoint> pointsCollection;

	internal int uID;

	private static Point[] points = new Point[9]
	{
		new Point(0, 0),
		new Point(1, 1),
		new Point(-1, -1),
		new Point(-1, 1),
		new Point(1, -1),
		new Point(-1, 0),
		new Point(1, 0),
		new Point(0, 1),
		new Point(0, -1)
	};

	private static int uidStatic;

	private static bool init;

	private static float deltaShift;

	private static Rect size;

	private static Vector3 bonePointA;

	private static Vector3 bonePointB;

	private bool isCanMoving;

	public Color colorNormal = Color.white;

	public Color colorBlackout = Color.gray;

	private bool _blackout;

	private int coroutineSwithColor;

	public Bone Bone
	{
		get
		{
			return currentBone;
		}
		set
		{
			currentBone = value;
			if (pointsCollection.Count > 0)
			{
				pool.PushPoint(PullInternal());
			}
			CreateSide(bonePointA, value.SideA);
			CreateSide(bonePointB, value.SideB);
		}
	}

	public int Id
	{
		get
		{
			return (currentBone != null) ? currentBone.Id : (-1);
		}
	}

	public bool ActiveSelf
	{
		get
		{
			return base.gameObject.activeSelf;
		}
		set
		{
			base.gameObject.SetActive(value);
		}
	}

	public bool Enabled
	{
		get
		{
			return button.enabled;
		}
		set
		{
			button.enabled = value;
		}
	}

	public bool Blackout
	{
		get
		{
			return _blackout;
		}
		set
		{
			if (_blackout != value)
			{
				_blackout = value;
				SetBlackout(value);
			}
		}
	}

	public bool IsCanMoving
	{
		get
		{
			return isCanMoving;
		}
		set
		{
			isCanMoving = value;
		}
	}

	public event Action<BoneView> OnMoveBegin;

	public event Action<BoneView> OnMoveEnd;

	public event Action<BoneView> OnClick;

	public void Init()
	{
		uID = ++uidStatic;
		node = base.transform;
		nodeUI = node as RectTransform;
		pool = DominoPool.instance;
		pointsCollection = new List<BonePoint>(8);
		button.onClick.AddListener(OnButtonClick);
		if (!init)
		{
			size = nodeUI.rect;
			bonePointA.y = size.height * 0.26f;
			bonePointB.y = size.height * -0.26f;
			deltaShift = size.width / 4.25f;
			init = true;
		}
	}

	public void Show(Bone bone)
	{
		imageTile.sprite = spriteFore;
		Bone = bone;
	}

	public void Hide()
	{
		currentBone = null;
		imageTile.sprite = spriteBack;
		pool.PushPoint(PullInternal());
	}

	public void Revert()
	{
		ActiveSelf = false;
		pool.PushPoint(PullInternal());
		currentBone = null;
	}

	public void PointNormalization()
	{
		foreach (BonePoint item in pointsCollection)
		{
			item.Normalization();
		}
	}

	private void CreateSide(Vector3 center, int value)
	{
		int num = value - value % 2;
		for (int i = ((value == num) ? 1 : 0); i <= num; i++)
		{
			BonePoint bonePoint = pool.PullPoint();
			PushInternal(bonePoint);
			bonePoint.node.localScale = Vector3.one;
			bonePoint.node.localPosition = new Vector3(center.x + (float)points[i].X * deltaShift, center.y + (float)points[i].Y * deltaShift);
		}
	}

	private void OnDestroy()
	{
		init = false;
	}

	private BonePoint PushInternal(BonePoint point)
	{
		pointsCollection.Add(point);
		point.node.SetParent(node);
		point.IsShow = true;
		return point;
	}

	private List<BonePoint> PullInternal()
	{
		List<BonePoint> result = pointsCollection;
		pointsCollection = new List<BonePoint>(8);
		return result;
	}

	public bool Equals(BoneView other)
	{
		return uID == other.uID;
	}

	private void SetBlackout(bool value)
	{
		Color colorTo = ((!value) ? colorNormal : colorBlackout);
		StartCoroutine(SwitchColor(colorTo, 0.2f));
	}

	private IEnumerator SwitchColor(Color colorTo, float timeout)
	{
		float counterTime = 0f;
		Color colorFrom = imageTile.color;
		int id = ++coroutineSwithColor;
		float num;
		do
		{
			yield return null;
			imageTile.color = Color.Lerp(colorFrom, colorTo, counterTime / timeout);
			counterTime = (num = counterTime + Time.deltaTime);
		}
		while (num < timeout && id == coroutineSwithColor);
	}

	internal void OnButtonClick()
	{
		if (isCanMoving)
		{
			GameSounds.Play(SoundType.Tile);
		}
		if (this.OnClick != null)
		{
			this.OnClick(this);
		}
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		if (isCanMoving && this.OnMoveBegin != null)
		{
			this.OnMoveBegin(this);
		}
	}

	public void OnDrag(PointerEventData eventData)
	{
		if (isCanMoving)
		{
			node.position = eventData.position;
		}
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		if (isCanMoving && this.OnMoveEnd != null)
		{
			this.OnMoveEnd(this);
		}
	}
}
