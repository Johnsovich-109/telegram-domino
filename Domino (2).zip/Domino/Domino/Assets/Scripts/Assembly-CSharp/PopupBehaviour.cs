using UnityEngine;

public class PopupBehaviour : GameBehaviour
{
	public SmoothMover mover;

	public Transform positionHideFrom;

	public Transform positionHideTo;

	public Transform positionShow;

	protected DisplayState currentState = DisplayState.Hide;

	public DisplayState State
	{
		get
		{
			return currentState;
		}
		protected set
		{
			currentState = value;
		}
	}

	public bool IsShow
	{
		get
		{
			return currentState == DisplayState.Show || currentState == DisplayState.Showing;
		}
	}

	public bool IsHide
	{
		get
		{
			return currentState == DisplayState.Hide || currentState == DisplayState.Hidding;
		}
	}

	public void Reset()
	{
		base.Node.localPosition = positionHideFrom.localPosition;
	}

	public virtual void Show()
	{
		if (IsHide)
		{
			mover.Stop();
			mover.Move(positionHideFrom.localPosition, positionShow.localPosition, 0.5f, ShowedInternal);
			currentState = DisplayState.Showing;
		}
	}

	public virtual void Hide()
	{
		if (IsShow)
		{
			if (currentState == DisplayState.Showing)
			{
				mover.Stop();
				mover.Move(positionHideTo.localPosition, 0.5f, HiddenInternal);
			}
			else
			{
				mover.Move(positionShow.localPosition, positionHideTo.localPosition, 0.5f, HiddenInternal);
			}
			currentState = DisplayState.Hidding;
		}
	}

	protected virtual void OnShowed()
	{
	}

	protected virtual void OnHidden()
	{
	}

	private void ShowedInternal()
	{
		currentState = DisplayState.Show;
		OnShowed();
	}

	private void HiddenInternal()
	{
		currentState = DisplayState.Hide;
		OnHidden();
	}
}
