public class LeaderboardPlayers : GameBehaviour
{
	public LeaderboardPlayerItem[] players;

	private string scoreLocalized;

	public void SetVisibility(bool enable)
	{
		LeaderboardPlayerItem[] array = players;
		foreach (LeaderboardPlayerItem leaderboardPlayerItem in array)
		{
			leaderboardPlayerItem.ActiveSelf = enable;
		}
	}

	public void SetData(ResponseLeaderboardPlayer[] topPlayers)
	{
		int i;
		for (i = 0; i < players.Length && i < topPlayers.Length; i++)
		{
			SetData(players[i], topPlayers[i]);
		}
		for (; i < players.Length; i++)
		{
			players[i].ActiveSelf = false;
		}
	}

	private void Start()
	{
		scoreLocalized = TextManager.GetString("Score") + ": ";
	}

	private void SetData(LeaderboardPlayerItem playerView, ResponseLeaderboardPlayer playerData)
	{
		string username = ((playerData.username.Length <= 0) ? "No name" : playerData.username);
		playerView.AvatarURL = playerData.avatar;
		playerView.Username = username;
		playerView.Place = playerData.rank.ToString("### ### ##0").Trim();
		playerView.Score = scoreLocalized + playerData.score.ToString("### ### ##0").Trim();
	}
}
