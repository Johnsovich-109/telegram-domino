namespace Dominoes
{
	public class FriendData
	{
		public string id;

		public string username;

		public string avatar;
	}
}
