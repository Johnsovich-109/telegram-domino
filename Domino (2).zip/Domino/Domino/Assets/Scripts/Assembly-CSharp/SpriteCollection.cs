using UnityEngine;

public class SpriteCollection : MonoBehaviour
{
	public Sprite[] spritesGameIcons;

	public Sprite[] spritesBetIcons;

	public static SpriteCollection instance;

	public static Sprite GetGameIcon(string spriteName)
	{
		if (instance == null)
		{
			return null;
		}
		return FindSprite(instance.spritesGameIcons, spriteName);
	}

	public static Sprite GetBetIcon(string spriteName)
	{
		if (instance == null)
		{
			return null;
		}
		return FindSprite(instance.spritesBetIcons, spriteName);
	}

	private static Sprite FindSprite(Sprite[] collection, string spriteName)
	{
		for (int i = 0; i < collection.Length; i++)
		{
			if (collection[i].name == spriteName)
			{
				return collection[i];
			}
		}
		return null;
	}

	private void Awake()
	{
		instance = this;
	}
}
