using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BalanceView : MonoBehaviour
{
	public Text textBalance;

	[Range(0.1f, 5f)]
	public float timeFlashing;

	public Color colorDefault;

	public Color colorFlashing;

	private int balance;

	public int Balance
	{
		get
		{
			return balance;
		}
		set
		{
			balance = value;
			textBalance.text = balance.ToString("### ### ##0").Trim();
		}
	}

	public void AddBalance(int balance)
	{
		Balance = balance;
		GameSounds.Play(SoundType.Scoring);
		StartCoroutine(Flashing());
	}

	private IEnumerator Flashing()
	{
		float delta = 1f;
		yield return null;
		while (true)
		{
			float num;
			delta = (num = delta - Time.deltaTime);
			if (!(num > 0f))
			{
				break;
			}
			textBalance.color = Color.Lerp(colorDefault, colorFlashing, delta);
			yield return null;
		}
		textBalance.color = colorDefault;
	}
}
