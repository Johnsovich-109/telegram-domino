public enum OSNotificationPermission
{
	NotDetermined = 0,
	Authorized = 1,
	Denied = 2
}
