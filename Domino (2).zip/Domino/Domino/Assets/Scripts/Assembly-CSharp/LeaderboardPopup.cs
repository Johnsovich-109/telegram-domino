public class LeaderboardPopup : PopupBehaviour
{
	private void Awake()
	{
	}

	private void Start()
	{
	}
}
