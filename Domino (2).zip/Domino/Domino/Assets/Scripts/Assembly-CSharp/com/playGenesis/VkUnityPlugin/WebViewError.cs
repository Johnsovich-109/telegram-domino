namespace com.playGenesis.VkUnityPlugin
{
	public class WebViewError
	{
		public WebViewErrorType ErrorType = WebViewErrorType.UknownError;

		public string FailedUrl { get; set; }

		public WebViewError(string url, string error)
		{
			FailedUrl = url;
			if (error.Contains("Canceled by user"))
			{
				ErrorType = WebViewErrorType.CanceledByUser;
			}
			else if (error.Contains("Network error"))
			{
				ErrorType = WebViewErrorType.NetworkError;
			}
		}
	}
}
