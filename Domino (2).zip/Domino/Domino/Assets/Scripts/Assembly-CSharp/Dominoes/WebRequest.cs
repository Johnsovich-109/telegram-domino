using System;
using System.Text;
using UnityEngine;

namespace Dominoes
{
	public class WebRequest
	{
		private string url;

		private string request;

		public WWW www;

		public Action<bool> callback;

		public string Url
		{
			get
			{
				return url;
			}
			set
			{
				url = value;
			}
		}

		public string Request
		{
			get
			{
				return request;
			}
			set
			{
				request = value;
			}
		}

		public WebRequest(string url, string request)
		{
			this.url = url;
			this.request = request;
		}

		public void Send()
		{
			byte[] bytes = Encoding.ASCII.GetBytes(Request);
			www = new WWW(Url, bytes);
		}
	}
}
