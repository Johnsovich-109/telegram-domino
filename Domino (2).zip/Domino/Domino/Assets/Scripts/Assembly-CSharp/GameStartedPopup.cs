using System;
using System.Collections;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class GameStartedPopup : PopupBehaviour
{
	public Text textTitle;

	public Text textMessage;

	public Text textButton;

	public Text textParamms;

	public Image imageIcon;

	public Button buttonLeave;

	private bool isPlaying;

	public string Game
	{
		get
		{
			return Title;
		}
		set
		{
			Title = TextManager.GetString(value).ToUpper();
			imageIcon.sprite = SpriteCollection.GetGameIcon(value);
			imageIcon.SetNativeSize();
		}
	}

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public string Message
	{
		get
		{
			return textMessage.text;
		}
		set
		{
			textMessage.text = value;
		}
	}

	public event Action<string> OnClick;

	public void Show(GameCurrent currentGame, bool isReady)
	{
		Game = currentGame.Name;
		textParamms.text = TextManager.GetString("Score") + ": " + currentGame.FinalScore + ", " + TextManager.GetString("Bet") + ": " + currentGame.Rate.ToString("### ##0");
		buttonLeave.interactable = true;
		if (!isReady)
		{
			isPlaying = false;
		}
		Message = TextManager.GetString("Wait");
		base.Show();
	}

	public void Play(float time, Action callback)
	{
		isPlaying = true;
		buttonLeave.interactable = true;
		StartCoroutine(Playing(time, callback));
	}

	public override void Hide()
	{
		isPlaying = false;
		buttonLeave.interactable = true;
		base.Hide();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		textButton.text = TextManager.GetString("Leave");
	}

	private IEnumerator Playing(float time, Action callback)
	{
		while (isPlaying)
		{
			float num;
			time = (num = time - Time.deltaTime);
			if (!(num > 0f))
			{
				break;
			}
			Message = string.Format(TextManager.GetString("GameWillStart"), Mathf.RoundToInt(time).ToString("0"));
			yield return null;
		}
		if (isPlaying)
		{
			Message = TextManager.GetString("Wait");
			if (callback != null)
			{
				callback();
			}
			buttonLeave.interactable = false;
		}
	}
}
