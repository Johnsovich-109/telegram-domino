using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class MainController : MonoBehaviour
{
	public MonoBehaviour[] controllersBehaviour;

	private Dictionary<string, IController> controllers;

	private IController activeController;

	public static MainController instance;

	public string startController;

	public string ActiveController
	{
		get
		{
			return activeController.GetName;
		}
	}

	public void ChangeActiveController(string nameNew, object args = null)
	{
		string getName = activeController.GetName;
		activeController.OnInactive(nameNew);
		activeController.IsActive = false;
		activeController = controllers[nameNew];
		activeController.IsActive = true;
		activeController.OnActive(getName, args);
	}

	public void Invite()
	{
		activeController.OnInvite();
	}

	private void Awake()
	{
		instance = this;
		controllers = new Dictionary<string, IController>();
		MonoBehaviour[] array = controllersBehaviour;
		foreach (MonoBehaviour monoBehaviour in array)
		{
			IController controller = monoBehaviour as IController;
			controllers.Add(controller.GetName, controller);
		}
	}

	private void Start()
	{
		DominoData.ScenrAwake();
		activeController = controllers[startController];
		activeController.OnActive(null, null);
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			activeController.OnEscape();
		}
		activeController.OnUpdate(Time.deltaTime);
	}

	private void OnDestroy()
	{
		DominoData.SceneDestroy();
	}
}
