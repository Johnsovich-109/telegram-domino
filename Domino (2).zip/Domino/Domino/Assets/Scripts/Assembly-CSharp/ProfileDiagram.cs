using UnityEngine;
using UnityEngine.UI;

public class ProfileDiagram : MonoBehaviour
{
	public Image imageDiagram;

	public TextValuePair pairWins;

	public TextValuePair pairLoss;

	public Text textPercent;

	private float internalPercent;

	public float Percent
	{
		get
		{
			return internalPercent;
		}
		set
		{
			internalPercent = value;
			textPercent.text = (int)(100f * value) + "%";
			imageDiagram.fillAmount = value;
		}
	}

	public void Set(int wins, int loss)
	{
		if (wins + loss > 0)
		{
			Percent = (float)wins / (float)(wins + loss);
		}
		else
		{
			Percent = 0f;
		}
		pairWins.Value = wins.ToString();
		pairLoss.Value = loss.ToString();
	}

	private void Start()
	{
		pairWins.Title = TextManager.GetString("Wins");
		pairLoss.Title = TextManager.GetString("Losses");
		Set(0, 0);
	}
}
