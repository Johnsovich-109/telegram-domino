using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPushSettings
	{
		public int disabled_until { get; set; }

		public int sound { get; set; }

		public static VKPushSettings Deserialize(object settings)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)settings;
			VKPushSettings vKPushSettings = new VKPushSettings();
			object value;
			if (dictionary.TryGetValue("disabled_until", out value))
			{
				vKPushSettings.disabled_until = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("sound", out value2))
			{
				vKPushSettings.sound = (int)(long)value2;
			}
			return vKPushSettings;
		}
	}
}
