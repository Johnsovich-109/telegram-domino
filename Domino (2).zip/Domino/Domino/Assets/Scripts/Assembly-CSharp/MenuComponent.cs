using System;

public class MenuComponent : GameBehaviour
{
	public static MenuComponent instance;

	public event Action OnMenuShow;

	public void ButtonClickMenu()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnMenuShow != null)
		{
			this.OnMenuShow();
		}
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
	}
}
