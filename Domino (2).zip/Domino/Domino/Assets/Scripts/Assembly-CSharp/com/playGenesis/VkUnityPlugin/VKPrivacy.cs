using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPrivacy
	{
		public string type { get; set; }

		public List<long> users { get; set; }

		public List<long> lists { get; set; }

		public List<long> except_lists { get; set; }

		public List<long> except_users { get; set; }

		public static VKPrivacy Deserialize(object Privacy)
		{
			VKPrivacy vKPrivacy = new VKPrivacy();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Privacy;
			object value;
			if (dictionary.TryGetValue("type", out value))
			{
				vKPrivacy.type = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("users", out value2))
			{
				vKPrivacy.users = new List<long>();
				foreach (object item in (List<object>)value2)
				{
					vKPrivacy.users.Add((long)item);
				}
			}
			object value3;
			if (dictionary.TryGetValue("lists", out value3))
			{
				vKPrivacy.lists = new List<long>();
				foreach (object item2 in (List<object>)value3)
				{
					vKPrivacy.lists.Add((long)item2);
				}
			}
			object value4;
			if (dictionary.TryGetValue("except_lists", out value4))
			{
				vKPrivacy.except_lists = new List<long>();
				foreach (object item3 in (List<object>)value4)
				{
					vKPrivacy.except_lists.Add((long)item3);
				}
			}
			object value5;
			if (dictionary.TryGetValue("except_users", out value5))
			{
				vKPrivacy.except_users = new List<long>();
				foreach (object item4 in (List<object>)value5)
				{
					vKPrivacy.except_users.Add((long)item4);
				}
			}
			return vKPrivacy;
		}
	}
}
