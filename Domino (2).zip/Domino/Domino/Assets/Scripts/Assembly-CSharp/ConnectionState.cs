public enum ConnectionState
{
	Disconnected = 0,
	Connecting = 1,
	Connected = 2,
	Disconnecting = 3,
	InitializingApplication = 4
}
