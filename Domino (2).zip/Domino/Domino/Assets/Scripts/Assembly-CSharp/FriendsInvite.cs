using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class FriendsInvite : PopupBehaviour
{
	public Text textSearch;

	public Text textInputField;

	public Text textTitle;

	public InputField inputField;

	public List<FriendItemView> listFriends;

	public Transform loader;

	public int viewLimit = 15;

	private bool activeLoader;

	private float deltaTimeLoader = 0.1f;

	private float counterTime;

	private VKFriendsList friendsList;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool ActiveLoader
	{
		get
		{
			return activeLoader;
		}
		set
		{
			activeLoader = value;
			loader.gameObject.SetActive(value);
		}
	}

	public event Action<string> OnClick;

	public event Action<UserProfile> OnFriendClick;

	public void ChangeInputField()
	{
		string findText = inputField.text;
		VKFriendsList vKFriendsList = new VKFriendsList(friendsList.Where((UserProfile x) => x.username.IndexOf(findText, StringComparison.OrdinalIgnoreCase) > -1));
		RefreshData(vKFriendsList);
	}

	public void ButtonClick(string message)
	{
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	public override void Show()
	{
		base.Show();
	}

	public void SetFriends(VKFriendsList friendsList)
	{
		this.friendsList = friendsList;
		if (friendsList == null)
		{
			HidingData();
		}
		else
		{
			RefreshData(friendsList);
		}
	}

	private void HidingData()
	{
		for (int i = 0; i < listFriends.Count; i++)
		{
			listFriends[i].Set(null);
		}
	}

	private void RefreshData(VKFriendsList friendsList)
	{
		int num = ((friendsList.Count <= viewLimit) ? friendsList.Count : viewLimit);
		AlignList(num);
		for (int i = 0; i < num; i++)
		{
			listFriends[i].Set(friendsList[i]);
		}
		for (int j = num; j < listFriends.Count; j++)
		{
			listFriends[j].Set(null);
		}
	}

	private void AlignList(int count)
	{
		if (listFriends.Count == 0)
		{
			throw new Exception("The list friends was not initialized");
		}
		while (listFriends.Count < count)
		{
			CreateFriendItem(listFriends[0]);
		}
		while (count < listFriends.Count && listFriends.Count > viewLimit)
		{
			RemoveFriendItem();
		}
	}

	private void CreateFriendItem(FriendItemView prototype)
	{
		FriendItemView friendItemView = UnityEngine.Object.Instantiate(prototype);
		friendItemView.transform.SetParent(prototype.transform.parent);
		friendItemView.transform.localScale = prototype.transform.localScale;
		friendItemView.OnClick += Friend_OnClick;
		listFriends.Add(friendItemView);
	}

	private void RemoveFriendItem()
	{
		if (listFriends.Count > 0)
		{
			FriendItemView friendItemView = listFriends[0];
			listFriends.RemoveAt(0);
			UnityEngine.Object.DestroyObject(friendItemView.gameObject);
			return;
		}
		throw new Exception("The list of objects is empty");
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		textSearch.text = TextManager.GetString("Search") + ":";
		textInputField.text = TextManager.GetString("TypeInName") + "...";
		foreach (FriendItemView listFriend in listFriends)
		{
			listFriend.OnClick += Friend_OnClick;
		}
	}

	private void Update()
	{
		if (ActiveLoader && (counterTime += Time.deltaTime) > deltaTimeLoader)
		{
			counterTime -= deltaTimeLoader;
			loader.Rotate(0f, 0f, -43f);
		}
	}

	private void Friend_OnClick(UserProfile friendData)
	{
		if (this.OnFriendClick != null)
		{
			this.OnFriendClick(friendData);
		}
	}
}
