using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ChooseRateItem : MonoBehaviour
{
	public Text textTitle;

	public Text textRate;

	public Text textScore;

	private int internalRate;

	private int internalScore;

	private BetItem currentBet;

	public Image imageIcon;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public int Bet
	{
		get
		{
			return internalRate;
		}
		set
		{
			internalRate = 0;
			textRate.text = TextManager.GetString("Bet") + ": " + value;
		}
	}

	public int Score
	{
		get
		{
			return internalScore;
		}
		set
		{
			internalScore = 0;
			textScore.text = TextManager.GetString("Score") + ": " + value;
		}
	}

	public event Action<BetItem> OnChoice;

	public void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnChoice != null)
		{
			this.OnChoice(currentBet);
		}
	}

	private string ToString(int value)
	{
		if ((double)value >= 1000000.0)
		{
			return (double)value / 1000000.0 + "M";
		}
		if ((double)value >= 1000.0)
		{
			return (double)value / 1000.0 + "k";
		}
		return value.ToString();
	}

	public void Set(BetItem item)
	{
		currentBet = item;
		Bet = item.Bet;
		Score = item.Score;
		Title = TextManager.GetString("Bet_" + item.Title);
		imageIcon.sprite = SpriteCollection.GetBetIcon(item.Title);
	}
}
