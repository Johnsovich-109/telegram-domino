using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Dominoes
{
	public static class Tools
	{
		private static char[] usernameSeparator = new char[1] { ' ' };

		public static IEnumerator Pause(int countFrame, Action callback)
		{
			while (countFrame-- > 0)
			{
				yield return null;
			}
			if (callback != null)
			{
				callback();
			}
		}

		public static IEnumerator Pause(float time, Action callback)
		{
			yield return new WaitForSeconds(time);
			if (callback != null)
			{
				callback();
			}
		}

		public static string Username(string value)
		{
			if (value == null || value.Length == 0)
			{
				return value;
			}
			int num = value.IndexOf(' ');
			if (num > -1)
			{
				string[] array = value.Split(usernameSeparator, StringSplitOptions.RemoveEmptyEntries);
				if (array.Length > 1)
				{
					return array[0] + ((array[1].Length <= 0) ? string.Empty : (" " + array[1][0] + "."));
				}
				return value;
			}
			return value;
		}

		public static string Username(string value, int limit)
		{
			if (value == null || value.Length == 0 || value.Length <= limit)
			{
				return value;
			}
			int num = value.IndexOf(' ');
			if (num > -1)
			{
				return value.Substring(0, num);
			}
			if (limit > 5)
			{
				return value.Substring(0, limit - 2) + "...";
			}
			return value.Substring(0, limit);
		}

		public static IEnumerator ChangeColor(Image image, Color from, Color to, float timeout, Action callback = null)
		{
			float state = 0f - Time.deltaTime;
			while (state < timeout)
			{
				image.color = Color.Lerp(from, to, state / timeout);
				state += Time.deltaTime;
				yield return null;
			}
			if (callback != null)
			{
				callback();
			}
		}

		public static IEnumerator ChangeColor(Text text, Color from, Color to, float timeout, Action callback = null)
		{
			float state = 0f - Time.deltaTime;
			while (state < timeout)
			{
				text.color = Color.Lerp(from, to, state / timeout);
				state += Time.deltaTime;
				yield return null;
			}
			if (callback != null)
			{
				callback();
			}
		}
	}
}
