public enum CloudRegionCode
{
	eu = 0,
	us = 1,
	asia = 2,
	jp = 3,
	au = 5,
	usw = 6,
	sa = 7,
	cae = 8,
	kr = 9,
	@in = 10,
	none = 4
}
