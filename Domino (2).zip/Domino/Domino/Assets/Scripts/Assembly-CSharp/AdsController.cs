using System;
using UnityEngine;//using UnityEngine.Advertisements;

public class AdsController : MonoBehaviour
{
	public AdmobController adMobController;

	public UnityAdsController unityAdsController;

	public static AdsController instance;

	

	public void ShowInterstitial()
	{
		adMobController.Show();
	}

	

	private void Awake()
	{
		instance = this;
	}
}
