using UnityEngine.UI;

public class TextValuePair : GameBehaviour
{
	public Text textTitle;

	public Text textValue;

	public string Value
	{
		get
		{
			return textValue.text;
		}
		set
		{
			textValue.text = value;
		}
	}

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}
}
