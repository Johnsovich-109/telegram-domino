namespace Dominoes
{
	public class Bone
	{
		public readonly int Id;

		public readonly int SideA;

		public readonly int SideB;

		public readonly int Value;

		public readonly bool IsDouble;

		public int Sleeve;

		public Bone(Bone prototupe)
			: this(prototupe.SideA, prototupe.SideB, prototupe.Id)
		{
		}

		public Bone(int sideA, int sideB, int id)
		{
			SideA = sideA;
			SideB = sideB;
			Id = id;
			Value = sideA + sideB;
			IsDouble = sideA == sideB;
		}

		public bool Equals(Bone other)
		{
			if (other == null)
			{
				return false;
			}
			return Id == other.Id;
		}

		public bool Pairing(int value)
		{
			return SideA == value || SideB == value;
		}

		public bool Pairing(Bone bone)
		{
			return bone.SideA == SideA || bone.SideA == SideB || bone.SideB == SideA || bone.SideB == SideB;
		}

		public bool Pairing(ListBone others)
		{
			foreach (Bone other in others)
			{
				if (Pairing(other))
				{
					return true;
				}
			}
			return false;
		}

		public override string ToString()
		{
			return "[" + SideA + ":" + SideB + "]";
		}
	}
}
