public static class EncryptionDataParameters
{
	public const byte Mode = 0;

	public const byte Secret1 = 1;

	public const byte Secret2 = 2;
}
