using System;

namespace GoogleMobileAds.Api
{
	public class CustomNativeEventArgs : EventArgs
	{
		public CustomNativeTemplateAd nativeAd { get; set; }
	}
}
