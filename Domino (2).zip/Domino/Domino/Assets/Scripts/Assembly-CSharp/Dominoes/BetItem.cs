namespace Dominoes
{
	public class BetItem
	{
		private int score;

		private string title;

		private int bet;

		public string Title
		{
			get
			{
				return title;
			}
			set
			{
				title = value;
			}
		}

		public int Bet
		{
			get
			{
				return bet;
			}
			set
			{
				bet = value;
			}
		}

		public int Score
		{
			get
			{
				return score;
			}
			set
			{
				score = value;
			}
		}

		public BetItem(string title, int score, int bet)
		{
			this.title = title;
			this.score = score;
			this.bet = bet;
		}
	}
}
