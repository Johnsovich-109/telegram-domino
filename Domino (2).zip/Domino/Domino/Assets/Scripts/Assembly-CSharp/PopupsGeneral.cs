public class PopupsGeneral : CurtainManager
{
	public static PopupsGeneral instance;

	public MessageConnectState messageConnect;

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		Reset();
	}
}
