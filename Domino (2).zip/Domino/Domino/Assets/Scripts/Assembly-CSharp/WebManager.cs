using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using MiniJSON;
using UnityEngine;

public class WebManager : MonoBehaviour
{
	public static WebManager instance;

	public static uint id;

	private string host = "http://dominoesweb.skillcap.net:3000";

	public string BuilingURL
	{
		get
		{
			return host + "/billing/dominoes/";
		}
	}

	public string LeaderboardURL
	{
		get
		{
			return host + "/lb/dominoes/";
		}
	}

	public string ReceiptURL
	{
		get
		{
			return host + "/store/receipt/dominoes/";
		}
	}

	public string InviteURL
	{
		get
		{
			return host + "/friends/dominoes/";
		}
	}

	public void Init(Action<ResponseInit> callback)
	{
		WebRequest request = new WebRequest(BuilingURL, GetInitRequest());
		request.callback = delegate(bool reault)
		{
			OnInitResponse(request, reault, callback);
		};
		Send(request);
	}

	public void Leaderboard(string typeGame, string command, Action<ResponseLeaderboard> callback)
	{
		WebRequest request = new WebRequest(LeaderboardURL, GetLeaderboardRequest(typeGame, command));
		request.callback = delegate(bool result)
		{
			OnLeaderboardResponse(request, result, callback);
		};
		Send(request);
	}

	public void Invite(string[] idsFriend, Action<ResponseBase> callback)
	{
		WebRequest request = new WebRequest(InviteURL, GetInviteRequest(idsFriend));
		request.callback = delegate(bool result)
		{
			OnBaseResponse(request, result, callback);
		};
		Send(request);
	}

	public void Purchase(string transactionID, string receipt, Action<ResponseReceipt> callback)
	{
		WebRequest request = new WebRequest(ReceiptURL, GetPurchaseRequest(transactionID, receipt));
		request.callback = delegate(bool result)
		{
			OnPurchaseResponse(request, result, callback);
		};
		Send(request);
	}

	public void Unbind(Action<ResponseUnbind> callback)
	{
		WebRequest request = new WebRequest(BuilingURL, GetRequest("unbind"));
		request.callback = delegate(bool result)
		{
			OnUnbindResponse(request, result, callback);
		};
		Send(request);
	}

	public void Bonus(Action<ResponseBonus> callback)
	{
		WebRequest request = new WebRequest(BuilingURL, GetRequest("get_bonus"));
		request.callback = delegate(bool result)
		{
			OnBonusResponse(request, result, callback);
		};
		Send(request);
	}

	public void Info(Action<ResponseInit> callback)
	{
		WebRequest request = new WebRequest(BuilingURL, GetRequest("get_info"));
		request.callback = delegate(bool result)
		{
			OnInitResponse(request, result, callback);
		};
		Send(request);
	}

	public void Statistic(StatisticItem data, Action<ResponseStatistic> callback)
	{
		WebRequest request = new WebRequest(LeaderboardURL, GetStatisticRequest(data));
		request.callback = delegate(bool result)
		{
			OnStatisticResponse(request, result, callback);
		};
		Send(request);
	}

	private string GetInitRequest()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", "init");
		dictionary.Add("uid", MainSettings.DeviceUID);
		dictionary.Add("username", DominoData.User.Name);
		dictionary.Add("acc_type", (int)DominoData.User.AuthType);
		dictionary.Add("acc_id", DominoData.User.AccountId);
		dictionary.Add("avatar", DominoData.User.Avatar);
		dictionary.Add("score", DominoData.Values.Score);
		dictionary.Add("onesignal", MainSettings.OneSignalUserId);
		dictionary.Add("version", MainSettings.BundleVersion);
		dictionary.Add("lang", "ru");
		Dictionary<string, object> obj = dictionary;
		return Json.Serialize(obj);
	}

	private string GetPurchaseRequest(string transactionID, string receipt)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", "receipt");
		dictionary.Add("uid", MainSettings.DeviceUID);
		dictionary.Add("game", "dominoes");
		dictionary.Add("store", "amz");
		dictionary.Add("transactionId", transactionID);
		dictionary.Add("receipt", (Json.Deserialize(receipt) as Dictionary<string, object>)["Payload"]);
		Dictionary<string, object> obj = dictionary;
		return Json.Serialize(obj);
	}

	private string GetInviteRequest(string[] idsFriend)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", "invite");
		dictionary.Add("uid", MainSettings.DeviceUID);
		dictionary.Add("type", (int)DominoData.User.AuthType);
		dictionary.Add("ids", idsFriend);
		Dictionary<string, object> obj = dictionary;
		return Json.Serialize(obj);
	}

	private string GetLeaderboardRequest(string typeGame, string command)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", command);
		dictionary.Add("uid", MainSettings.DeviceUID);
		dictionary.Add("type", typeGame);
		dictionary.Add("count", 5);
		Dictionary<string, object> obj = dictionary;
		return Json.Serialize(obj);
	}

	private string GetRequest(string command)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", command);
		dictionary.Add("uid", MainSettings.DeviceUID);
		Dictionary<string, object> obj = dictionary;
		return Json.Serialize(obj);
	}

	private string GetStatisticRequest(StatisticItem data)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add("games", data.start);
		dictionary.Add("win", data.win);
		dictionary.Add("ended", data.finish);
		Dictionary<string, object> obj = dictionary;
		dictionary = new Dictionary<string, object>();
		dictionary.Add("id", id++);
		dictionary.Add("cmd", "update_statistic");
		dictionary.Add("uid", MainSettings.DeviceUID);
		dictionary.Add("values", Json.Serialize(obj));
		Dictionary<string, object> obj2 = dictionary;
		return Json.Serialize(obj2);
	}

	private void Awake()
	{
		instance = this;
	}

	private void Send(WebRequest request)
	{
		StartCoroutine(WaitForRequest(request));
	}

	private IEnumerator WaitForRequest(WebRequest request)
	{
		float time = 0f;
		float value = 0f;
		float maxTime = 3f;
		request.Send();
		while (!request.www.isDone)
		{
			if (request.www.progress == value)
			{
				if (time > maxTime)
				{
					if (request.callback != null)
					{
						request.callback(false);
					}
					request.www.Dispose();
					yield break;
				}
				time += Time.deltaTime;
			}
			else
			{
				time = 0f;
			}
			value = request.www.progress;
			yield return null;
		}
		if (request.callback != null)
		{
			request.callback(true);
		}
	}

	private void OnInitResponse(WebRequest request, bool result, Action<ResponseInit> callback)
	{
		if (callback != null)
		{
			ResponseInit obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseInit(dict);
			}
			callback(obj);
		}
	}

	private void OnLeaderboardResponse(WebRequest request, bool result, Action<ResponseLeaderboard> callback)
	{
		if (callback != null)
		{
			ResponseLeaderboard obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseLeaderboard(dict);
			}
			callback(obj);
		}
	}

	private void OnPurchaseResponse(WebRequest request, bool result, Action<ResponseReceipt> callback)
	{
		if (callback != null)
		{
			ResponseReceipt obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseReceipt(dict);
			}
			callback(obj);
		}
	}

	private void OnUnbindResponse(WebRequest request, bool result, Action<ResponseUnbind> callback)
	{
		if (callback != null)
		{
			ResponseUnbind obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseUnbind(dict);
			}
			callback(obj);
		}
	}

	private void OnBaseResponse(WebRequest request, bool result, Action<ResponseBase> callback)
	{
		if (callback != null)
		{
			ResponseBase obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseBase(dict);
			}
			callback(obj);
		}
	}

	private void OnBonusResponse(WebRequest request, bool result, Action<ResponseBonus> callback)
	{
		if (callback != null)
		{
			ResponseBonus obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseBonus(dict);
			}
			callback(obj);
		}
	}

	private void OnStatisticResponse(WebRequest request, bool result, Action<ResponseStatistic> callback)
	{
		if (callback != null)
		{
			ResponseStatistic obj = null;
			if (result && request.www.text.Length > 0)
			{
				Dictionary<string, object> dict = Json.Deserialize(request.www.text) as Dictionary<string, object>;
				obj = new ResponseStatistic(dict);
			}
			callback(obj);
		}
	}
}
