using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKLink
	{
		public string url { get; set; }

		public string title { get; set; }

		public string description { get; set; }

		public string image_src { get; set; }

		public static VKLink Deserialize(object link)
		{
			VKLink vKLink = new VKLink();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)link;
			object value;
			if (dictionary.TryGetValue("url", out value))
			{
				vKLink.url = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("title", out value2))
			{
				vKLink.title = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("description", out value3))
			{
				vKLink.description = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("image_src", out value4))
			{
				vKLink.image_src = (string)value4;
			}
			return vKLink;
		}
	}
}
