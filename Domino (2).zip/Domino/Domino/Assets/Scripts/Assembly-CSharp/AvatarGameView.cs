using UnityEngine;
using UnityEngine.UI;

public class AvatarGameView : MonoBehaviour
{
	private enum ShowStates
	{
		None = 0,
		Show = 1,
		Joining = 2,
		Reconnected = 3
	}

	public Transform loader;

	public Image imageAvatar;

	public Image imageIcon;

	public Sprite spriteBack;

	public Vector3 sizeAvatar = new Vector2(86f, 86f);

	public float totalTimer = 0.1f;

	private ShowStates state;

	private Sprite currentSpriteAvatar;

	private float counterTime;

	private string avatarURL;

	private bool isLoaderShow;

	public string AvatarURL
	{
		get
		{
			return avatarURL;
		}
		set
		{
			if (avatarURL != value)
			{
				avatarURL = value;
				if (string.IsNullOrEmpty(value))
				{
					SetDefault();
				}
				else if (!SpriteDownloader.GetAvatar(value, HandleAvatarLoader))
				{
					SetDefault();
				}
			}
		}
	}

	private bool IsLoaderShow
	{
		get
		{
			return isLoaderShow;
		}
		set
		{
			isLoaderShow = value;
			if ((bool)loader)
			{
				loader.gameObject.SetActive(value);
			}
		}
	}

	public void ShowJoin()
	{
		state = ShowStates.Joining;
		SetIcon(SpriteDownloader.AvatarJoin);
		IsLoaderShow = true;
	}

	public void ShowAvatar()
	{
		state = ShowStates.Show;
		IsLoaderShow = false;
		if (currentSpriteAvatar == null)
		{
			SetIcon(SpriteDownloader.AvatarDefault);
		}
		else
		{
			SetAvatar(currentSpriteAvatar);
		}
	}

	public void ShowDisconnect()
	{
		state = ShowStates.Reconnected;
		SetIcon(SpriteDownloader.AvatarDisconnect);
		IsLoaderShow = true;
	}

	public void HideAvatar()
	{
		state = ShowStates.None;
		IsLoaderShow = false;
		avatarURL = string.Empty;
		currentSpriteAvatar = null;
	}

	private void SetIcon(Sprite sprite)
	{
		imageIcon.enabled = true;
		imageIcon.sprite = sprite;
		imageIcon.SetNativeSize();
		imageAvatar.sprite = spriteBack;
		imageAvatar.SetNativeSize();
	}

	private void SetAvatar(Sprite sprite)
	{
		imageIcon.enabled = false;
		imageAvatar.sprite = sprite;
		imageAvatar.rectTransform.sizeDelta = sizeAvatar;
	}

	private void SetDefault()
	{
		currentSpriteAvatar = null;
		if (state == ShowStates.Show)
		{
			ShowAvatar();
		}
	}

	private void Update()
	{
		if (isLoaderShow && (counterTime += Time.deltaTime) > totalTimer)
		{
			counterTime -= totalTimer;
			loader.Rotate(0f, 0f, -43f);
		}
	}

	private void HandleAvatarLoader(Sprite sprite)
	{
		currentSpriteAvatar = sprite;
		if (state == ShowStates.Show)
		{
			ShowAvatar();
		}
	}
}
