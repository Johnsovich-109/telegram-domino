using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

[ExecuteInEditMode]
public class ShopItemView : MonoBehaviour
{
	public Text textBaseSize;

	public Text textActualSize;

	public Text textPercent;

	public Text textPrice;

	public Button button;

	public GameObject checkImage;

	private ShopItemInfo itemInfo;

	public string BaseSize
	{
		get
		{
			return textBaseSize.text;
		}
		set
		{
			textBaseSize.text = value;
		}
	}

	public string ActualSize
	{
		get
		{
			return textActualSize.text;
		}
		set
		{
			textActualSize.text = value;
		}
	}

	public string Percent
	{
		get
		{
			return textPercent.text;
		}
		set
		{
			textPercent.text = value;
		}
	}

	public string Price
	{
		get
		{
			return textPrice.text;
		}
		set
		{
			textPrice.text = value;
		}
	}

	public bool Checked
	{
		get
		{
			return checkImage.activeSelf;
		}
		set
		{
			checkImage.SetActive(value);
		}
	}

	public string Name
	{
		get
		{
			return itemInfo.Name;
		}
	}

	public event Action<ShopItemInfo> OnClick;

	public void SetData(ShopItemInfo data)
	{
		itemInfo = data;
		BaseSize = ToStringCount(data.BaseSize);
		ActualSize = ToStringCount(data.Size);
		Percent = ToStringPercent(data.Percent);
		Price = ToStringPrice(data.Price);
	}

	private void Start()
	{
		button.onClick.AddListener(ButtonClick);
	}

	private void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(itemInfo);
		}
	}

	private string ToStringPrice(float price)
	{
		return "$ " + price.ToString("### ##0.00").Trim() + " USD";
	}

	private string ToStringPercent(int percent)
	{
		return percent + " %";
	}

	private string ToStringCount(int actualSize)
	{
		return actualSize.ToString("### ### ##0").Trim().Replace(' ', '.');
	}
}
