using System;
using Dominoes;
using UnityEngine.UI;

public class StartScreenCanvas : CanvasManager
{
	public static StartScreenCanvas instance;

	public Button buttonVK;

	public Button buttonFB;

	public Text textButtonVK;

	public Text textButtonFB;

	public Text textButtonGuest;

	public event Action<string> OnButtonClick;

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}

	public void Show(AuthType auth)
	{
		switch (auth)
		{
		case AuthType.Vkontakte:
			SetVkontakte();
			break;
		case AuthType.Facebook:
			SetFacebook();
			break;
		}
		textButtonGuest.text = TextManager.GetString("loginGuest");
		base.Show();
	}

	public override void Hide()
	{
		base.Hide();
	}

	private void SetFacebook()
	{
		buttonVK.gameObject.SetActive(false);
		textButtonFB.text = TextManager.GetString("loginFB");
	}

	private void SetVkontakte()
	{
		buttonFB.gameObject.SetActive(false);
		textButtonVK.text = TextManager.GetString("loginVK");
	}

	private void Awake()
	{
		instance = this;
	}
}
