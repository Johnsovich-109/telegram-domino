using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUserStatus
	{
		public long time { get; set; }

		public int platform { get; set; }

		public static VKUserStatus Deserialize(object UserStatus)
		{
			VKUserStatus vKUserStatus = new VKUserStatus();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)UserStatus;
			object value;
			if (dictionary.TryGetValue("time", out value))
			{
				vKUserStatus.time = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("platform", out value2))
			{
				vKUserStatus.platform = (int)(long)value2;
			}
			return vKUserStatus;
		}
	}
}
