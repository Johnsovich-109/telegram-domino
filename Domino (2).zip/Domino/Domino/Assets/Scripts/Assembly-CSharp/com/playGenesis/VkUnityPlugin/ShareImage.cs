namespace com.playGenesis.VkUnityPlugin
{
	public class ShareImage
	{
		public string imageName;

		public byte[] data;

		public ImageType imagetype;
	}
}
