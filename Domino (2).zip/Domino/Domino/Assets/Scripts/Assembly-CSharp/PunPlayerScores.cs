using UnityEngine;

public class PunPlayerScores : MonoBehaviour
{
	public const string PlayerScoreProp = "score";
}
