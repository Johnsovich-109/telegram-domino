using System;
using UnityEngine.UI;

public class LobbyCanvas : CanvasManager
{
	public static LobbyCanvas instance;

	public LobbyProfileView profileView;

	public LobbyBonusView bonusView;

	public Text[] textButtons;

	public event Action<string> OnButtonClick;

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		Reset();
		Text[] array = textButtons;
		foreach (Text text in array)
		{
			text.text = TextManager.GetString(text.text).ToUpper();
		}
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}
}
