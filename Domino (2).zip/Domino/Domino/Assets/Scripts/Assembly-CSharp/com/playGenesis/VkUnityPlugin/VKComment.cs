using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKComment
	{
		public long id { get; set; }

		public long from_id { get; set; }

		public long date { get; set; }

		private string text { get; set; }

		public long reply_to_user { get; set; }

		public long reply_to_comment { get; set; }

		public List<VKAttachment> attachments { get; set; }

		public static VKComment Deserialize(object Comment)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Comment;
			VKComment vKComment = new VKComment();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKComment.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("from_id", out value2))
			{
				vKComment.from_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("date", out value3))
			{
				vKComment.date = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("text", out value4))
			{
				vKComment.text = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("reply_to_user", out value5))
			{
				vKComment.reply_to_user = (long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("reply_to_comment", out value6))
			{
				vKComment.reply_to_comment = (long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("attachments", out value7))
			{
				List<object> list = (List<object>)value7;
				List<VKAttachment> list2 = new List<VKAttachment>();
				foreach (object item in list)
				{
					list2.Add(VKAttachment.Deserialize(item));
				}
				vKComment.attachments = list2;
			}
			return vKComment;
		}
	}
}
