using System.Collections.Generic;

public class VKVariable
{
	public string key { get; set; }

	public string value { get; set; }

	public static VKVariable Deserialize(object variable)
	{
		VKVariable vKVariable = new VKVariable();
		Dictionary<string, object> dictionary = (Dictionary<string, object>)variable;
		object obj;
		if (dictionary.TryGetValue("key", out obj))
		{
			vKVariable.key = (string)obj;
		}
		object obj2;
		if (dictionary.TryGetValue("value", out obj2))
		{
			vKVariable.value = (string)obj2;
		}
		return vKVariable;
	}
}
