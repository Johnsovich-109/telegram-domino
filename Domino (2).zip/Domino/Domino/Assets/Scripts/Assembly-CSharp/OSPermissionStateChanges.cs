public class OSPermissionStateChanges
{
	public OSPermissionState to;

	public OSPermissionState from;
}
