using System.Collections.Generic;

public class ResponseLeaderboardPlayer : ResponseBase
{
	public readonly string username;

	public readonly string avatar;

	public readonly int score;

	public readonly int rank;

	public readonly int exp;

	public ResponseLeaderboardPlayer(Dictionary<string, object> dict)
		: base(dict)
	{
		object value;
		if (dict.TryGetValue("username", out value))
		{
			username = (string)value;
		}
		if (dict.TryGetValue("avatar", out value))
		{
			avatar = (string)value;
		}
		if (dict.TryGetValue("score", out value))
		{
			score = (int)(long)value;
		}
		if (dict.TryGetValue("rank", out value))
		{
			rank = (int)(long)value;
		}
		if (dict.TryGetValue("exp", out value))
		{
			exp = (int)(long)value;
		}
	}
}
