using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPostSource
	{
		public string platform { get; set; }

		public string type { get; set; }

		public string data { get; set; }

		public static VKPostSource Deserialize(object in_data)
		{
			VKPostSource vKPostSource = new VKPostSource();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)in_data;
			object value;
			if (dictionary.TryGetValue("platform", out value))
			{
				vKPostSource.platform = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("type", out value2))
			{
				vKPostSource.type = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("data", out value3))
			{
				vKPostSource.data = (string)value3;
			}
			return vKPostSource;
		}
	}
}
