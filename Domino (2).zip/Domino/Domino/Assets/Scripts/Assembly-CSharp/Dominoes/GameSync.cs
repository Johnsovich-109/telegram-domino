using System;
using System.Text;
using ExitGames.Client.Photon;

namespace Dominoes
{
	public class GameSync
	{
		public int activePlayer;

		public int[] players;

		public int[] idsBone;

		public int[][] desk;

		public int heap;

		public int time;

		public int round;

		public int[] scoresGame;

		public int[] scoresRound;

		public int[] scoresWon;

		public int[] scoresMemory;

		public GameState state;

		public int[][] idsBoneByPlayers;

		private Hashtable hashtable;

		public bool IsRoundOver
		{
			get
			{
				return (state & GameState.RoundOver) > GameState.Start;
			}
		}

		public bool IsGameOver
		{
			get
			{
				return (state & GameState.GameOver) > GameState.Start;
			}
		}

		private object this[byte index]
		{
			get
			{
				return hashtable[index];
			}
		}

		public GameSync(Hashtable hashtable, Func<int, int> function)
		{
			this.hashtable = hashtable;
			activePlayer = (int)this[0];
			idsBone = (int[])this[1];
			players = (int[])this[2];
			desk = (int[][])this[3];
			heap = (int)this[4];
			time = (int)this[5];
			round = (int)this[6];
			scoresGame = (int[])this[7];
			scoresRound = (int[])this[8];
			scoresWon = (int[])this[9];
			scoresMemory = (int[])this[10];
			state = GetState((int)this[11]);
			if (IsRoundOver)
			{
				idsBoneByPlayers = (int[][])this[12];
			}
			TranslateIndexes(function);
		}

		private void TranslateIndexes(Func<int, int> translator)
		{
			activePlayer = translator(activePlayer);
			players = IndexTranslatorInArray(players, translator);
			scoresGame = IndexTranslatorInArray(scoresGame, translator);
			scoresRound = IndexTranslatorInArray(scoresRound, translator);
			scoresWon = IndexTranslatorInArray(scoresWon, translator);
			scoresMemory = IndexTranslatorInArray(scoresMemory, translator);
			if (IsRoundOver)
			{
				idsBoneByPlayers = IndexTranslatorInArray(idsBoneByPlayers, translator);
			}
		}

		private GameState GetState(int state)
		{
			switch (state)
			{
			case 0:
				return GameState.Play;
			case 2:
				return GameState.Play;
			case 3:
				return GameState.RoundOver;
			case 4:
				return GameState.Start;
			case 5:
				return (GameState)18;
			default:
				return GameState.Play;
			}
		}

		private int[] IndexTranslatorInArray(int[] array, Func<int, int> translator)
		{
			if (array == null || array.Length == 0)
			{
				return array;
			}
			int[] array2 = new int[array.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array2[translator(i + 1)] = array[i];
			}
			return array2;
		}

		private int[][] IndexTranslatorInArray(int[][] array, Func<int, int> translator)
		{
			int[][] array2 = new int[array.Length][];
			for (int i = 0; i < array.Length; i++)
			{
				array2[translator(i + 1)] = array[i];
			}
			return array2;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("Active id: \t" + activePlayer);
			stringBuilder.AppendLine("Heap: \t" + heap);
			stringBuilder.AppendLine("Time: \t" + time);
			stringBuilder.AppendLine("Round: \t" + round);
			stringBuilder.AppendLine("IdsBone: \t" + Utils.ToString(idsBone));
			stringBuilder.AppendLine("Players: \t" + Utils.ToString(players));
			stringBuilder.AppendLine("Desk: \n" + Utils.ToString(desk));
			return stringBuilder.ToString();
		}
	}
}
