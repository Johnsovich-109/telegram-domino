using System;
using System.Collections.Generic;
using System.Text;
using Dominoes;
using UnityEngine;

public class OneSignalController : GameBehaviour
{
	public MessagePopup messageView;

	public CurtainManager curtain;

	private RoomInvite roomInvite;

	private void Awake()
	{
		curtain.OnChangeView += Curtain_OnChangeView;
		curtain.ActiveSelf = false;
	}

	private void Start()
	{
		OneSignal.StartInit("95c9d6bb-3609-430c-98b5-a57afbb0af23", "461238476155").HandleNotificationOpened(HandleNotificationOpened).HandleNotificationReceived(HandleNotificationReceived)
			.InFocusDisplaying(OneSignal.OSInFocusDisplayOption.None)
			.Settings(new Dictionary<string, bool> { { "kOSSettingsAutoPrompt", false } })
			.EndInit();
		OneSignal.IdsAvailable(IdsAvailable);
		OneSignal.RegisterForPushNotifications();
		messageView.OnClick += Message_Click;
	}

	private void AcceptGame()
	{
		DominoData.RoomInvite = roomInvite;
		MainController.instance.Invite();
	}

	private void CancelGame()
	{
		DominoData.RoomInvite = null;
	}

	private void OnSetData(string message, Dictionary<string, object> additionalData, bool isActive)
	{
		Debug.Log("[" + DateTime.Now.TimeOfDay.ToString() + "]    *** *** *** " + message);
		foreach (KeyValuePair<string, object> additionalDatum in additionalData)
		{
			Debug.Log(additionalDatum.Key + " " + additionalDatum.Value);
		}
		if (additionalData.ContainsKey("md"))
		{
			InviteMode(additionalData, isActive);
		}
	}

	private void InviteMode(Dictionary<string, object> additionalData, bool isActive)
	{
		Debug.Log("InviteMode.IsActive: " + isActive + "\n" + ToString(additionalData));
		roomInvite = new RoomInvite(additionalData);
		Debug.Log("CorrectParse: " + roomInvite.correctParse);
		if (roomInvite.correctParse)
		{
			if (isActive)
			{
				string @string = TextManager.GetString(DominoData.Games[GamesCollection.GetTypeByNumber(roomInvite.Table)].Name);
				ShowMessage(string.Format(TextManager.GetString("InviteMessage"), roomInvite.Username, @string, roomInvite.Bet));
			}
			else
			{
				AcceptGame();
			}
		}
	}

	private void ShowMessage(string message)
	{
		messageView.Show(TextManager.GetString("TitleInviteMessage"), message);
		curtain.ActiveSelf = true;
		curtain.Show();
		Handheld.Vibrate();
	}

	private void Message_Click(string message)
	{
		switch (message)
		{
		case "accept":
			AcceptGame();
			break;
		case "escape":
		case "cancel":
			CancelGame();
			break;
		}
		curtain.Hide();
		messageView.Hide();
	}

	private void HandleNotificationOpened(OSNotificationOpenedResult result)
	{
		OSNotification notification = result.notification;
		Debug.Log("Invate from " + notification.payload.body + " " + true);
		Debug.Log("Display Type: " + notification.displayType);
		Debug.Log("Action: " + result.action.actionID);
		OnSetData(notification.payload.body, notification.payload.additionalData, true);
	}

	private void HandleNotificationReceived(OSNotification notification)
	{
		OnSetData(notification.payload.body, notification.payload.additionalData, true);
	}

	private void IdsAvailable(string userID, string pushToken)
	{
		Debug.Log("UserID:" + userID);
		Debug.Log("pushToken:" + pushToken);
		MainSettings.OneSignalUserId = userID;
	}

	private void Curtain_OnChangeView(DisplayState state)
	{
		if (state == DisplayState.Hide)
		{
			curtain.ActiveSelf = false;
		}
	}

	private string ToString(Dictionary<string, object> response)
	{
		if (response == null)
		{
			return "Data is null";
		}
		if (response.Count == 0)
		{
			return "Date is Empty";
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (KeyValuePair<string, object> item in response)
		{
			stringBuilder.AppendLine(item.Key + ": '" + item.Value.ToString() + "' [" + item.Value.GetType().Name + "] ");
		}
		return stringBuilder.ToString();
	}
}
