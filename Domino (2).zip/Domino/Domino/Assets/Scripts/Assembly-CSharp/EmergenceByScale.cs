using System.Collections;
using UnityEngine;

[ExecuteInEditMode]
public class EmergenceByScale : MonoBehaviour
{
	public float timeout = 1f;

	public float scaleShow = 1f;

	public float scaleHide = 1.1f;

	public float exponentiation = 0.5f;

	public GameObject callbackTarget;

	public string messageShowEnd = "EmergenceShowEnd";

	public string messageHideEnd = "EmergenceHideEnd";

	private Transform node;

	private float state;

	private float minStateValue;

	private float maxStateValue = 1f;

	private int idCoroutine;

	public float Timeout
	{
		get
		{
			return timeout;
		}
		set
		{
			timeout = value;
		}
	}

	public float MinStateValue
	{
		get
		{
			return minStateValue;
		}
		set
		{
			minStateValue = Mathf.Clamp(value, 0f, maxStateValue);
		}
	}

	public float MaxStateValue
	{
		get
		{
			return maxStateValue;
		}
		set
		{
			maxStateValue = Mathf.Clamp(value, minStateValue, 1f);
		}
	}

	public void Show()
	{
		idCoroutine++;
		state = maxStateValue;
		Vector3 a = Vector3.one * scaleHide;
		Vector3 b = Vector3.one * scaleShow;
		node.localScale = Vector3.Lerp(a, b, Mathf.Pow(state, exponentiation));
	}

	public void Hide()
	{
		idCoroutine++;
		state = minStateValue;
		Vector3 a = Vector3.one * scaleHide;
		Vector3 b = Vector3.one * scaleShow;
		node.localScale = Vector3.Lerp(a, b, Mathf.Pow(state, exponentiation));
	}

	public void EmergenceShow()
	{
		StopAllCoroutines();
		StartCoroutine(Showing());
	}

	public void EmergenceHide()
	{
		StopAllCoroutines();
		StartCoroutine(Hiding());
	}

	public void EmergenceReset()
	{
		StopAllCoroutines();
		Hide();
	}

	private void Awake()
	{
		node = base.transform;
	}

	private IEnumerator Showing()
	{
		int id = ++idCoroutine;
		Vector3 vectorHide = Vector3.one * scaleHide;
		Vector3 vectorShow = Vector3.one * scaleShow;
		while (id == idCoroutine && state < maxStateValue)
		{
			if ((state += Time.deltaTime / timeout) > maxStateValue)
			{
				state = maxStateValue;
			}
			node.localScale = Vector3.Lerp(vectorHide, vectorShow, Mathf.Pow(state, exponentiation));
			yield return null;
		}
		if (messageShowEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageShowEnd, id == idCoroutine);
		}
	}

	private IEnumerator Hiding()
	{
		int id = ++idCoroutine;
		Vector3 vectorHide = Vector3.one * scaleHide;
		Vector3 vectorShow = Vector3.one * scaleShow;
		while (id == idCoroutine && state > minStateValue)
		{
			if ((state -= Time.deltaTime / timeout) < minStateValue)
			{
				state = minStateValue;
			}
			node.localScale = Vector3.Lerp(vectorShow, vectorHide, 1f - Mathf.Pow(state, exponentiation));
			yield return null;
		}
		if (messageHideEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageHideEnd, id == idCoroutine);
		}
	}
}
