public struct Point
{
	public int X;

	public int Y;

	public static Point MaxValue
	{
		get
		{
			return new Point(int.MaxValue, int.MaxValue);
		}
	}

	public static Point MinValue
	{
		get
		{
			return new Point(int.MinValue, int.MinValue);
		}
	}

	public static Point Zero
	{
		get
		{
			return new Point(0, 0);
		}
	}

	public Point(int x, int y)
	{
		X = x;
		Y = y;
	}

	public bool Equals(Point point)
	{
		return X == point.X && Y == point.Y;
	}

	public override string ToString()
	{
		return string.Format("[Point {0} {1}]", X, Y);
	}

	public static Point operator +(Point a, Point b)
	{
		return new Point(a.X + b.X, a.Y + b.Y);
	}

	public static Point operator -(Point a, Point b)
	{
		return new Point(a.X - b.X, a.Y - b.Y);
	}

	public static Point operator /(Point a, int b)
	{
		return new Point(a.X / b, a.Y / b);
	}
}
