namespace Dominoes
{
	public class Player : ListBone
	{
		public readonly int Id;

		private PlayerScores scores;

		private string name;

		private string avatar;

		private int counterWin;

		private int counterFish;

		private bool skip;

		public bool IsLocal
		{
			get
			{
				return Id == 0;
			}
		}

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		public string Avatar
		{
			get
			{
				return avatar;
			}
			set
			{
				avatar = value;
			}
		}

		public PlayerScores Score
		{
			get
			{
				return scores;
			}
			set
			{
				scores = value;
			}
		}

		public bool IsEmpty
		{
			get
			{
				return base.Count == 0;
			}
		}

		public bool Skip
		{
			get
			{
				return skip;
			}
			set
			{
				skip = value;
			}
		}

		public int CounterWin
		{
			get
			{
				return counterWin;
			}
			set
			{
				counterWin = value;
			}
		}

		public int CounterFish
		{
			get
			{
				return counterFish;
			}
			set
			{
				counterFish = value;
			}
		}

		public Player(int playerId)
		{
			Id = playerId;
			name = TextManager.GetString("Player") + " " + playerId;
			avatar = string.Empty;
			scores = new PlayerScores(this);
		}

		public void NewRound()
		{
			Clear();
		}

		public void Sync(ListBone listBone)
		{
			Clear();
			Push(listBone);
		}

		public bool CheckAvailable(ListBone interfaced)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].Pairing(interfaced))
				{
					return true;
				}
			}
			return false;
		}
	}
}
