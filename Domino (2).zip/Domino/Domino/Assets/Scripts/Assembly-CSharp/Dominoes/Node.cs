namespace Dominoes
{
	public class Node
	{
		public Branch branch;

		public Bone bone;

		public int value;

		public Node(Bone bone)
			: this(null, bone, -1)
		{
		}

		public Node(Branch branch, Bone bone)
			: this(branch, bone, -1)
		{
		}

		public Node(Branch branch, Bone bone, int value)
		{
			this.branch = branch;
			this.bone = bone;
			this.value = value;
		}

		public bool Pairing(Bone bone)
		{
			return bone.Pairing(value);
		}

		public override string ToString()
		{
			return string.Concat(bone, " --> ", value);
		}

		internal void Play(Branch branch, Bone mBone)
		{
		}
	}
}
