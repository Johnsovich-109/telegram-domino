using System.Collections;
using UnityEngine;

[ExecuteInEditMode]
public class EmergenceByPosition : MonoBehaviour
{
	public float timeout = 1f;

	public float exponentiation = 1f;

	public Transform positionShow;

	public Transform positionHide;

	public GameObject callbackTarget;

	public string messageShowEnd = "EmergenceShowEnd";

	public string messageHideEnd = "EmergenceHideEnd";

	private float minStateValue;

	private float maxStateValue = 1f;

	private Transform node;

	private float state;

	private int idCoroutine;

	public float MinStateValue
	{
		get
		{
			return minStateValue;
		}
		set
		{
			minStateValue = Mathf.Clamp(value, 0f, maxStateValue);
		}
	}

	public float MaxStateValue
	{
		get
		{
			return maxStateValue;
		}
		set
		{
			maxStateValue = Mathf.Clamp(value, minStateValue, 1f);
		}
	}

	public float Timeout
	{
		get
		{
			return timeout;
		}
		set
		{
			timeout = value;
		}
	}

	public void Show()
	{
		idCoroutine++;
		state = maxStateValue;
		node.localPosition = Vector3.Lerp(positionHide.localPosition, positionShow.localPosition, Mathf.Pow(state, exponentiation));
	}

	public void Hide()
	{
		idCoroutine++;
		state = minStateValue;
		node.localPosition = Vector3.Lerp(positionHide.localPosition, positionShow.localPosition, Mathf.Pow(state, exponentiation));
	}

	public void EmergenceShow()
	{
		StopAllCoroutines();
		StartCoroutine(Showing());
	}

	public void EmergenceHide()
	{
		StopAllCoroutines();
		StartCoroutine(Hiding());
	}

	public void EmergenceReset()
	{
		StopAllCoroutines();
		Hide();
	}

	private void Awake()
	{
		node = base.transform;
	}

	private IEnumerator Showing()
	{
		Vector3 vectorShow = positionShow.localPosition;
		Vector3 vectorHide = positionHide.localPosition;
		int id = ++idCoroutine;
		while (id == idCoroutine && state < maxStateValue)
		{
			if ((state += Time.deltaTime / timeout) > maxStateValue)
			{
				state = maxStateValue;
			}
			node.localPosition = Vector3.Lerp(vectorHide, vectorShow, Mathf.Pow(state, exponentiation));
			yield return null;
		}
		if (messageShowEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageShowEnd, id == idCoroutine);
		}
	}

	private IEnumerator Hiding()
	{
		Vector3 vectorShow = positionShow.localPosition;
		Vector3 vectorHide = positionHide.localPosition;
		int id = ++idCoroutine;
		while (id == idCoroutine && state > minStateValue)
		{
			if ((state -= Time.deltaTime / timeout) < minStateValue)
			{
				state = minStateValue;
			}
			node.localPosition = Vector3.Lerp(vectorShow, vectorHide, 1f - Mathf.Pow(state, exponentiation));
			yield return null;
		}
		if (messageHideEnd.Length > 0)
		{
			(callbackTarget ?? base.gameObject).SendMessage(messageHideEnd, id == idCoroutine);
		}
	}
}
