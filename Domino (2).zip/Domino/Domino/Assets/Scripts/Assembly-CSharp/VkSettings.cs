using System;
using System.Collections.Generic;
using UnityEngine;
using com.playGenesis.VkUnityPlugin;

public class VkSettings : ScriptableObject
{
	public int VkAppId;

	public List<string> scope = new List<string>();

	public bool forceOAuth;

	public bool revoke;

	public string apiVersion;

	public bool notify;

	public bool friends;

	public bool photos;

	public bool audio;

	public bool video;

	public bool docs;

	public bool notes;

	public bool pages;

	public bool status;

	public bool offers;

	public bool questions;

	public bool wall;

	public bool groups;

	public bool messages;

	public bool notifications;

	public bool stats;

	public bool ads;

	public bool offline;

	public bool nohttps;

	private void Awake()
	{
		generateScope();
	}

	public void generateScope()
	{
		if (scope != null)
		{
			scope.Clear();
		}
		if (notify)
		{
			scope.Add("notify");
		}
		if (friends)
		{
			scope.Add("friends");
		}
		if (photos)
		{
			scope.Add("photos");
		}
		if (audio)
		{
			scope.Add("audio");
		}
		if (video)
		{
			scope.Add("video");
		}
		if (docs)
		{
			scope.Add("docs");
		}
		if (notes)
		{
			scope.Add("notes");
		}
		if (pages)
		{
			scope.Add("pages");
		}
		if (status)
		{
			scope.Add("status");
		}
		if (offers)
		{
			scope.Add("offers");
		}
		if (questions)
		{
			scope.Add("questions");
		}
		if (wall)
		{
			scope.Add("wall");
		}
		if (groups)
		{
			scope.Add("groups");
		}
		if (messages)
		{
			scope.Add("messages");
		}
		if (notifications)
		{
			scope.Add("notifications");
		}
		if (stats)
		{
			scope.Add("stats");
		}
		if (ads)
		{
			scope.Add("ads");
		}
		if (offline)
		{
			scope.Add("offline");
		}
		if (nohttps)
		{
			scope.Add("nohttps");
		}
	}

	public void ProcessAuthUrl()
	{
		if (string.IsNullOrEmpty(PlayerPrefs.GetString("auth_url", string.Empty)))
		{
			Debug.LogError("Please, enter auth url in VKSetting");
			Debug.Break();
			return;
		}
		Dictionary<string, string> dictionary = Utilities.ParseUrlParams(PlayerPrefs.GetString("auth_url", string.Empty));
		VkApi.CurrentToken.access_token = dictionary["access_token"];
		VkApi.CurrentToken.expires_in = int.Parse(dictionary["expires_in"]);
		VkApi.CurrentToken.tokenRecievedTime = DateTime.Now;
		VkApi.CurrentToken.user_id = dictionary["user_id"];
		VkApi.CurrentToken.expires_in = ((VkApi.CurrentToken.expires_in != 0) ? VkApi.CurrentToken.expires_in : 9999999);
		VkApi.CurrentToken.Save();
	}
}
