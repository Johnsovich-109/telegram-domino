using UnityEngine;

public class CanvasManager : CurtainManager
{
	public Canvas canvas;

	public override bool IsCanvasActive
	{
		get
		{
			return canvas.enabled;
		}
		set
		{
			canvas.enabled = value;
		}
	}

	public override void OnShowed()
	{
		base.IsCurtainShow = false;
	}
}
