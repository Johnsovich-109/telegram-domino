public enum ViewSynchronization
{
	Off = 0,
	ReliableDeltaCompressed = 1,
	Unreliable = 2,
	UnreliableOnChange = 3
}
