using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[AddComponentMenu("UI/ToJ Effects/Depth Effect", 2)]
[RequireComponent(typeof(Text))]
public class DepthEffect : BaseMeshEffect
{
	[SerializeField]
	private Color m_EffectColor = new Color(0f, 0f, 0f, 1f);

	[SerializeField]
	private Vector2 m_EffectDirectionAndDepth = new Vector2(-1f, 1f);

	[SerializeField]
	private Vector2 m_DepthPerspectiveStrength = new Vector2(0f, 0f);

	[SerializeField]
	private bool m_OnlyInitialCharactersGenerateDepth = true;

	[SerializeField]
	private bool m_UseGraphicAlpha = true;

	private Vector2 m_OverallTextSize = Vector2.zero;

	private Vector2 m_TopLeftPos = Vector2.zero;

	private Vector2 m_BottomRightPos = Vector2.zero;

	public Color effectColor
	{
		get
		{
			return m_EffectColor;
		}
		set
		{
			m_EffectColor = value;
			if (base.graphic != null)
			{
				base.graphic.SetVerticesDirty();
			}
		}
	}

	public Vector2 effectDirectionAndDepth
	{
		get
		{
			return m_EffectDirectionAndDepth;
		}
		set
		{
			if (!(m_EffectDirectionAndDepth == value))
			{
				m_EffectDirectionAndDepth = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}
	}

	public Vector2 depthPerspectiveStrength
	{
		get
		{
			return m_DepthPerspectiveStrength;
		}
		set
		{
			if (!(m_DepthPerspectiveStrength == value))
			{
				m_DepthPerspectiveStrength = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}
	}

	public bool onlyInitialCharactersGenerateDepth
	{
		get
		{
			return m_OnlyInitialCharactersGenerateDepth;
		}
		set
		{
			m_OnlyInitialCharactersGenerateDepth = value;
			if (base.graphic != null)
			{
				base.graphic.SetVerticesDirty();
			}
		}
	}

	public bool useGraphicAlpha
	{
		get
		{
			return m_UseGraphicAlpha;
		}
		set
		{
			m_UseGraphicAlpha = value;
			if (base.graphic != null)
			{
				base.graphic.SetVerticesDirty();
			}
		}
	}

	protected DepthEffect()
	{
	}

	protected void ApplyShadowZeroAlloc(List<UIVertex> verts, Color32 color, int start, int end, float x, float y, float factor)
	{
		for (int i = start; i < end; i++)
		{
			UIVertex uIVertex = verts[i];
			verts.Add(uIVertex);
			Vector3 position = uIVertex.position;
			position.x += x * factor;
			if (depthPerspectiveStrength.x != 0f)
			{
				position.x -= depthPerspectiveStrength.x * ((position.x - m_TopLeftPos.x) / m_OverallTextSize.x - 0.5f) * factor;
			}
			position.y += y * factor;
			if (depthPerspectiveStrength.y != 0f)
			{
				position.y += depthPerspectiveStrength.y * ((m_TopLeftPos.y - position.y) / m_OverallTextSize.y - 0.5f) * factor;
			}
			uIVertex.position = position;
			Color32 color2 = color;
			if (useGraphicAlpha)
			{
				color2.a = (byte)(color2.a * verts[i].color.a / 255);
			}
			uIVertex.color = color2;
			verts[i] = uIVertex;
		}
	}

	public override void ModifyMesh(VertexHelper vh)
	{
		if (!IsActive())
		{
			return;
		}
		List<UIVertex> list = new List<UIVertex>();
		vh.GetUIVertexStream(list);
		int count = list.Count;
		Text component = GetComponent<Text>();
		List<UIVertex> list2 = new List<UIVertex>();
		list2 = ((!m_OnlyInitialCharactersGenerateDepth) ? list : list.GetRange(list.Count - component.cachedTextGenerator.characterCountVisible * 6, component.cachedTextGenerator.characterCountVisible * 6));
		if (list2.Count == 0)
		{
			return;
		}
		if (depthPerspectiveStrength.x != 0f || depthPerspectiveStrength.y != 0f)
		{
			m_TopLeftPos = list2[0].position;
			m_BottomRightPos = list2[list2.Count - 1].position;
			for (int i = 0; i < list2.Count; i++)
			{
				if (list2[i].position.x < m_TopLeftPos.x)
				{
					m_TopLeftPos.x = list2[i].position.x;
				}
				if (list2[i].position.y > m_TopLeftPos.y)
				{
					m_TopLeftPos.y = list2[i].position.y;
				}
				if (list2[i].position.x > m_BottomRightPos.x)
				{
					m_BottomRightPos.x = list2[i].position.x;
				}
				if (list2[i].position.y < m_BottomRightPos.y)
				{
					m_BottomRightPos.y = list2[i].position.y;
				}
			}
			m_OverallTextSize = new Vector2(m_BottomRightPos.x - m_TopLeftPos.x, m_TopLeftPos.y - m_BottomRightPos.y);
		}
		int num = 0;
		int num2 = 0;
		num = num2;
		num2 = list2.Count;
		ApplyShadowZeroAlloc(list2, effectColor, num, list2.Count, effectDirectionAndDepth.x, effectDirectionAndDepth.y, 0.25f);
		num = num2;
		num2 = list2.Count;
		ApplyShadowZeroAlloc(list2, effectColor, num, list2.Count, effectDirectionAndDepth.x, effectDirectionAndDepth.y, 0.5f);
		num = num2;
		num2 = list2.Count;
		ApplyShadowZeroAlloc(list2, effectColor, num, list2.Count, effectDirectionAndDepth.x, effectDirectionAndDepth.y, 0.75f);
		num = num2;
		num2 = list2.Count;
		ApplyShadowZeroAlloc(list2, effectColor, num, list2.Count, effectDirectionAndDepth.x, effectDirectionAndDepth.y, 1f);
		if (onlyInitialCharactersGenerateDepth)
		{
			list2.RemoveRange(list2.Count - component.cachedTextGenerator.characterCountVisible * 6, component.cachedTextGenerator.characterCountVisible * 6);
			list2.AddRange(list);
		}
		if (component.material.shader == Shader.Find("Text Effects/Fancy Text"))
		{
			for (int j = 0; j < list2.Count - count; j++)
			{
				UIVertex value = list2[j];
				value.uv1 = new Vector2(0f, 0f);
				list2[j] = value;
			}
		}
		vh.Clear();
		vh.AddUIVertexTriangleStream(list2);
	}
}
