namespace Dominoes
{
	public class GameCurrent
	{
		public GameInfo gameInfo;

		private int finalScore;

		private int rate;

		private int countPlayers;

		private bool isFriends;

		public string Name
		{
			get
			{
				return gameInfo.Name;
			}
		}

		public int CountPlayers
		{
			get
			{
				return countPlayers;
			}
			set
			{
				countPlayers = value;
			}
		}

		public bool IsFriends
		{
			get
			{
				return isFriends;
			}
			set
			{
				isFriends = value;
			}
		}

		public int Rate
		{
			get
			{
				return rate;
			}
			set
			{
				rate = value;
			}
		}

		public int FinalScore
		{
			get
			{
				return finalScore;
			}
			set
			{
				finalScore = value;
			}
		}

		public GameCurrent(GameInfo gameInfo)
			: this(gameInfo, 2, 10, false)
		{
		}

		public GameCurrent(GameInfo gameInfo, bool friends)
			: this(gameInfo, 2, 10, friends)
		{
		}

		public GameCurrent(GameInfo gameInfo, int countPlayers, int rate, bool isFriends)
		{
			this.gameInfo = gameInfo;
			this.countPlayers = countPlayers;
			this.rate = rate;
			this.isFriends = isFriends;
		}

		public override string ToString()
		{
			return string.Format("Name: {0}; Count: {1}; ", Name, countPlayers);
		}
	}
}
