namespace ExitGames.Client.GUI
{
	public enum GizmoType
	{
		WireSphere = 0,
		Sphere = 1,
		WireCube = 2,
		Cube = 3
	}
}
