using UnityEngine;

namespace Dominoes
{
	public class Statistics
	{
		public const string keyForSingle = "StatisticsSaveSimpleGames";

		public const string keyForOnline = "StatisticsSaveOnlineGames";

		private StatisticItem single;

		private StatisticItem online;

		public StatisticItem Single
		{
			get
			{
				return single;
			}
			set
			{
				single = value;
			}
		}

		public StatisticItem Online
		{
			get
			{
				return online;
			}
			set
			{
				online = value;
			}
		}

		public Statistics()
		{
			single = new StatisticItem();
			online = new StatisticItem();
		}

		public void OnlineStart(GameCurrent game)
		{
			online.start++;
		}

		public void OnlineFinish(GameCurrent game, bool gameWin)
		{
			if (gameWin)
			{
				online.win++;
			}
			else
			{
				online.loss++;
			}
			online.finish++;
		}

		public void SingleSurrender(GameCurrent gameCurrent)
		{
		}

		public void SingleStart(GameCurrent game)
		{
			single.start++;
		}

		public void SingleFinish(GameCurrent game, bool gameWin)
		{
			if (gameWin)
			{
				single.win++;
			}
			else
			{
				single.loss++;
			}
			single.finish++;
		}

		public void Load()
		{
			single.Parse(PlayerPrefs.GetString("StatisticsSaveSimpleGames", string.Empty));
			online.Parse(PlayerPrefs.GetString("StatisticsSaveOnlineGames", string.Empty));
		}

		public void Save()
		{
			PlayerPrefs.SetString("StatisticsSaveSimpleGames", single.ToString());
			PlayerPrefs.SetString("StatisticsSaveOnlineGames", online.ToString());
		}
	}
}
