public class SystemCanvas : CanvasManager
{
	public static SystemCanvas instance;

	public override void Show()
	{
		IsCanvasActive = true;
	}

	public override void Hide()
	{
		IsCanvasActive = false;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
	}
}
