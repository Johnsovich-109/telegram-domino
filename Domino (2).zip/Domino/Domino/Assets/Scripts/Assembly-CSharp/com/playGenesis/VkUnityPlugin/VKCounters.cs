using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKCounters
	{
		public int albums { get; set; }

		public int videos { get; set; }

		public int audios { get; set; }

		public int notes { get; set; }

		public int groups { get; set; }

		public int photos { get; set; }

		public int friends { get; set; }

		public int online_friends { get; set; }

		public int mutual_friends { get; set; }

		public int user_videos { get; set; }

		public int user_photos { get; set; }

		public int followers { get; set; }

		public int subscriptions { get; set; }

		public int topics { get; set; }

		public int docs { get; set; }

		public int pages { get; set; }

		public static VKCounters Deserialize(object Countries)
		{
			VKCounters vKCounters = new VKCounters();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Countries;
			object value;
			if (dictionary.TryGetValue("albums", out value))
			{
				vKCounters.albums = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("videos", out value2))
			{
				vKCounters.videos = (int)(long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("audios", out value3))
			{
				vKCounters.audios = (int)(long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("notes", out value4))
			{
				vKCounters.notes = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("groups", out value5))
			{
				vKCounters.groups = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("photos", out value6))
			{
				vKCounters.photos = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("friends", out value7))
			{
				vKCounters.friends = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("online_friends", out value8))
			{
				vKCounters.online_friends = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("mutual_friends", out value9))
			{
				vKCounters.mutual_friends = (int)(long)value9;
			}
			object value10;
			if (dictionary.TryGetValue("user_videos", out value10))
			{
				vKCounters.user_videos = (int)(long)value10;
			}
			object value11;
			if (dictionary.TryGetValue("user_photos", out value11))
			{
				vKCounters.user_photos = (int)(long)value11;
			}
			object value12;
			if (dictionary.TryGetValue("followers", out value12))
			{
				vKCounters.followers = (int)(long)value12;
			}
			object value13;
			if (dictionary.TryGetValue("subscriptions", out value13))
			{
				vKCounters.subscriptions = (int)(long)value13;
			}
			object value14;
			if (dictionary.TryGetValue("topics", out value14))
			{
				vKCounters.topics = (int)(long)value14;
			}
			object value15;
			if (dictionary.TryGetValue("docs", out value15))
			{
				vKCounters.docs = (int)(long)value15;
			}
			object value16;
			if (dictionary.TryGetValue("pages", out value16))
			{
				vKCounters.pages = (int)(long)value16;
			}
			return vKCounters;
		}
	}
}
