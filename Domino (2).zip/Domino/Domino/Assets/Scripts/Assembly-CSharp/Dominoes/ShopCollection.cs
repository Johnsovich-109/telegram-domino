using System.Collections.Generic;
using System.Linq;

namespace Dominoes
{
	public class ShopCollection : List<ShopItemInfo>
	{
		public const string StoreType = "amz";

		public int CountEnable
		{
			get
			{
				return this.Count((ShopItemInfo x) => x.Enable);
			}
		}

		public ShopItemInfo this[string name]
		{
			get
			{
				return FindByName(name);
			}
		}

		public ShopCollection()
		{
			Add(new ShopItemInfo("ru.skillcap.dominoes.1000000coins", 500000, 100, 1000000, 99.99f));
			Add(new ShopItemInfo("ru.skillcap.dominoes.450000coins", 250000, 80, 450000, 49.99f));
			Add(new ShopItemInfo("ru.skillcap.dominoes.160000coins", 100000, 60, 160000, 19.99f));
			Add(new ShopItemInfo("ru.skillcap.dominoes.70000coins", 50000, 40, 70000, 9.99f));
			Add(new ShopItemInfo("ru.skillcap.dominoes.30000coins", 25000, 20, 30000, 4.99f));
			Add(new ShopItemInfo("ru.skillcap.dominoes.10000coins", 10000, 0, 10000, 1.99f));
		}

		public void Save()
		{
		}

		public ShopItemInfo[] SingleEnable()
		{
			return this.Where((ShopItemInfo x) => x.Enable).ToArray();
		}

		public ShopItemInfo[] OnlineEnables()
		{
			return this.Where((ShopItemInfo x) => x.Enable).ToArray();
		}

		private ShopItemInfo FindByName(string name)
		{
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ShopItemInfo current = enumerator.Current;
					if (name == current.Name)
					{
						return current;
					}
				}
			}
			return null;
		}

		private ShopItemInfo FindByType(string name)
		{
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ShopItemInfo current = enumerator.Current;
					if (name == current.Name)
					{
						return current;
					}
				}
			}
			return null;
		}
	}
}
