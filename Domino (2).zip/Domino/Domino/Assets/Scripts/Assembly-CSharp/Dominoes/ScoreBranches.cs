namespace Dominoes
{
	public class ScoreBranches
	{
		private Desk desk;

		private int number;

		private int summ;

		private int[] scores;

		private int won;

		public Desk Desk
		{
			get
			{
				return desk;
			}
		}

		public int Number
		{
			get
			{
				return number;
			}
		}

		public int Summ
		{
			get
			{
				return summ;
			}
		}

		public int Won
		{
			get
			{
				return won;
			}
		}

		public int Count
		{
			get
			{
				return scores.Length;
			}
		}

		public int this[int index]
		{
			get
			{
				return scores[index];
			}
		}

		public ScoreBranches(Desk desk, int playNumber)
		{
			this.desk = desk;
			number = playNumber;
			scores = new int[desk.Count];
		}

		public void Play(bool skip)
		{
			if (skip)
			{
				InternalSkip();
			}
			else
			{
				InternalPlay();
			}
		}

		public void Over()
		{
			summ = 0;
			won = 0;
			scores = new int[desk.Count];
		}

		private void InternalPlay()
		{
			summ = 0;
			won = 0;
			scores = new int[desk.Count];
			if (desk.CountBones == 0)
			{
				won = 0;
				summ = 0;
			}
			else if (desk.CountBones == 1)
			{
				Bone bone = desk.collection[0];
				summ = bone.Value;
			}
			else
			{
				foreach (Branch item in desk)
				{
					if (item.id < 2 || item.Count > 1)
					{
						scores[item.id] = ((!item.head.bone.IsDouble) ? item.head.value : item.head.bone.Value);
						summ += scores[item.id];
					}
				}
			}
			if (summ % number == 0)
			{
				won = summ;
			}
			DebugF.Log("Play won: " + won + "; ");
		}

		private void InternalSkip()
		{
			DebugF.Log("Skip won: " + won + " --> 0");
			won = 0;
		}
	}
}
