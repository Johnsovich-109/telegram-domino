using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class InitController : BaseController, IController
{
	private abstract class BaseInitState : BaseState, IState
	{
		protected InitController controller;

		protected StartScreenCanvas StartScreen
		{
			get
			{
				return StartScreenCanvas.instance;
			}
		}

		protected void ChangeState(string state)
		{
			ChangeState(state, null);
		}

		protected void ChangeState(string state, object args)
		{
			controller.ChangeState(state, args);
		}
	}

	private class Enter : BaseInitState, IState
	{
		public const string Name = "Enter";

		private float startTime;

		public override string GetName
		{
			get
			{
				return "Enter";
			}
		}

		public Enter(InitController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			controller.Pause(10f, UpdateInfo);
			controller.Pause(1, WaitForGoTo);
			if (DominoData.User.AuthType == AuthType.Vkontakte)
			{
				SocialVKController.instance.CheckStateLogin();
				SocialVKController.instance.OnStateLogin += SocialVK_OnStateLogin;
			}
			startTime = Time.time;
		}

		private void SocialVK_OnStateLogin(bool isLoggin)
		{
			if (!(Time.time - startTime > 20f) && !isLoggin)
			{
				DominoData.User.Clear();
				WebManager.instance.Unbind(null);
			}
		}

		private void WaitForGoTo()
		{
			if (DominoData.User.AuthType == AuthType.None)
			{
				ChangeState("Ready");
			}
			else
			{
				ChangeState("Finish");
			}
		}

		private void UpdateInfo()
		{
			if (MainController.instance.ActiveController == "Lobby")
			{
				WebManager.instance.Info(OnInfoResponse);
			}
			else
			{
				controller.Pause(1f, UpdateInfo);
			}
		}

		private void OnInfoResponse(ResponseInit response)
		{
			DominoData.SetInit(response);
			if (response != null)
			{
				DominoData.User.Name = response.username;
				DominoData.Values.Balance = response.balance;
			}
			LobbyBonusView.instance.Show(DominoData.Bonus);
			controller.Pause(10f, UpdateInfo);
		}
	}

	private class Finish : BaseInitState, IState
	{
		public const string Name = "Finish";

		public override string GetName
		{
			get
			{
				return "Finish";
			}
		}

		public Finish(InitController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.StartScreen.ActiveSelf = false;
			ChangeActiveController("Lobby");
		}
	}

	private class Ready : BaseInitState, IState
	{
		public const string Name = "Ready";

		private SocialVKController VK;

		private SocialFBController FB;

		public override string GetName
		{
			get
			{
				return "Ready";
			}
		}

		public Ready(InitController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			VK = SocialVKController.instance;
			FB = SocialFBController.instance;
			VK.OnLoggedIn += VK_OnLoggedIn;
			VK.OnImportFriends += VK_OnImportFriends;
			VK.OnFailed += VK_OnFailed;
			FB.OnLogin += FB_OnLogin;
			FB.OnFailed += FB_OnFailed;
			base.StartScreen.OnButtonClick += StartScreen_OnButtonClick;
			base.StartScreen.OnChangeView += StartScreen_OnChangeView;
		}

		public override void OnEnter(string oldState, object args)
		{
			AuthType auth = AuthType.Facebook;
			SystemLanguage systemLanguage = Application.systemLanguage;
			if (systemLanguage == SystemLanguage.Belarusian || systemLanguage == SystemLanguage.Russian)
			{
				auth = AuthType.Vkontakte;
			}
			base.StartScreen.Show(auth);
		}

		public override void OnEscape()
		{
			base.StartScreen.Hide();
		}

		private void StartScreen_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				ChangeState("Finish");
			}
		}

		private void StartScreen_OnButtonClick(string message)
		{
			switch (message)
			{
			case "vk":
				OnClickVK();
				break;
			case "fb":
				OnClickFB();
				break;
			case "guest":
				OnClickGuest();
				break;
			}
		}

		private void OnClickVK()
		{
			VK.Login();
		}

		private void OnClickFB()
		{
			FB.LogIn();
		}

		private void OnClickGuest()
		{
			OnEscape();
		}

		private void FB_OnLogin(UserProfile info, string[] ids)
		{
			if (isActive)
			{
				OnLogin(AuthType.Facebook, info);
				WebManager.instance.Invite(ids, null);
				OnEscape();
			}
		}

		private void FB_OnFailed(string message)
		{
			OnClickGuest();
		}

		private void VK_OnFailed(string message)
		{
			OnClickGuest();
		}

		private void VK_OnImportFriends(VKFriendsList friendsList)
		{
			WebManager.instance.Invite(friendsList.GetIDs(), null);
			VK.OnImportFriends -= VK_OnImportFriends;
		}

		private void VK_OnLoggedIn(UserProfile info)
		{
			if (isActive)
			{
				OnLogin(AuthType.Vkontakte, info);
				OnEscape();
			}
		}

		private void OnLogin(AuthType authType, UserProfile info)
		{
			DominoData.User.AuthType = authType;
			DominoData.User.AccountId = info.id.ToString();
			DominoData.User.Name = info.username;
			DominoData.User.Avatar = info.avatar;
		}
	}

	public const string Name = "Init";

	public override string GetName
	{
		get
		{
			return "Init";
		}
	}

	public override void OnActive(string oldController, object args)
	{
		CheckInit();
		activeState = states["Enter"];
		activeState.IsActive = true;
		activeState.OnEnter(null, null);
	}

	public override void OnInactive(string newController)
	{
		activeState.OnExit(null);
		activeState.IsActive = false;
	}

	private void Awake()
	{
		states = new Dictionary<string, IState>();
		states.Add("Enter", new Enter(this));
		states.Add("Ready", new Ready(this));
		states.Add("Finish", new Finish(this));
	}

	private void Start()
	{
	}
}
