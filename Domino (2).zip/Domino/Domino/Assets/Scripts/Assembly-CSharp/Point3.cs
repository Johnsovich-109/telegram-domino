public struct Point3
{
	public int X;

	public int Y;

	public int Z;

	public static Point3 MaxValue
	{
		get
		{
			return new Point3(int.MaxValue, int.MaxValue, int.MaxValue);
		}
	}

	public static Point3 MinValue
	{
		get
		{
			return new Point3(int.MinValue, int.MinValue, int.MinValue);
		}
	}

	public static Point3 Zero
	{
		get
		{
			return new Point3(0, 0, 0);
		}
	}

	public Point3(int x, int y)
		: this(x, y, 0)
	{
	}

	public Point3(int x, int y, int z)
	{
		X = x;
		Y = y;
		Z = z;
	}

	public bool Equals(Point3 point)
	{
		return X == point.X && Y == point.Y && Z == point.Z;
	}

	public override string ToString()
	{
		return string.Format("[Point {0} {1} {2}]", X, Y, Z);
	}

	public static Point3 operator +(Point3 a, Point3 b)
	{
		return new Point3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
	}

	public static Point3 operator -(Point3 a, Point3 b)
	{
		return new Point3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
	}

	public static Point3 operator /(Point3 a, int b)
	{
		return new Point3(a.X / b, a.Y / b, a.Z / b);
	}
}
