using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKComments
	{
		public int count { get; set; }

		public int can_post { get; set; }

		public static VKComments Deserialize(object comments)
		{
			VKComments vKComments = new VKComments();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)comments;
			object value;
			if (dictionary.TryGetValue("count", out value))
			{
				vKComments.count = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("can_post", out value2))
			{
				vKComments.can_post = (int)(long)value2;
			}
			return vKComments;
		}
	}
}
