using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;


public class OnlineController : BaseController, IController
{
	public interface IOnlineState : IGameState, IState
	{
		void OnPhotonStateChange(PhotonStates target, PhotonStates current);

		void OnPhotonResponse(PhotonResponse response);

		void OnPhotonRoomChange(string message, object[] args);

		void OnPhotonLobbyChange(PhotonResponse response);

		void OnPhotonFailed(string message);
	}

	private abstract class BaseOnlineState : BaseGameState, IOnlineState, IGameState, IState
	{
		protected OnlineController controller;

		protected MessageConnectState MessageConnect
		{
			get
			{
				return base.GeneralPopups.messageConnect;
			}
		}

		protected GameRoom Room
		{
			get
			{
				return controller.room;
			}
		}

		protected PhotonManager PhotonManager
		{
			get
			{
				return PhotonManager.instance;
			}
		}

		protected ISingleGame Manager
		{
			get
			{
				return controller.manager;
			}
		}

		protected IOnlineGame ManagerOnline
		{
			get
			{
				return controller.manager;
			}
		}

		protected PhotonClient Client
		{
			get
			{
				return PhotonManager.instance.Client;
			}
		}

		protected GameMenu MenuState
		{
			get
			{
				return controller.menu;
			}
		}

		protected MessagePopupAdvanced ChooseMessage
		{
			get
			{
				return base.ChooseBlock.chooseMessage;
			}
		}

		protected GameStartedPopup GameStarted
		{
			get
			{
				return base.PlayPopups.gameStarted;
			}
		}

		protected void ChangeState(string state)
		{
			ChangeState(state, null);
		}

		protected void ChangeState(string state, object args)
		{
			controller.ChangeState(state, args);
		}

		protected void QuitToLobby()
		{
			DominoData.RoomInvite = null;
			ChangeState("Finish", "Lobby");
		}

		public virtual void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
		}

		public virtual void OnPhotonLobbyChange(PhotonResponse response)
		{
		}

		public virtual void OnPhotonRoomChange(string message, object[] args)
		{
		}

		public virtual void OnPhotonResponse(PhotonResponse response)
		{
		}

		public virtual void OnPhotonFailed(string message)
		{
			if (message == "join_room")
			{
				ResetGame();
				QuitToLobby();
			}
		}

		public virtual void OnReset()
		{
		}

		public override void OnInvite()
		{
			if (Manager != null)
			{
				ResetGame();
			}
			ChangeState("Finish", "Online");
		}

		protected void ChooseBlock_OnClickReward()
		{
			
		}

		

		protected void PlayersRoomRefresh()
		{
			for (int i = 0; i < Room.Size; i++)
			{
				if (Room[i] == null)
				{
					base.PlayersView[i].avatar.ShowJoin();
					continue;
				}
				base.PlayersView[i].avatar.AvatarURL = Room[i].Avatar;
				base.PlayersView[i].avatar.ShowAvatar();
			}
		}

		protected void ResetGame(Action callback = null)
		{
			if (Manager.State != 0)
			{
				List<BoneView> list = new List<BoneView>(28);
				foreach (Player player in Manager.Players)
				{
					list.AddRange(base.PlayersView[player].PullAll());
				}
				list.AddRange(base.DeskView.PullAll());
				base.HeapView.Back(list, callback);
			}
			base.PlayPopups.Hide();
			base.PlayPopups.gameOver.Hide();
			RoundOverView.instance.Hide();
		}

		protected void NewGame()
		{
			int countBranches = Manager.Desk.CountBranches;
			int count = Manager.Players.Count;
			string name = DominoData.GameCurrent.Name;
			base.GameCanvas.NewGame(countBranches, count, name);
		}
	}

	private class Disconnect : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Disconnect";

		public override string GetName
		{
			get
			{
				return "Disconnect";
			}
		}

		public Disconnect(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			MenuComponent.instance.OnMenuShow += ManuSmall_OnMenuShow;
			base.PlayPopups.gameMenu.OnClick += GameMenu_OnClick;
			base.MessageConnect.OnClick += MessageConnect_OnClick;
		}

		private void ManuSmall_OnMenuShow()
		{
			if (isActive)
			{
				OnEscape();
			}
		}

		public override void OnEnter(string oldState, object args)
		{
			byte b = 0;
			while (base.MenuState.IsActive && ++b < 4)
			{
				base.MenuState.OnEscape();
			}
			base.PlayPopups.Show();
			base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
		}

		public override void OnPhotonFailed(string message)
		{
			base.OnPhotonFailed(message);
			if (message == "join_room")
			{
				AdsController.instance.ShowInterstitial();
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			if (response.Name == "sync")
			{
				ChangeState("GameSync");
			}
			Debug.Log("OnPhotonResponse: " + response.Name);
		}

		public override void OnEscape()
		{
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnEscape();
				if (!base.MenuState.IsActive)
				{
					base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
				}
			}
			else
			{
				base.MessageConnect.Hide();
				base.MenuState.OnEnter("Disconnect", null);
			}
		}

		public override void OnExit(string newState)
		{
			base.PlayPopups.Hide();
			base.MessageConnect.Hide();
		}

		private void GameMenu_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
			}
		}

		private void MessageConnect_OnClick(string message)
		{
			if (isActive)
			{
				OnEscape();
			}
		}
	}

	private class Distribution : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Distribution";

		public override string GetName
		{
			get
			{
				return "Distribution";
			}
		}

		public Distribution(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.HeapView.NewRound(base.Manager.Heap.Size);
			PlayDistribution();
		}

		private void PlayDistribution()
		{
			ListBone[] array = new ListBone[base.Manager.Players.Count];
			List<BoneView>[] array2 = new List<BoneView>[base.Manager.Players.Count];
			List<BoneView> list = base.HeapView.StartGame(base.Manager.Heap.Size - base.Manager.Heap.Count);
			for (int i = 0; i < base.Manager.Players.Count; i++)
			{
				array[i] = base.Manager.Players[i];
				array2[i] = Pull(list, base.Manager.Players[i].Count);
			}
			base.PlayersView.Distribution(array, array2, OnDistributed);
		}

		private List<BoneView> Pull(List<BoneView> list, int count)
		{
			if (list.Count < count)
			{
				throw new ArgumentOutOfRangeException();
			}
			List<BoneView> range = list.GetRange(0, count);
			list.RemoveRange(0, count);
			return range;
		}

		private void OnDistributed()
		{
			if (isActive)
			{
				ChangeState("GamePlay");
			}
		}
	}

	private class Enter : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Enter";

		public override string GetName
		{
			get
			{
				return "Enter";
			}
		}

		public Enter(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			ChangeState("Connect");
		}
	}

	private class Finish : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Finish";

		public override string GetName
		{
			get
			{
				return "Finish";
			}
		}

		public Finish(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (args is string)
			{
				GoToController(args as string);
				return;
			}
			throw new Exception("Error, error!!!");
		}

		public override void OnExit(string newState)
		{
		}

		private void GoToController(string name)
		{
			ChangeActiveController(name);
		}
	}

	private class GameMenu : BaseOnlineState, IGameState, IState
	{
		public const string Name = "GameMenu";

		private PopupBehaviour currentActivePopup;

		public override string GetName
		{
			get
			{
				return "GameMenu";
			}
		}

		public PopupBehaviour ActivePopup
		{
			get
			{
				return currentActivePopup;
			}
			set
			{
				if (currentActivePopup != null)
				{
					currentActivePopup.Hide();
				}
				currentActivePopup = value;
				if (currentActivePopup != null)
				{
					currentActivePopup.Show();
				}
			}
		}

		public GameMenu(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.MenuPopup.OnClick += Menu_OnClick;
			base.RulesPopup.OnClick += Rules_OnClick;
			base.StatisticsPopup.OnClick += Statistics_OnClick;
			base.Message.OnClick += Message_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			isActive = true;
			Debug.LogWarning("----------- GAME MENU ---------------\nOnEnter");
			if (controller.activeState.GetName != "Disconnect")
			{
				base.PlayPopups.Show();
			}
			ActivePopup = base.MenuPopup;
			base.StatisticsPopup.Refresh(base.Manager.Scores);
		}

		public override void OnEscape()
		{
			if (ActivePopup == base.MenuPopup)
			{
				OnExit("GameMenu");
			}
			else
			{
				ActivePopup = base.MenuPopup;
			}
		}

		public override void OnExit(string newState)
		{
			if (controller.activeState.GetName != "Disconnect" && controller.activeState.GetName != "GameOver")
			{
				base.PlayPopups.Hide();
			}
			ActivePopup = null;
			isActive = false;
			Debug.LogWarning("----------- GAME MENU ---------------\nOnExit");
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				if (message == "yes")
				{
					ChangeState("GameQuit");
				}
				else
				{
					ActivePopup = base.MenuPopup;
				}
			}
		}

		private void Menu_OnClick(string message)
		{
			if (isActive)
			{
				switch (message)
				{
				case "escape":
					OnEscape();
					break;
				case "quit":
					ShowMessageConfirmation();
					break;
				case "statistics":
					ActivePopup = base.StatisticsPopup;
					break;
				case "rules":
					ActivePopup = base.RulesPopup;
					break;
				}
			}
		}

		private void ShowMessageConfirmation()
		{
			if (!(controller.activeState.GetName == "GameSync"))
			{
				base.Message.Title = TextManager.GetString("ConfirmationTitle").ToUpper();
				base.Message.Message = TextManager.GetString("Confirmation");
				ActivePopup = base.Message;
			}
		}

		private void Statistics_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void Rules_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class GameOver : BaseOnlineState, IGameState, IState
	{
		public const string Name = "GameOver";

		private string messageOver;

		public override string GetName
		{
			get
			{
				return "GameOver";
			}
		}

		public bool CheckShare
		{
			get
			{
				return PlayerPrefs.GetInt("gameOver_checkShare", 1) > 0;
			}
			set
			{
				PlayerPrefs.SetInt("gameOver_checkShare", value ? 1 : 0);
			}
		}

		public GameOver(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.PlayPopups.OnChangeView += Popups_OnChangeView;
			base.PlayPopups.gameOver.OnClick += GameOver_OnClick;
			base.PlayPopups.gameOver.OnCheckShare += GameOver_OnCheckShare;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnExit("GameOver");
			}
			AdsController.instance.ShowInterstitial();
			ShowMessage();
			DominoData.Statistics.OnlineFinish(DominoData.GameCurrent, base.Manager.CheckLocalWin());
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Hide();
			}
			base.Client.ConnectToMaster();
		}

		public override void OnEscape()
		{
			messageOver = "quit";
			HideMessage();
		}

		private void ShowMessage()
		{
			base.PlayPopups.Show();
			base.PlayPopups.gameOver.Show();
			base.PlayPopups.gameOver.Refresh(base.Manager.Scores, 0);
			base.PlayPopups.gameOver.IsCheckShare = CheckShare;
			base.PlayPopups.gameOver.IsToggleShow = CheckShareWon();
			base.PlayPopups.gameOver.ShowButton(!DominoData.GameCurrent.IsFriends);
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			string name = response.Name;
			if (name != null && name == "game_over")
			{
				base.PlayPopups.gameOver.Refresh(base.Manager.Scores, 0);
			}
		}

		private bool CheckShareWon()
		{
			if (DominoData.User.AuthType == AuthType.None)
			{
				return false;
			}
			return base.Manager.Scores.IndexMax((PlayerScores x) => x.BalanceChanges) == 0;
		}

		private void HideMessage()
		{
			base.PlayPopups.gameOver.Hide();
			base.PlayPopups.Hide();
		}

		private void OnResetCompleted()
		{
			ChangeState("RoomCreateOnline");
		}

		private void Popups_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				controller.StatesReset();
				if (messageOver == "again")
				{
					base.Room.Leave();
					base.Client.ConnectToMaster();
					ResetGame(OnResetCompleted);
				}
				else
				{
					ChangeState("GameQuit");
				}
			}
		}

		private void GameOver_OnClick(string message)
		{
			if (isActive)
			{
				messageOver = message;
				HideMessage();
				if (CheckShare && CheckShareWon())
				{
					Share();
				}
			}
		}

		public override void OnPhotonFailed(string message)
		{
		}

		private void GameOver_OnCheckShare(bool state)
		{
			CheckShare = state;
		}

		private void Share()
		{
			if (DominoData.User.AuthType == AuthType.Facebook)
			{
				string title = "I have just won another game on my way to top!";
				string description = "I'm on my way to be a Domino champion! Think you can beat me? Try! Let's play!";
				SocialFBController.instance.Share(title, description, "https://nardeweb.skillcap.net/i/banners/domino_invite_banner.jpg");
			}
			if (DominoData.User.AuthType == AuthType.Vkontakte)
			{
				string msg = "Я только что выиграл еще одну игру на пути к вершине рейтинга! Скоро я стану чемпионом Домино! Думаешь, сможешь меня победить? Рискни! Заходи в игру!";
				SocialVKController.instance.Share(msg, "https://vk.com/club149536085");
			}
		}
	}

	private class GamePlay : BaseOnlineState, IGameState, IState
	{
		public const string Name = "GamePlay";

		public override string GetName
		{
			get
			{
				return "GamePlay";
			}
		}

		public GamePlay(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Set(base.Manager.ScoreBranches);
				if (base.Manager.ScoreBranches.Won > 0)
				{
					Debug.LogError("Manager.ScoreBranches.Won: " + base.Manager.ScoreBranches.Won);
					base.PlayersView.PlayerActive.ShowWon(base.Manager.ScoreBranches.Won);
				}
			}
			base.PlayersView.SetGameScores(base.Manager.Players);
			if ((base.Manager.State & GameState.Play) > GameState.Start)
			{
				base.PlayersView.IndexActive = base.Manager.Players.Index;
				if (base.Manager.Players.IsMyTurn)
				{
					float timeLeft = ((!(oldState == "GameSync")) ? (DominoSettings.TimeForTurn - base.ManagerOnline.TurnPassedTime) : ((float)base.ManagerOnline.SyncTime));
					base.PlayersView.PlayerActive.timer.Play(timeLeft);
					ChangeState("TurnPlayer");
				}
				else
				{
					base.PlayersView.PlayerActive.timer.Play(DominoSettings.TimeForTurn);
					ChangeState("TurnRival");
				}
			}
			else if ((base.Manager.State & GameState.GameOver) > GameState.Start)
			{
				ChangeState("GameOver");
			}
			else if ((base.Manager.State & GameState.RoundOver) > GameState.Start)
			{
				ChangeState("RoundOver");
			}
			DebugF.Log("Players: \n {0}", base.Manager.Players.ToString());
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			if (response.Name == "round_over")
			{
				ChangeState("RoundOver");
			}
			else if (response.Name == "game_over")
			{
				ChangeState("GameOver");
			}
		}
	}

	private class GameQuit : BaseOnlineState, IGameState, IState
	{
		public const string Name = "GameQuit";

		private string oldState;

		public override string GetName
		{
			get
			{
				return "GameQuit";
			}
		}

		public GameQuit(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.GameCanvas.OnChangeView += GameCanvas_OnChangeView;
		}

		public override void OnEnter(string oldState, object args)
		{
			this.oldState = oldState;
			base.Manager.Surrender();
			base.Client.ConnectToMaster();
			List<BoneView> list = new List<BoneView>(20);
			foreach (Player player in base.Manager.Players)
			{
				List<BoneView> collection = base.PlayersView[player].PullAll();
				list.AddRange(collection);
			}
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnExit("GameQuit");
			}
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Hide();
			}
			RoundOverView.instance.Hide();
			list.AddRange(base.DeskView.PullAll());
			base.PlayersView.Clear();
			base.HeapView.Back(list);
			base.GameCanvas.Hide();
			base.MessageConnect.Hide();
			base.GeneralPopups.Hide();
		}

		private void GameCanvas_OnChangeView(DisplayState state)
		{
			if (isActive)
			{
				controller.StatesReset();
				QuitToLobby();
				if (oldState != "GameOver")
				{
					AdsController.instance.ShowInterstitial();
				}
			}
		}
	}

	private class GameSync : BaseOnlineState, IGameState, IState
	{
		public const string Name = "GameSync";

		private bool resolutionBack;

		public override string GetName
		{
			get
			{
				return "GameSync";
			}
		}

		public GameMessageSync MessageSync
		{
			get
			{
				return GameCanvas.instance.messageSync;
			}
		}

		private DominoPool Pool
		{
			get
			{
				return DominoPool.instance;
			}
		}

		public GameSync(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			resolutionBack = true;
			MessageSync.ActiveSelf = true;
			base.PlayersView.IndexActive = base.Manager.Players.Index;
			controller.StartCoroutine(Tools.Pause(1f, OnTimeout));
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Show();
				base.ScoreBranches.Set(base.Manager.ScoreBranches);
			}
			else
			{
				base.ScoreBranches.Hide();
			}
			if ((base.Manager.State & GameState.Play) > GameState.Start)
			{
				SyncGame(args);
			}
			else if ((base.Manager.State & GameState.RoundOver) > GameState.Start)
			{
				SyncRoundOver();
			}
		}

		public override void OnExit(string newState)
		{
			MessageSync.ActiveSelf = false;
			if (!base.MenuState.IsActive)
			{
				base.PlayPopups.Hide();
				base.MessageConnect.Hide();
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			if (response.Name == "start_game")
			{
				List<BoneView> list = new List<BoneView>(28);
				foreach (Player player in base.Manager.Players)
				{
					list.AddRange(base.PlayersView[player].PullAll());
				}
				resolutionBack = false;
				list.AddRange(base.DeskView.PullAll());
				RoundOverView.instance.Hide();
				base.GeneralPopups.Hide();
				base.MessageConnect.Hide();
				base.HeapView.Back(list, OnToDoRoundNew);
			}
			else if (response.Name == "skip" || response.Name == "place")
			{
				if (base.Manager.Players.Index == 0)
				{
					TurnDataOnline args = base.ManagerOnline.GetTurnData() as TurnDataOnline;
					ChangeState("TurnAuto", args);
				}
				else
				{
					ChangeState("TurnRival");
				}
			}
		}

		private void SyncGame(object args)
		{
			Pool.Revert();
			base.HeapView.Sync(base.Manager.Heap.Count);
			foreach (Player player in base.Manager.Players)
			{
				base.PlayersView[player].Sync(player);
			}
			base.DeskView.Sync(base.Manager.Desk);
		}

		private void SyncRoundOver()
		{
			Pool.Revert();
			base.HeapView.Sync(base.Manager.Heap.Count);
			foreach (Player player in base.Manager.Players)
			{
				base.PlayersView[player].PullAll();
			}
			base.DeskView.Sync(base.Manager.Desk);
			RoundOverData roundOverData = new RoundOverData(base.Manager.Players.Count);
			foreach (Player player2 in base.Manager.Players)
			{
				roundOverData.Add(player2, Pool.PullTiles(player2.Count));
			}
			RoundOverView.instance.Sync(roundOverData);
		}

		private void OnTimeout()
		{
			if (isActive && resolutionBack)
			{
				if ((base.Manager.State & GameState.GameOver) > GameState.Start)
				{
					ChangeState("GameOver");
				}
				else if ((base.Manager.State & GameState.RoundOver) > GameState.Start)
				{
					ChangeState("RoundOver");
				}
				else
				{
					ChangeState("GamePlay");
				}
			}
		}

		private void OnToDoRoundNew()
		{
			base.PlayersView.SetGameScores(base.Manager.Players);
			ChangeState("NewRound");
		}
	}

	private class RoundNew : BaseOnlineState, IGameState, IState
	{
		public const string Name = "NewRound";

		public override string GetName
		{
			get
			{
				return "NewRound";
			}
		}

		public RoundNew(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			DominoPool.instance.Revert();
			base.PlayersView.NewRound();
			base.DeskView.NewRound();
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.NewRound();
				base.ScoreBranches.Show();
			}
			else
			{
				base.ScoreBranches.Hide();
			}
			ChangeState("Distribution");
		}
	}

	private class RoundOver : BaseOnlineState, IGameState, IState
	{
		public const string Name = "RoundOver";

		private List<BoneView> collection;

		private bool waitRoundOver;

		public override string GetName
		{
			get
			{
				return "RoundOver";
			}
		}

		public RoundOverView MessageOver
		{
			get
			{
				return RoundOverView.instance;
			}
		}

		private bool IsRoundOver
		{
			get
			{
				return (base.Manager.State & GameState.RoundOver) > GameState.Start;
			}
		}

		public RoundOver(OnlineController gameController)
		{
			controller = gameController;
			collection = new List<BoneView>(20);
		}

		public override void OnInit()
		{
			MessageOver.OnClick += MessageOver_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnExit("RoundOver");
			}
			if (oldState != "GameSync")
			{
				waitRoundOver = (base.ManagerOnline.StateOnline & GameState.RoundOver) == 0;
				if (!waitRoundOver)
				{
					RoundOverShow();
				}
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			switch (response.Name)
			{
			case "start_game":
			case "game_over":
				MessageOver_OnClick();
				break;
			case "round_over":
				waitRoundOver = false;
				RoundOverShow();
				break;
			case "sync":
				SyncResponse();
				break;
			}
		}

		public override void OnExit(string newState)
		{
			MessageOver.Hide();
			base.PlayPopups.Hide();
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnExit(string.Empty);
			}
		}

		private void RoundOverShow()
		{
			base.Manager.RoundOver();
			MessageOver.Show(GetRoundData());
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Hide();
			}
		}

		private void SyncResponse()
		{
			if (waitRoundOver || (base.Manager.State & GameState.RoundOver) == 0)
			{
				OnReset();
				MessageOver.Hide();
				ChangeState("GameSync", collection);
			}
		}

		private void ManuSmall_OnMenuShow()
		{
			if (isActive)
			{
				OnEscape();
			}
		}

		private void MessageConnect_OnClick(string message)
		{
			if (isActive)
			{
				OnEscape();
			}
		}

		private void MessageOver_OnClick()
		{
			if (!isActive)
			{
				return;
			}
			if (MessageOver.IsShow)
			{
				if (!base.DeskView.IsEmpty)
				{
					collection.AddRange(base.DeskView.PullAll());
				}
				if ((base.Manager.State & (GameState)17) == 0)
				{
					if ((base.Manager.State & GameState.Play) == 0 && CheckFinalScore())
					{
						base.Client.ReadyEndRound();
					}
					if (base.MenuState.IsActive)
					{
						base.MenuState.OnExit(string.Empty);
					}
				}
				base.HeapView.Back(collection, OnHeapBeackCompleted);
				MessageOver.Hide();
			}
			else if (MessageOver.State == DisplayState.Hide && !base.HeapView.IsBackAnimationBusy)
			{
				OnHeapBeackCompleted();
			}
		}

		private bool CheckFinalScore()
		{
			return base.Manager.Scores.Max((PlayerScores x) => x.GameTotal) < base.Manager.FinalScore;
		}

		private void OnHeapBeackCompleted()
		{
			collection.Clear();
			if ((base.Manager.State & GameState.GameOver) > GameState.Start)
			{
				ChangeState("GameOver");
			}
			else if ((base.Manager.State & GameState.Play) > GameState.Start)
			{
				base.PlayersView.SetGameScores(base.Manager.Players);
				ChangeState("NewRound");
			}
		}

		private RoundOverData GetRoundData()
		{
			RoundOverData roundOverData = new RoundOverData(base.Manager.Players.Count);
			foreach (Player player in base.Manager.Players)
			{
				if (player.Count != base.PlayersView[player].Count)
				{
					base.PlayersView[player].Sync(player);
				}
				List<BoneView> list = base.PlayersView[player].PullAll();
				collection.AddRange(list);
				roundOverData.Add(player, list);
			}
			return roundOverData;
		}
	}

	private class TurnAuto : TurnPlayer, IGameState, IState
	{
		public new const string Name = "TurnAuto";

		private Turn turn;

		public override string GetName
		{
			get
			{
				return "TurnAuto";
			}
		}

		public TurnAuto(OnlineController gameController)
			: base(gameController)
		{
		}

		public override void OnInit()
		{
			handOpen = base.PlayersView.Local.hand as PlayerHandOpen;
			handController = handOpen as PlayerHandController;
		}

		public override void OnEnter(string oldState, object args)
		{
			turnData = args as TurnDataOnline;
			turn = base.ManagerOnline.TurnCurrent;
			TurnAutoPlay();
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			if (response.Name == "sync")
			{
				OnResponseSync();
			}
		}

		public override void OnPhotonRoomChange(string message, object[] args)
		{
		}

		private void TurnAutoPlay()
		{
			if (turn == null)
			{
				throw new NullReferenceException("Turn is null");
			}
			if (turnData == null)
			{
				throw new NullReferenceException("TurnDataOnline is null");
			}
			if (!turn.player.IsLocal)
			{
				Debug.LogError("The move is not a local player. Player ID = " + turn.player.Id);
				turn.player = base.Manager.Players.Local;
			}
			base.DeskView.SetBacklight(null);
			if (turnData.IsAddEnable)
			{
				controller.StartCoroutine(PlayAnimation());
				handController.BackToHand(turnData.tileMoving);
				turnData.tileMoving = null;
			}
			else
			{
				Turn(turn);
			}
		}

		private IEnumerator PlayAnimation()
		{
			while (true)
			{
				Bone pullAdding;
				Bone currentBone = (pullAdding = turnData.PullAdding);
				if (pullAdding == null)
				{
					break;
				}
				ShowingAdd(currentBone);
				yield return new WaitForSeconds(DominoSettings.TimeMoveBone * 0.5f);
			}
			base.HeapView.IsActive = false;
			yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
			Turn(turn);
		}

		protected override void Complited()
		{
			turn = null;
			turnData = null;
			if ((base.Manager.State & GameState.Play) > GameState.Start)
			{
				base.Manager.Next();
			}
			ChangeState("GamePlay");
		}

		private void ShowingAdd(Bone addBone)
		{
			BoneView tile = base.HeapView.Pull();
			base.Manager.Players.Current.Push(addBone);
			base.PlayersView[turn.player].Push(addBone, tile);
		}
	}

	private class TurnPlayer : BaseOnlineState, IGameState, IState
	{
		public const string Name = "TurnPlayer";

		protected TurnDataOnline turnData;

		private BoneHandleMove handle;

		protected PlayerHandOpen handOpen;

		protected PlayerHandController handController;

		private BoneView tileMoving;

		public override string GetName
		{
			get
			{
				return "TurnPlayer";
			}
		}

		public ListBone available
		{
			get
			{
				return turnData.available;
			}
			set
			{
				turnData.available = value;
			}
		}

		public bool IsCanMakeTurn
		{
			get
			{
				return turnData.IsCanMakeTurn && Timer.CurrentTime > 0f;
			}
		}

		private PlayerTimer Timer
		{
			get
			{
				return base.PlayersView.Local.timer;
			}
		}

		protected PlayerPanel CurrentPlaerView
		{
			get
			{
				return base.PlayersView[base.Manager.Players.Current];
			}
		}

		public TurnPlayer(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			handOpen = base.PlayersView.Local.hand as PlayerHandOpen;
			handController = handOpen as PlayerHandController;
			handController.OnMoveBegin += Hand_OnMoveBegin;
			handController.OnMoveEnd += Hand_OnMoveEnd;
			handController.OnSelectTile += Hand_OnSelectTile;
			handController.OnUnselectTile += Hand_OnUnselectTile;
			handController.OnClickField += Hand_OnClickField;
			base.HeapView.OnClick += HeapView_OnClick;
			MenuComponent.instance.OnMenuShow += OnClickMenu;
			Timer.OnTimerCompleted += Timer_OnTimerCompleted;
		}

		public override void OnEnter(string oldState, object args)
		{
			turnData = base.ManagerOnline.GetTurnData() as TurnDataOnline;
			available = base.ManagerOnline.GetAvailablePlayer();
			handOpen.SetAvailable(available);
			if ((base.ManagerOnline.TurnCurrent == null || base.ManagerOnline.TurnCurrent.adding.Count == 0) && available.Count == 0 && !base.Manager.Heap.IsEmpty)
			{
				base.Client.Add();
				turnData.isWaitResponse = true;
			}
			if (tileMoving != null)
			{
				handle = new BoneHandleMove(tileMoving, GetPairingInDesk(tileMoving));
				base.DeskView.SetBacklight(handle);
			}
			CheckingWaitToDo();
			if (base.ManagerOnline.TurnCurrent != null && base.ManagerOnline.TurnCurrent.CompletedOnline)
			{
				OnResponsePlace();
			}
		}

		public override void OnEscape()
		{
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnEscape();
			}
			else
			{
				OnClickMenu();
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			if (current == PhotonStates.Disconnect)
			{
				OnReset();
				ChangeState("Disconnect");
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			switch (response.Name)
			{
			case "sync":
				OnResponseSync();
				break;
			case "add":
				OnResponseAdd();
				break;
			case "place":
				OnResponsePlace();
				break;
			case "round_over":
			case "game_over":
				OnResponseGameOver();
				break;
			}
		}

		protected void OnResponseAdd()
		{
			turnData.isWaitResponse = false;
			CheckingWaitToDo();
		}

		protected void OnResponsePlace()
		{
			turnData.tileMoving = tileMoving;
			ChangeState("TurnAuto", turnData);
			tileMoving = null;
			handle = null;
			turnData = null;
		}

		protected void OnResponseSync()
		{
			OnReset();
			ChangeState("GameSync");
		}

		protected void OnResponseGameOver()
		{
			turnData = null;
			ChangeState("GamePlay");
		}

		public override void OnExit(string newState)
		{
			handOpen.SetAvailable(null);
			turnData = null;
			if (newState != "TurnAuto")
			{
				base.HeapView.IsActive = false;
			}
			if (handle != null)
			{
				base.DeskView.SetBacklight(handle = null);
			}
		}

		protected bool Turn(Turn turn)
		{
			try
			{
				Timer.Stop();
				turnData.Play(turn);
				base.Manager.Play(turn);
				if (turn.Skip)
				{
					ShowingSkip();
					if (!turn.autoplay)
					{
						base.Client.Skip();
					}
				}
				else
				{
					ShowingTurn(turn);
					if (!turn.autoplay)
					{
						base.Client.Play(turn.MoveBone, turn.MoveBranch);
					}
				}
				return true;
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Client.Sync();
				return false;
			}
		}

		private void Skip()
		{
			Turn turn = new Turn(base.Manager.Players.Current);
			Turn(turn);
		}

		private void ShowingTurn(Turn turn)
		{
			BoneView boneView = base.PlayersView[turn.player.Id].Pull(turn.MoveBone);
			boneView.Show(turn.MoveBone);
			base.DeskView.Turn(turn.MoveBranch, boneView, Complited);
		}

		private void ShowingSkip()
		{
			controller.StartCoroutine(Tools.Pause(0.7f, delegate
			{
				CurrentPlaerView.Skip(Complited);
			}));
		}

		protected virtual void Complited()
		{
			if (isActive)
			{
				turnData = null;
				if ((base.Manager.State & GameState.Play) > GameState.Start)
				{
					base.Manager.Next();
				}
				ChangeState("GamePlay");
			}
		}

		private void CheckingWaitToDo()
		{
			if (available.Count > 0)
			{
				base.HeapView.IsActive = false;
				if (!IsCanMakeTurn)
				{
					Complited();
				}
			}
			else if (!turnData.isWaitResponse)
			{
				if (base.ManagerOnline.TurnCurrent != null && !turnData.isAddRequest)
				{
					turnData.SetAddList(base.ManagerOnline.TurnCurrent.adding);
				}
				base.HeapView.IsActive = turnData.IsAddEnable;
				if (!turnData.IsAddEnable)
				{
					Skip();
				}
			}
		}

		private Turn CreateTurnMoving(BoneView tile)
		{
			if (base.Manager.Desk.IsEmpty)
			{
				if (handController.GetNearestBone(tile))
				{
					return base.Manager.CreateTurn(tile.Bone);
				}
			}
			else
			{
				List<BoneView> pairingInDesk = GetPairingInDesk(tile);
				BoneView nearestBone = handController.GetNearestBone(tile, pairingInDesk);
				if (nearestBone != null)
				{
					return base.Manager.CreateTurn(tile.Bone, nearestBone.Bone);
				}
			}
			return null;
		}

		private Turn CreateTurnDoubleClick(BoneView tile, Vector3 position)
		{
			if (base.Manager.Desk.IsEmpty)
			{
				if (handController.GetNearestBonePosition(tile, position))
				{
					return base.Manager.CreateTurn(tile.Bone);
				}
			}
			else
			{
				List<BoneView> pairingInDesk = GetPairingInDesk(tile);
				BoneView nearestBonePosition = handController.GetNearestBonePosition(tile, pairingInDesk, position);
				if (nearestBonePosition != null)
				{
					return base.Manager.CreateTurn(tile.Bone, nearestBonePosition.Bone);
				}
			}
			return null;
		}

		private void Hand_OnMoveBegin(BoneView tile)
		{
			tile.mover.Stop();
			SelectTilesOnDesk(tile);
		}

		private void Hand_OnMoveEnd(BoneView tile)
		{
			Turn turn = null;
			tileMoving = null;
			if (isActive)
			{
				if (IsCanMakeTurn && available.Exists((Bone x) => x.Equals(tile.Bone)))
				{
					turn = CreateTurnMoving(tile);
				}
				base.DeskView.SetBacklight(handle = null);
			}
			if (turn != null)
			{
				Turn(turn);
			}
			else
			{
				handController.BackToHand(tile);
			}
		}

		private void Hand_OnUnselectTile(BoneView tile)
		{
			base.DeskView.SetBacklight(null);
		}

		private void Hand_OnSelectTile(BoneView tile)
		{
			SelectTilesOnDesk(tile);
		}

		private void Hand_OnClickField(BoneView tile, Vector3 position)
		{
			Turn turn = null;
			tileMoving = null;
			if (isActive)
			{
				if (IsCanMakeTurn && available.Exists((Bone x) => x.Equals(tile.Bone)))
				{
					turn = CreateTurnDoubleClick(tile, position);
				}
				base.DeskView.SetBacklight(handle = null);
			}
			if (turn != null)
			{
				Turn(turn);
			}
			else
			{
				handController.TileUnselect();
			}
		}

		private void Timer_OnTimerCompleted()
		{
			if (isActive && handle != null)
			{
				handController.BackToHand(handle.TileMove);
				base.DeskView.SetBacklight(handle = null);
			}
		}

		private void HeapView_OnClick(BoneView tile)
		{
			if (isActive && turnData.IsAddEnable)
			{
				Bone pullAdding = turnData.PullAdding;
				base.Manager.Players.Current.Push(pullAdding);
				available = base.Manager.GetAvailablePlayer();
				turnData.Add(pullAdding);
				tile.Enabled = false;
				base.HeapView.Pull(tile);
				CurrentPlaerView.Push(pullAdding, tile, delegate
				{
					tile.Enabled = true;
				});
				handOpen.SetAvailable(available);
				CheckingWaitToDo();
			}
		}

		private void SelectTilesOnDesk(BoneView tile)
		{
			tileMoving = tile;
			if (isActive && IsCanMakeTurn && tile.Bone != null)
			{
				handle = new BoneHandleMove(tile, GetPairingInDesk(tile));
				base.DeskView.SetBacklight(handle);
			}
		}

		private List<BoneView> GetPairingInDesk(BoneView tile)
		{
			ListBone pairing = base.Manager.Desk.GetPairing(tile.Bone);
			List<BoneView> list = new List<BoneView>();
			foreach (Bone item in pairing)
			{
				list.Add(base.DeskView[item]);
			}
			return list;
		}

		private void OnClickMenu()
		{
			if (isActive)
			{
				if (base.MenuState.IsActive)
				{
					base.MenuState.OnExit(string.Empty);
				}
				else
				{
					base.MenuState.OnEnter("TurnPlayer", null);
				}
			}
		}
	}

	private class TurnRival : BaseOnlineState, IGameState, IState
	{
		public const string Name = "TurnRival";

		public override string GetName
		{
			get
			{
				return "TurnRival";
			}
		}

		private PlayerTimer Timer
		{
			get
			{
				return base.PlayersView[base.Manager.Players.Current].timer;
			}
		}

		public TurnRival(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			MenuComponent.instance.OnMenuShow += OnClickMenu;
		}

		public override void OnEnter(string oldState, object args)
		{
			if ((base.Manager.State & (GameState)18) > GameState.Start)
			{
				OnResponseGameOver();
			}
			else
			{
				CheckState();
			}
		}

		public override void OnEscape()
		{
			if (base.MenuState.IsActive)
			{
				base.MenuState.OnEscape();
			}
			else
			{
				OnClickMenu();
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			switch (response.Name)
			{
			case "place":
			case "add":
			case "skip":
				CheckState();
				break;
			case "sync":
				OnResponseSync();
				break;
			case "round_over":
			case "game_over":
				OnResponseGameOver();
				break;
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			if (current == PhotonStates.Disconnect)
			{
				OnReset();
				ChangeState("Disconnect");
			}
		}

		private void OnResponseGameOver()
		{
			ChangeState("GamePlay");
		}

		private void OnResponseSync()
		{
			OnReset();
			ChangeState("GameSync");
		}

		private void CheckState()
		{
			Turn turnCurrent = base.ManagerOnline.TurnCurrent;
			if (turnCurrent == null)
			{
				return;
			}
			if (turnCurrent.CompletedOnline)
			{
				if (turnCurrent.Skip)
				{
					SkipInternal(turnCurrent);
				}
				else if (turnCurrent.CompletedSingle)
				{
					Completed();
				}
				else
				{
					PlayInternal(turnCurrent);
				}
			}
			else
			{
				Bone pullAdding = turnCurrent.PullAdding;
				if (pullAdding != null)
				{
					ShowingAdd(turnCurrent, pullAdding);
				}
			}
		}

		private void PlayInternal(Turn turn)
		{
			if (!turn.isPlayed)
			{
				Turn(turn);
				ShowingTurn(turn);
				turn.NextStep();
				if (turn.CompletedOnline)
				{
					Timer.Stop();
				}
			}
		}

		private void SkipInternal(Turn turn)
		{
			Turn(turn);
			ShowingSkip(turn);
			Timer.Stop();
		}

		private void ShowingAdd(Turn turn, Bone addBone)
		{
			BoneView tile = base.HeapView.Pull();
			base.Manager.Players.Current.Push(addBone);
			base.PlayersView[turn.player].Push(addBone, tile, CheckState);
		}

		private void ShowingTurn(Turn turn)
		{
			if (turn == null)
			{
				Debug.Log("Turn == null");
			}
			BoneView boneView = base.PlayersView[turn.player.Id].PullRandom();
			if (boneView == null)
			{
				Debug.Log("Tile == null");
			}
			boneView.Show(turn.MoveBone);
			base.DeskView.Turn(turn.MoveBranch, boneView, CheckState);
		}

		private void ShowingSkip(Turn turn)
		{
			base.PlayersView[turn.player].Skip(Completed);
		}

		protected bool Turn(Turn turn)
		{
			DebugF.Log(turn);
			try
			{
				base.Manager.Play(turn);
				turn.isPlayed = true;
				return true;
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.Message);
				base.Client.Sync();
				return false;
			}
		}

		private void Completed()
		{
			if (isActive)
			{
				if ((base.Manager.State & GameState.Play) > GameState.Start)
				{
					base.Manager.Next();
				}
				ChangeState("GamePlay");
			}
		}

		private void OnClickMenu()
		{
			if (isActive)
			{
				if (base.MenuState.IsActive)
				{
					base.MenuState.OnExit(string.Empty);
				}
				else
				{
					base.MenuState.OnEnter("TurnRival", null);
				}
			}
		}
	}

	private class Connect : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Connect";

		public override string GetName
		{
			get
			{
				return "Connect";
			}
		}

		public Connect(OnlineController gameController)
		{
			controller = gameController;
			base.GameCanvas.OnChangeView += GameCanvas_OnChangeView;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.Client.ConnectToMaster();
			CreateRoom();
			if (DominoData.RoomInvite == null)
			{
				base.ChooseBlock.Show();
				base.ChooseBlock.RewardButton = false;
				base.ChooseBlock.Title = TextManager.GetString((!DominoData.GameCurrent.IsFriends) ? "ONLINE GAME" : "FRIENDS GAME");
				ChangeState("Games");
			}
			else
			{
				base.ChooseBlock.Hide();
				if (base.GameCanvas.State == DisplayState.Show || base.GameCanvas.State == DisplayState.Hide)
				{
					ChangeState("RoomCreateByInvite");
				}
			}
		}

		private void CreateRoom()
		{
			if (DominoData.GameCurrent == null)
			{
				DominoData.GameCurrent = new GameCurrent(DominoData.Games.Default, DominoData.RoomInvite != null);
			}
			controller.room = new GameRoom(DominoData.GameCurrent.IsFriends);
		}

		private void GameCanvas_OnChangeView(DisplayState state)
		{
			if (isActive && DominoData.RoomInvite != null && (state == DisplayState.Hide || state == DisplayState.Show))
			{
				ChangeState("RoomCreateByInvite");
			}
		}
	}

	private class Friends : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Friends";

		private FriendsCollection data;

		private bool isJoingLobby;

		public override string GetName
		{
			get
			{
				return "Friends";
			}
		}

		public Friends(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChooseBlock.OnChangeView += ChooseBlock_OnChangeView;
			base.ChooseFriends.OnButtonClick += ChoosePlayers_OnButtonClick;
			base.ChooseFriends.OnOnlineFriend += ChooseFriends_OnOnlineFriend;
			base.ChooseFriends.OnSelectFriend += ChooseFriends_OnSelectFriend;
			base.MessageConnect.OnClick += MessageConnect_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChooseBlock.RewardButton = false;
			if (!isJoingLobby)
			{
				base.Room.inviteFriends = new List<PhotonFriend>();
				base.Client.ConnectToLobby();
				base.GeneralPopups.Show();
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
				base.MessageConnect.Message = TextManager.GetString("Connecting");
			}
			if (isJoingLobby)
			{
				base.ChooseFriends.Show(DominoData.GameCurrent, data);
			}
			base.ChooseFriends.ButtonStart = data != null && data.select.Count > 0;
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
		}

		public override void OnPhotonLobbyChange(PhotonResponse response)
		{
			switch (response.Name)
			{
			case "joined_lobby":
				JoinedLobby();
				break;
			case "received_friends":
				ReceivedFriends(response[0]);
				break;
			}
		}

		public override void OnEscape()
		{
			base.Client.ConnectToMaster();
			isJoingLobby = false;
			data = null;
			ChangeState("Games");
		}

		public override void OnExit(string newState)
		{
			base.GeneralPopups.Hide();
			base.MessageConnect.Hide();
			base.ChooseFriends.Hide();
		}

		private void JoinedLobby()
		{
			base.GeneralPopups.Hide();
			base.MessageConnect.Hide();
			base.ChooseFriends.Show(DominoData.GameCurrent, data);
			base.ChooseFriends.ActiveLoader = true;
			isJoingLobby = true;
		}

		private void ReceivedFriends(object arg)
		{
			if (data == null)
			{
				data = new FriendsCollection(base.Room.Size, DominoData.User.AuthType);
			}
			data.ReceivedFriends(arg as Dictionary<string, object>);
			base.ChooseFriends.Show(DominoData.GameCurrent, data);
		}

		private void StartGame()
		{
			DebugF.Log("Select: {0}; Room size: {1}; ", base.Room.inviteFriends.Count, DominoData.GameCurrent.CountPlayers);
			base.Room.inviteFriends = data.select;
			isJoingLobby = false;
			data = null;
			base.ChooseFriends.Hide();
			base.ChooseBlock.Hide();
		}

		private void ChooseBlock_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				ChangeState("RoomCreateFriend");
			}
		}

		private void ChooseFriends_OnSelectFriend(FriendData friend)
		{
			if (data.select.Count > 0)
			{
				data.MoveToOnline(friend);
				base.ChooseFriends.SetLists(data.online, data.select);
			}
			else
			{
				base.ChooseFriends.Show(DominoData.GameCurrent, data);
			}
			base.ChooseFriends.ButtonStart = data.select.Count > 0;
		}

		private void ChooseFriends_OnOnlineFriend(FriendData friend)
		{
			if (data.select.Count < DominoData.GameCurrent.CountPlayers - 1)
			{
				data.MoveToSelect(friend);
				base.ChooseFriends.SetLists(data.online, data.select);
			}
			base.ChooseFriends.ButtonStart = data.select.Count > 0;
		}

		private void ChoosePlayers_OnButtonClick(string message)
		{
			if (isActive)
			{
				switch (message)
				{
				case "escape":
					OnEscape();
					break;
				case "start":
					StartGame();
					break;
				case "vk":
					InviteFromVK();
					break;
				case "fb":
					InviteFromFB();
					break;
				}
			}
		}

		private void InviteFromVK()
		{
			ChangeState("Invites");
		}

		private void InviteFromFB()
		{
			SocialFBController.instance.AppInvite();
		}

		protected virtual void MessageConnect_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class Games : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Games";

		public override string GetName
		{
			get
			{
				return "Games";
			}
		}

		public Games(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChooseGames.OnChooseGame += ChooseGames_OnChooseGame;
			base.ChooseGames.OnButtonClick += ChooseGames_OnButtonClick;
			base.ChooseBlock.OnClickReward += base.ChooseBlock_OnClickReward;
			base.ChooseBlock.OnChangeView += ChooseBlock_OnChangeView;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChooseBlock.Show();
			base.ChooseBlock.IsUpdateReward = true;
			base.ChooseGames.Show(DominoData.Games.OnlineEnables());
		}

		public override void OnEscape()
		{
			base.Client.Disconnect();
			base.ChooseBlock.Hide();
			base.ChooseGames.Hide();
		}

		public override void OnExit(string newState)
		{
			base.ChooseBlock.IsUpdateReward = false;
			base.ChooseGames.Hide();
		}

		private void ChooseBlock_OnChangeView(DisplayState state)
		{
			if (IsActive && state == DisplayState.Hide)
			{
				QuitToLobby();
			}
		}

		private void ChooseGames_OnChooseGame(GameInfo info)
		{
			if (isActive)
			{
				DominoData.GameCurrent.gameInfo = info;
				base.Room.GameInfo = info;
				ChangeState("Players");
			}
		}

		private void ChooseGames_OnButtonClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class Invites : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Invites";

		private SocialVKController vk;

		private SocialFBController fb;

		public override string GetName
		{
			get
			{
				return "Invites";
			}
		}

		protected FriendsInvite FriendsView
		{
			get
			{
				return PopupsLobby.instance.friends;
			}
		}

		public Invites(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			vk = SocialVKController.instance;
			vk.OnImportFriends += Vk_OnImportFriends;
			vk.OnLoggedIn += Vk_OnLoggedIn;
			FriendsView.OnClick += Friends_OnClick;
			FriendsView.OnFriendClick += FriendsView_OnFriendClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			FriendsView.Show();
			FriendsView.SetFriends(null);
			FriendsView.ActiveLoader = true;
			GetFriends();
		}

		public override void OnEscape()
		{
			ChangeState("Friends");
		}

		public override void OnExit(string newState)
		{
			FriendsView.Hide();
		}

		private void Friends_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void FriendsView_OnFriendClick(UserProfile friend)
		{
			SocialVKController.instance.InviteVKFriend(friend.id);
			DebugF.Log("OnFriendClick: " + friend.ToString());
		}

		private void GetFriends()
		{
			switch (DominoData.User.AuthType)
			{
			case AuthType.Vkontakte:
				ImportVKFriends();
				break;
			case AuthType.Facebook:
				ImportFBFriends();
				break;
			}
		}

		private void Vk_OnLoggedIn(UserProfile profile)
		{
			if (isActive)
			{
				ImportVKFriends();
			}
		}

		private void Vk_OnImportFriends(VKFriendsList friendsList)
		{
			if (isActive)
			{
				FriendsView.SetFriends(friendsList);
				FriendsView.ActiveLoader = false;
				WebManager.instance.Invite(friendsList.GetIDs(), null);
			}
		}

		private void ImportVKFriends()
		{
			vk.ImportFriends();
		}

		private void ImportFBFriends()
		{
			fb.AppInvite();
		}
	}

	private class Players : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Players";

		public override string GetName
		{
			get
			{
				return "Players";
			}
		}

		public Players(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChoosePlayers.OnChoosePlayers += ChoosePlayers_OnChoosePlayer;
			base.ChoosePlayers.OnButtonClick += ChoosePlayers_OnButtonClick;
			base.ChooseBlock.OnClickReward += base.ChooseBlock_OnClickReward;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChooseBlock.IsUpdateReward = true;
			base.ChoosePlayers.Show();
		}

		public override void OnEscape()
		{
			ChangeState("Games");
		}

		public override void OnExit(string newState)
		{
			base.ChooseBlock.IsUpdateReward = false;
			base.ChoosePlayers.Hide();
		}

		private void ChoosePlayers_OnChoosePlayer(int count)
		{
			if (IsActive)
			{
				DominoData.GameCurrent.CountPlayers = count;
				base.Room.Size = count;
				ChangeState("Rate");
			}
		}

		private void ChoosePlayers_OnButtonClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class Rate : BaseOnlineState, IGameState, IState
	{
		public const string Name = "Rate";

		public override string GetName
		{
			get
			{
				return "Rate";
			}
		}

		public Rate(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChooseBlock.OnClickReward += base.ChooseBlock_OnClickReward;
			base.ChooseBlock.OnChangeView += ChooseBlock_OnChangeView;
			base.ChooseRates.Init(DominoData.Bets);
			base.ChooseRates.OnChooseRate += ChoosePlayers_OnChooseRate;
			base.ChooseRates.OnButtonClick += ChoosePlayers_OnButtonClick;
			base.ChooseMessage.OnClick += ChooseMessage_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChooseBlock.IsUpdateReward = true;
			base.ChooseRates.Show();
		}

		public override void OnEscape()
		{
			ChangeState("Players");
		}

		public override void OnExit(string newState)
		{
			base.ChooseBlock.IsUpdateReward = false;
			base.ChooseRates.Hide();
			base.ChooseMessage.Hide();
		}

		private void NotEnoughMoney()
		{
			base.ChooseRates.Hide();
			base.ChooseMessage.BoxButtons = MessageBoxButtons.OK;
			base.ChooseMessage.Show(TextManager.GetString("NotEnoughMoneyTitle"), TextManager.GetString("NotEnoughMoney"));
		}

		private void ToGame(BetItem selectBet)
		{
			base.Room.Bet = selectBet.Bet;
			DominoData.GameCurrent.Rate = selectBet.Bet;
			DominoData.GameCurrent.FinalScore = selectBet.Score;
			if (DominoData.GameCurrent.IsFriends)
			{
				ChangeState("Friends");
				return;
			}
			base.ChooseRates.Hide();
			base.ChooseBlock.Hide();
		}

		private void ChooseBlock_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				ChangeState("RoomCreateOnline");
			}
		}

		private void ChooseMessage_OnClick(string message)
		{
			if (isActive)
			{
				base.ChooseMessage.Hide();
				base.ChooseRates.Show();
			}
		}

		private void ChoosePlayers_OnChooseRate(BetItem selectBet)
		{
			if (isActive)
			{
				if (DominoData.Values.Balance < selectBet.Bet)
				{
					NotEnoughMoney();
				}
				else
				{
					ToGame(selectBet);
				}
			}
		}

		private void ChoosePlayers_OnButtonClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private abstract class RoomCreateBase : BaseOnlineState, IGameState, IState
	{
		public override void OnInit()
		{
			base.GameStarted.OnClick += GameStarted_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			CreateManager(DominoData.GameCurrent);
			base.ChooseBlock.RewardButton = false;
			base.GameCanvas.Show();
			NewGame();
			if (base.Client.CurrentState == PhotonStates.ToMaster)
			{
				base.GameStarted.Show(DominoData.GameCurrent, false);
			}
			else
			{
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
			}
		}

		public override void OnEscape()
		{
			base.Client.ConnectToMaster();
			ChangeState("Games");
			base.GameStarted.Hide();
		}

		public override void OnPhotonRoomChange(string message, object[] args)
		{
			switch (message)
			{
			case "room_joined":
			case "room_created":
				ComplitedRoom();
				break;
			}
		}

		protected virtual void ComplitedRoom()
		{
			base.MessageConnect.Hide();
			ChangeState("RoomFilling");
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			switch (current)
			{
			case PhotonStates.Disconnect:
				base.GameStarted.Hide();
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
				break;
			case PhotonStates.ToMaster:
				base.GameStarted.Show(DominoData.GameCurrent, false);
				base.MessageConnect.Hide();
				break;
			}
		}

		public override void OnPhotonFailed(string message)
		{
			if (message == "join_room")
			{
				base.GameStarted.Hide();
				base.MessageConnect.Hide();
			}
		}

		public override void OnExit(string newState)
		{
			base.MessageConnect.Hide();
		}

		private void GameStarted_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		protected void CreateManager(GameCurrent current)
		{
			GameManager gameManager = CreateSingle(current);
			controller.manager = CreateOnline(gameManager, current);
			gameManager.FinalScore = current.FinalScore;
		}

		protected IOnlineGame CreateOnline(GameManager single, GameCurrent current)
		{
			switch (current.gameInfo.gameType)
			{
			case GameType.AllFives:
			case GameType.AllThrees:
				return new OnlineGameAllNumber(single);
			case GameType.BlockGame:
			case GameType.DrawGame:
				return new OnlineGame(single);
			case GameType.Kozel:
				return new OnlineGame(single);
			default:
				throw new Exception("Error: unknown game: " + current.Name);
			}
		}

		protected GameManager CreateSingle(GameCurrent current)
		{
			switch (current.gameInfo.gameType)
			{
			case GameType.AllFives:
				return new GameAllFives(current.CountPlayers);
			case GameType.AllThrees:
				return new GameAllThrees(current.CountPlayers);
			case GameType.BlockGame:
				return new GameBlock(current.CountPlayers);
			case GameType.DrawGame:
				return new GameDraw(current.CountPlayers);
			case GameType.Kozel:
				return new GameKozel(current.CountPlayers);
			default:
				throw new Exception("Error: unknown game: " + current.Name);
			}
		}
	}

	private class RoomCreateByInvite : RoomCreateBase, IGameState, IState
	{
		public const string Name = "RoomCreateByInvite";

		public override string GetName
		{
			get
			{
				return "RoomCreateByInvite";
			}
		}

		public RoomCreateByInvite(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			GameSetting(DominoData.RoomInvite);
			base.OnEnter(oldState, args);
			if (base.Client.CurrentState == PhotonStates.ToMaster)
			{
				Join();
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			base.OnPhotonStateChange(target, current);
			if (target == PhotonStates.ToGame && current == PhotonStates.Connecting)
			{
				base.GameStarted.Hide();
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
			}
			if (target == PhotonStates.ToMaster && current == PhotonStates.ToMaster)
			{
				Join();
			}
		}

		public override void OnEscape()
		{
			base.Client.Disconnect();
			DominoData.RoomInvite = null;
			QuitToLobby();
		}

		private void Join()
		{
			base.Client.JoinFriendRoom(base.ManagerOnline, base.Room, DominoData.RoomInvite);
		}

		private void GameSetting(RoomInvite roomInvite)
		{
			GameType typeByNumber = GamesCollection.GetTypeByNumber(roomInvite.Table);
			GameCurrent gameCurrent = new GameCurrent(DominoData.Games[typeByNumber], roomInvite.MaxPlayers, roomInvite.Bet, true);
			base.Room.GameInfo = gameCurrent.gameInfo;
			base.Room.Size = roomInvite.MaxPlayers;
			base.Room.Bet = roomInvite.Bet;
			gameCurrent.FinalScore = DominoData.Bets.GetFinalScore(roomInvite.Bet);
			DominoData.GameCurrent = gameCurrent;
		}
	}

	private class RoomCreateFriend : RoomCreateBase, IGameState, IState
	{
		public const string Name = "RoomCreateFriend";

		public override string GetName
		{
			get
			{
				return "RoomCreateFriend";
			}
		}

		public RoomCreateFriend(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.OnEnter(oldState, args);
			if (base.Client.CurrentState == PhotonStates.ToLobby)
			{
				base.Client.ConnectToGame(base.ManagerOnline, base.Room);
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			base.OnPhotonStateChange(target, current);
			if (current == PhotonStates.ToGame)
			{
				base.Client.ConnectToGame(base.ManagerOnline, base.Room);
			}
		}

		public override void OnEscape()
		{
			base.Client.ConnectToLobby();
			ChangeState("Games");
		}

		protected override void ComplitedRoom()
		{
			SendInvites();
			base.ComplitedRoom();
		}

		private void SendInvites()
		{
			string[] array = new string[base.Room.inviteFriends.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = base.Room.inviteFriends[i].id;
			}
			base.Client.SendInvite(array);
		}
	}

	private class RoomCreateOnline : RoomCreateBase, IGameState, IState
	{
		public const string Name = "RoomCreateOnline";

		public override string GetName
		{
			get
			{
				return "RoomCreateOnline";
			}
		}

		public RoomCreateOnline(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.OnEnter(oldState, args);
			if (base.Client.CurrentState == PhotonStates.ToMaster)
			{
				base.Client.ConnectToGame(base.ManagerOnline, base.Room);
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			base.OnPhotonStateChange(target, current);
			if (current == PhotonStates.ToMaster)
			{
				base.Client.ConnectToGame(base.ManagerOnline, base.Room);
			}
		}
	}

	private class RoomFilling : BaseOnlineState, IGameState, IState
	{
		public const string Name = "RoomFilling";

		public override string GetName
		{
			get
			{
				return "RoomFilling";
			}
		}

		public RoomFilling(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.GameStarted.OnClick += GameStarted_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (oldState == "RoomReady")
			{
				ShowMessageFilling();
			}
			else
			{
				controller.StartCoroutine(Tools.Pause(0.3f, ShowMessageFilling));
			}
			base.GameStarted.Show(DominoData.GameCurrent, false);
		}

		public override void OnEscape()
		{
			base.Client.ConnectToMaster();
			base.PlayersView.Clear();
			base.GameCanvas.Hide();
			if (DominoData.RoomInvite == null)
			{
				ChangeState("Connect");
			}
			else
			{
				QuitToLobby();
			}
		}

		public override void OnPhotonRoomChange(string message, object[] args)
		{
			switch (message)
			{
			case "player_conected":
				RefreshPlayers();
				break;
			case "player_disconected":
				RefreshPlayers();
				break;
			case "property_changed":
				RefreshPlayers();
				break;
			case "activity_changed":
				break;
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			if (current == PhotonStates.Disconnect)
			{
				base.PlayersView.Local.avatar.ShowDisconnect();
			}
		}

		public override void OnExit(string newState)
		{
			if (newState != "RoomReady")
			{
				base.GameCanvas.Hide();
				base.GameStarted.Hide();
			}
		}

		protected void RefreshPlayers()
		{
			for (int i = 0; i < base.Room.Size; i++)
			{
				base.PlayersView[i].SetPlayerInfo(base.Room[i]);
			}
			if (base.Room.IsFilling)
			{
				ChangeState("RoomReady");
				for (int j = 0; j < base.Room.Size; j++)
				{
					base.Manager.Players[j].Avatar = base.Room[j].Avatar;
					base.Manager.Players[j].Name = base.Room[j].Username;
				}
			}
		}

		private void ShowMessageFilling()
		{
			base.GameCanvas.Show();
		}

		private void GameStarted_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class RoomReady : BaseOnlineState, IGameState, IState
	{
		public const string Name = "RoomReady";

		public override string GetName
		{
			get
			{
				return "RoomReady";
			}
		}

		private bool IsAnyInactive
		{
			get
			{
				PhotonPlayer[] playerList = PhotonNetwork.playerList;
				foreach (PhotonPlayer photonPlayer in playerList)
				{
					if (photonPlayer.IsInactive)
					{
						return true;
					}
				}
				return false;
			}
		}

		public RoomReady(OnlineController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.MessageConnect.OnClick += MessageConnect_OnClick;
			base.GameStarted.OnClick += GameStarted_OnClick;
		}

		public override void OnInvite()
		{
			Debug.Log("OnInvite ------------------------ ");
			base.GameStarted.Hide();
			base.OnInvite();
		}

		public override void OnEnter(string oldState, object args)
		{
			base.GameStarted.Show(DominoData.GameCurrent, true);
			base.GameStarted.Play(9f, OnEnd);
			Handheld.Vibrate();
		}

		public override void OnEscape()
		{
			base.Client.ConnectToMaster();
			base.GameCanvas.Hide();
			base.ChooseBlock.Show();
			if (DominoData.RoomInvite == null)
			{
				ChangeState("Games");
			}
			else
			{
				QuitToLobby();
			}
		}

		public override void OnPhotonStateChange(PhotonStates target, PhotonStates current)
		{
			if (current == PhotonStates.ToGame)
			{
				base.MessageConnect.Hide();
				base.GameStarted.Show();
				if (base.Room.IsFilling)
				{
					base.GameStarted.Show(DominoData.GameCurrent, true);
					base.GameStarted.Play(9f, OnEnd);
				}
				else
				{
					ChangeState("RoomFilling");
				}
			}
			else
			{
				base.MessageConnect.Show(MessageConnectState.TypeMessage.Connecting);
				base.GameStarted.Hide();
				base.PhotonManager.Ready(false);
				base.GameStarted.Hide();
				base.PlayersView.Local.avatar.ShowDisconnect();
			}
		}

		public override void OnPhotonRoomChange(string message, object[] args)
		{
			switch (message)
			{
			case "player_conected":
				RefreshPlayers();
				break;
			case "player_disconected":
				RefreshPlayers();
				break;
			case "property_changed":
				RefreshPlayers();
				break;
			case "activity_changed":
				RefreshPlayers();
				break;
			}
		}

		public override void OnPhotonFailed(string message)
		{
			base.OnPhotonFailed(message);
			if (message != "connect_photon")
			{
				base.MessageConnect.Hide();
				base.GameStarted.Show();
			}
		}

		public override void OnPhotonResponse(PhotonResponse response)
		{
			switch (response.Name)
			{
			case "start_game":
				StartGame();
				ChangeState("NewRound");
				break;
			case "sync":
				if ((base.Manager.State & GameState.Play) > GameState.Start)
				{
					base.HeapView.NewRound(base.Manager.Heap.Size);
					StartGame();
					ChangeState("GameSync");
				}
				break;
			}
		}

		public override void OnExit(string newState)
		{
			if (newState != "RoomFilling")
			{
				base.GameStarted.Hide();
			}
			base.MessageConnect.Hide();
		}

		private void StartGame()
		{
			Analytics.OnlineGame(DominoData.GameCurrent);
			DominoData.Statistics.OnlineStart(DominoData.GameCurrent);
			for (int i = 0; i < base.Room.Size; i++)
			{
				base.Manager.Players[i].Avatar = base.Room[i].Avatar;
				base.Manager.Players[i].Name = base.Room[i].Username;
			}
		}

		private void OnEnd()
		{
			base.PhotonManager.Ready(true);
		}

		private void RefreshPlayers()
		{
			PlayersRoomRefresh();
			if (!base.Room.IsFilling || IsAnyInactive)
			{
				ChangeState("RoomFilling");
			}
		}

		private void GameStarted_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void MessageConnect_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void Client_OnRoomChange(string state, int index)
		{
			if (state == "joinned")
			{
				base.PlayersView[index].avatar.ShowAvatar();
			}
			else if (state == "disconnect")
			{
				base.PlayersView[index].avatar.ShowJoin();
				ChangeState("RoomFilling");
			}
		}
	}

	public const string Name = "Online";

	private IOnlineGame manager;

	private GameRoom room;

	private GameMenu menu;

	public override string GetName
	{
		get
		{
			return "Online";
		}
	}

	public override void OnActive(string oldController, object args)
	{
		CheckInit();
		PhotonManager.instance.ClientCreate();
		PhotonManager.instance.Client.OnChangeState += Client_OnChangeState;
		PhotonManager.instance.Client.OnResponse += Client_OnResponse;
		PhotonManager.instance.Client.OnRoomChange += Client_OnRoomChange;
		PhotonManager.instance.Client.OnClientFailed += Client_OnClientFailed;
		PhotonManager.instance.Client.OnLobbyChange += Client_OnLobbyChange;
		activeState = states["Enter"];
		activeState.IsActive = true;
		activeState.OnEnter(null, null);
	}

	public override void OnInactive(string newController)
	{
		activeState.OnExit(null);
		activeState.IsActive = false;
		PhotonManager.instance.ClientDestroy();
	}

	private void Client_OnLobbyChange(PhotonResponse response)
	{
		(activeState as IOnlineState).OnPhotonLobbyChange(response);
	}

	private void Client_OnRoomChange(string message, object[] args)
	{
		(activeState as IOnlineState).OnPhotonRoomChange(message, args);
	}

	private void Client_OnResponse(PhotonResponse response)
	{
		(activeState as IOnlineState).OnPhotonResponse(response);
	}

	private void Client_OnChangeState(PhotonStates target, PhotonStates current)
	{
		(activeState as IOnlineState).OnPhotonStateChange(target, current);
	}

	private void Client_OnClientFailed(string message)
	{
		(activeState as IOnlineState).OnPhotonFailed(message);
	}

	protected void StatesReset()
	{
		foreach (KeyValuePair<string, IState> state in states)
		{
			(state.Value as IGameState).OnReset();
		}
	}

	private void Awake()
	{
		states = new Dictionary<string, IState>();
		menu = new GameMenu(this);
	}

	private void Start()
	{
		states.Add("Enter", new Enter(this));
		states.Add("Finish", new Finish(this));
		states.Add("Connect", new Connect(this));
		states.Add("Games", new Games(this));
		states.Add("Players", new Players(this));
		states.Add("Rate", new Rate(this));
		states.Add("Friends", new Friends(this));
		states.Add("Invites", new Invites(this));
		states.Add("RoomCreateOnline", new RoomCreateOnline(this));
		states.Add("RoomCreateFriend", new RoomCreateFriend(this));
		states.Add("RoomCreateByInvite", new RoomCreateByInvite(this));
		states.Add("RoomFilling", new RoomFilling(this));
		states.Add("RoomReady", new RoomReady(this));
		states.Add("NewRound", new RoundNew(this));
		states.Add("Distribution", new Distribution(this));
		states.Add("GamePlay", new GamePlay(this));
		states.Add("TurnPlayer", new TurnPlayer(this));
		states.Add("TurnAuto", new TurnAuto(this));
		states.Add("TurnRival", new TurnRival(this));
		states.Add("GameOver", new GameOver(this));
		states.Add("GameQuit", new GameQuit(this));
		states.Add("RoundOver", new RoundOver(this));
		states.Add("Disconnect", new Disconnect(this));
		states.Add("GameSync", new GameSync(this));
		states.Add("GameMenu", menu);
	}
}
