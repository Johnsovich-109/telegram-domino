public class OSPermissionSubscriptionState
{
	public OSPermissionState permissionStatus;

	public OSSubscriptionState subscriptionStatus;
}
