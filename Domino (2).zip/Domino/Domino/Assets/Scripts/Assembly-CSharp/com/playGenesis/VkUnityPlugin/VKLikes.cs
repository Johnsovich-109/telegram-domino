using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKLikes
	{
		public int count { get; set; }

		public int user_likes { get; set; }

		public int can_like { get; set; }

		public int can_publish { get; set; }

		public static VKLikes Deserialize(object likes)
		{
			VKLikes vKLikes = new VKLikes();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)likes;
			object value;
			if (dictionary.TryGetValue("count", out value))
			{
				vKLikes.count = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("can_publish", out value2))
			{
				vKLikes.can_publish = (int)(long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("user_likes", out value3))
			{
				vKLikes.user_likes = (int)(long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("can_like", out value4))
			{
				vKLikes.can_like = (int)(long)value4;
			}
			return vKLikes;
		}
	}
}
