using System;
using UnityEngine;

namespace Dominoes
{
	public class UserData
	{
		private string avatar;

		public string AccountId
		{
			get
			{
				return PlayerPrefs.GetString("user_id", string.Empty);
			}
			set
			{
				PlayerPrefs.SetString("user_id", value);
			}
		}

		public string Name
		{
			get
			{
				return PlayerPrefs.GetString("user_first_name", "Player");
			}
			set
			{
				PlayerPrefs.SetString("user_first_name", value);
			}
		}

		public AuthType AuthType
		{
			get
			{
				return (AuthType)PlayerPrefs.GetInt("auth_type", -1);
			}
			set
			{
				PlayerPrefs.SetInt("auth_type", (int)value);
			}
		}

		public string Avatar
		{
			get
			{
				return avatar ?? (avatar = PlayerPrefs.GetString("user_avatar", string.Empty));
			}
			set
			{
				if (avatar != value)
				{
					avatar = value;
					PlayerPrefs.GetString("user_avatar", value);
					if (this.OnChangeAvatar != null)
					{
						this.OnChangeAvatar(value);
					}
				}
			}
		}

		public event Action<string> OnChangeAvatar;

		public UserData()
		{
			avatar = null;
		}

		public void Clear()
		{
			AccountId = string.Empty;
			Name = string.Empty;
			Avatar = string.Empty;
			AuthType = AuthType.None;
		}

		internal void Save()
		{
			throw new NotImplementedException();
		}
	}
}
