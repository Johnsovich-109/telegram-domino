using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKGeo
	{
		public string type { get; set; }

		public string coordinates { get; set; }

		public Place place { get; set; }

		public static VKGeo Deserialize(object geo)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)geo;
			VKGeo vKGeo = new VKGeo();
			object value;
			if (dictionary.TryGetValue("type", out value))
			{
				vKGeo.type = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("coordinates", out value2))
			{
				vKGeo.coordinates = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("place", out value3))
			{
				vKGeo.place = Place.Deserialize(value3);
			}
			return vKGeo;
		}
	}
}
