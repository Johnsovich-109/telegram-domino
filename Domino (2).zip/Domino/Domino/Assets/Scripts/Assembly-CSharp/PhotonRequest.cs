public class PhotonRequest
{
}
