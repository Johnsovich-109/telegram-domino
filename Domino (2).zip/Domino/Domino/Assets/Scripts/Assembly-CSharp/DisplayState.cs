public enum DisplayState
{
	Show = 0,
	Hide = 1,
	Showing = 2,
	Hidding = 3
}
