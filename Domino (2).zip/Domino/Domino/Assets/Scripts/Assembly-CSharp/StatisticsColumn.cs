using Dominoes;
using UnityEngine.UI;

public class StatisticsColumn : TableStatisticColumn
{
	public Text[] textScores;

	public override void Refresh(PlayerScores playScore)
	{
		base.Refresh(playScore);
		SetTable(playScore);
	}

	private void SetTable(PlayerScores playScore)
	{
		if (playScore.RoundList.Count < textScores.Length)
		{
			for (int i = 0; i < playScore.RoundList.Count; i++)
			{
				textScores[i].text = GetScore(playScore.RoundList[i], playScore.MemoryList[i]);
			}
			for (int j = playScore.RoundList.Count; j < textScores.Length; j++)
			{
				textScores[j].text = string.Empty;
			}
		}
		else
		{
			for (int k = 1; k <= textScores.Length; k++)
			{
				textScores[textScores.Length - k].text = GetScore(playScore.RoundList[playScore.RoundList.Count - k], playScore.MemoryList[playScore.MemoryList.Count - k]);
			}
		}
	}

	private string GetScore(int round, int memory)
	{
		if (memory == 0)
		{
			return round.ToString();
		}
		return round + " (" + memory + ")";
	}
}
