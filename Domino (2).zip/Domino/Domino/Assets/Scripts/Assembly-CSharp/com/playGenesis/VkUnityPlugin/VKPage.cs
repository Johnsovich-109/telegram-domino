using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPage
	{
		public long id { get; set; }

		public long group_id { get; set; }

		public long creator_id { get; set; }

		public string title { get; set; }

		public int current_user_can_edit { get; set; }

		public int current_user_can_edit_access { get; set; }

		public int who_can_view { get; set; }

		public int who_can_edit { get; set; }

		public int edited { get; set; }

		public int created { get; set; }

		public long editor_id { get; set; }

		public int views { get; set; }

		public string parent { get; set; }

		public string parent2 { get; set; }

		public string source { get; set; }

		public string html { get; set; }

		public string view_url { get; set; }

		public static VKPage Deserialize(object page)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)page;
			VKPage vKPage = new VKPage();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKPage.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("group_id", out value2))
			{
				vKPage.group_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("creator_id", out value3))
			{
				vKPage.creator_id = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("title", out value4))
			{
				vKPage.title = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("current_user_can_edit", out value5))
			{
				vKPage.current_user_can_edit = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("current_user_can_edit_access", out value6))
			{
				vKPage.current_user_can_edit_access = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("who_can_view", out value7))
			{
				vKPage.who_can_view = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("who_can_edit", out value8))
			{
				vKPage.who_can_edit = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("edited", out value9))
			{
				vKPage.edited = (int)(long)value9;
			}
			object value10;
			if (dictionary.TryGetValue("created", out value10))
			{
				vKPage.created = (int)(long)value10;
			}
			object value11;
			if (dictionary.TryGetValue("editor_id", out value11))
			{
				vKPage.editor_id = (long)value11;
			}
			object value12;
			if (dictionary.TryGetValue("views", out value12))
			{
				vKPage.views = (int)(long)value12;
			}
			object value13;
			if (dictionary.TryGetValue("parent", out value13))
			{
				vKPage.parent = (string)value13;
			}
			object value14;
			if (dictionary.TryGetValue("parent2", out value14))
			{
				vKPage.parent2 = (string)value14;
			}
			object value15;
			if (dictionary.TryGetValue("source", out value15))
			{
				vKPage.source = (string)value15;
			}
			object value16;
			if (dictionary.TryGetValue("html", out value16))
			{
				vKPage.html = (string)value16;
			}
			object value17;
			if (dictionary.TryGetValue("view_url", out value17))
			{
				vKPage.view_url = (string)value17;
			}
			return vKPage;
		}
	}
}
