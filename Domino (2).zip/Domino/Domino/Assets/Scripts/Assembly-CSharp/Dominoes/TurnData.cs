namespace Dominoes
{
	public class TurnData
	{
		public readonly int limitTurn;

		public readonly int limitAdd;

		public int countTurn;

		public int countAdd;

		public ListBone available;

		public bool IsCanMakeTurn
		{
			get
			{
				return limitTurn < 0 || countTurn < limitTurn;
			}
		}

		public bool IsCanAdding
		{
			get
			{
				return limitAdd < 0 || countAdd < limitAdd;
			}
		}

		public TurnData()
			: this(1, -1)
		{
		}

		public TurnData(int limitTurn, int limitAdd)
		{
			this.limitTurn = limitTurn;
			this.limitAdd = limitAdd;
		}

		public void Play(Turn turn)
		{
			countTurn++;
		}

		public void Add(Bone bone)
		{
			countAdd++;
		}
	}
}
