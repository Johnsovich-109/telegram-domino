using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class SingleController : BaseController, IController
{
	private abstract class BaseSingleState : BaseGameState, IGameState, IState
	{
		protected SingleController controller;

		protected GameManager Manager
		{
			get
			{
				return controller.manager;
			}
		}

		protected void ChangeState(string state)
		{
			ChangeState(state, null);
		}

		protected void ChangeState(string state, object args)
		{
			controller.ChangeState(state, args);
		}

		protected void QuitToLobby()
		{
			base.PlayersView.Clear();
			ChangeState("Finish", "Lobby");
		}

		public virtual void OnReset()
		{
		}

		public override void OnInvite()
		{
			ResetGame();
			ChangeState("Finish", "Online");
		}

		private void ResetGame()
		{
			if (Manager != null && Manager.State != 0)
			{
				List<BoneView> list = new List<BoneView>(28);
				foreach (Player player in Manager.Players)
				{
					list.AddRange(base.PlayersView[player].PullAll());
				}
				list.AddRange(base.DeskView.PullAll());
				base.HeapView.Back(list);
			}
			base.PlayPopups.Hide();
			base.PlayPopups.gameOver.Hide();
			RoundOverView.instance.Hide();
		}
	}

	private class Distribution : BaseSingleState, IGameState, IState
	{
		public const string Name = "Distribution";

		private bool isWaitCompletion;

		public override string GetName
		{
			get
			{
				return "Distribution";
			}
		}

		public Distribution(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (isWaitCompletion)
			{
				OnDistributed();
				return;
			}
			base.HeapView.NewRound(base.Manager.Heap.Size);
			PlayDistribution();
		}

		public override void OnReset()
		{
			isWaitCompletion = false;
		}

		public override void OnExit(string newState)
		{
			if (newState != "GameMenu")
			{
				isWaitCompletion = false;
			}
		}

		private void PlayDistribution()
		{
			ListBone[] array = new ListBone[base.Manager.Players.Count];
			List<BoneView>[] array2 = new List<BoneView>[base.Manager.Players.Count];
			List<BoneView> list = base.HeapView.StartGame(base.Manager.Heap.Size - base.Manager.Heap.Count);
			for (int i = 0; i < base.Manager.Players.Count; i++)
			{
				array[i] = base.Manager.Players[i];
				array2[i] = Pull(list, base.Manager.Players[i].Count);
			}
			base.PlayersView.Distribution(array, array2, OnDistributed);
		}

		private List<BoneView> Pull(List<BoneView> list, int count)
		{
			if (list.Count < count)
			{
				throw new ArgumentOutOfRangeException();
			}
			List<BoneView> range = list.GetRange(0, count);
			list.RemoveRange(0, count);
			return range;
		}

		private void OnDistributed()
		{
			if (isActive)
			{
				isWaitCompletion = false;
				ChangeState("GamePlay");
			}
			else
			{
				isWaitCompletion = true;
			}
		}
	}

	private class Enter : BaseSingleState, IGameState, IState
	{
		public const string Name = "Enter";

		public override string GetName
		{
			get
			{
				return "Enter";
			}
		}

		public Enter(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			DominoData.GameCurrent = new GameCurrent(DominoData.Games.Default);
			base.ChooseBlock.Show();
			base.ChooseBlock.RewardButton = false;
		}

		public override void OnUpdate(float deltaTime)
		{
			ChangeState("Games");
		}
	}

	private class Finish : BaseSingleState, IGameState, IState
	{
		public const string Name = "Finish";

		public override string GetName
		{
			get
			{
				return "Finish";
			}
		}

		public Finish(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (args is string)
			{
				GoToController(args as string);
				return;
			}
			throw new Exception("Error, error!!!");
		}

		public override void OnExit(string newState)
		{
			base.GameCanvas.Hide();
		}

		private void GoToController(string name)
		{
			ChangeActiveController(name);
		}
	}

	private class GameMenu : BaseSingleState, IGameState, IState
	{
		public const string Name = "GameMenu";

		private string callbackState;

		private PopupBehaviour currentActivePopup;

		public override string GetName
		{
			get
			{
				return "GameMenu";
			}
		}

		public PopupBehaviour ActivePopup
		{
			get
			{
				return currentActivePopup;
			}
			set
			{
				if (currentActivePopup != null)
				{
					currentActivePopup.Hide();
				}
				currentActivePopup = value;
				if (currentActivePopup != null)
				{
					currentActivePopup.Show();
				}
			}
		}

		public GameMenu(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.MenuPopup.OnClick += Menu_OnClick;
			base.RulesPopup.OnClick += Rules_OnClick;
			base.StatisticsPopup.OnClick += Statistics_OnClick;
			base.Message.OnClick += Message_OnClick;
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				if (message == "yes")
				{
					Surrender();
				}
				else
				{
					ActivePopup = base.MenuPopup;
				}
			}
		}

		public override void OnEnter(string oldState, object args)
		{
			callbackState = args as string;
			base.PlayPopups.Show();
			ActivePopup = base.MenuPopup;
			base.StatisticsPopup.Refresh(base.Manager.Scores);
		}

		public override void OnExit(string newState)
		{
			base.PlayPopups.Hide();
			ActivePopup = null;
		}

		public override void OnEscape()
		{
			if (ActivePopup == base.MenuPopup)
			{
				ChangeState(callbackState);
			}
			else
			{
				ActivePopup = base.MenuPopup;
			}
		}

		private void Menu_OnClick(string message)
		{
			if (isActive)
			{
				switch (message)
				{
				case "escape":
					OnEscape();
					break;
				case "replay":
					Replay();
					break;
				case "quit":
					ShowQuit();
					break;
				case "statistics":
					ActivePopup = base.StatisticsPopup;
					break;
				case "rules":
					ActivePopup = base.RulesPopup;
					break;
				}
			}
		}

		private void ShowQuit()
		{
			base.Message.Title = TextManager.GetString("QuitDialogTitle").ToUpper();
			base.Message.Message = TextManager.GetString("QuitDialog");
			ActivePopup = base.Message;
		}

		private void Statistics_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void Rules_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void Surrender()
		{
			base.Manager.Surrender();
			ChangeState("GamePlay");
		}

		private void Replay()
		{
			ChangeState("GameReplay");
		}
	}

	private class GameOver : BaseSingleState, IGameState, IState
	{
		public const string Name = "GameOver";

		public override string GetName
		{
			get
			{
				return "GameOver";
			}
		}

		public GameOver(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.PlayPopups.OnChangeView += Popups_OnChangeView;
			base.PlayPopups.gameOver.OnClick += GameOver_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			ShowGameOver();
			DominoData.Statistics.SingleFinish(DominoData.GameCurrent, base.Manager.CheckLocalWin());
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Hide();
			}
		}

		private void ShowGameOver()
		{
			base.PlayPopups.Show();
			base.PlayPopups.gameOver.Show();
			base.PlayPopups.gameOver.Refresh(base.Manager.Scores, -1);
			base.PlayPopups.gameOver.IsToggleShow = false;
			base.PlayPopups.gameOver.ShowButton(false);
		}

		public override void OnEscape()
		{
			HideGameOver();
		}

		private void HideGameOver()
		{
			base.PlayPopups.gameOver.Hide();
			base.PlayPopups.Hide();
		}

		private void Popups_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				QuitToLobby();
			}
		}

		private void GameOver_OnClick(string message)
		{
			if (isActive)
			{
				HideGameOver();
			}
		}
	}

	private class GamePlay : BaseSingleState, IGameState, IState
	{
		public const string Name = "GamePlay";

		public override string GetName
		{
			get
			{
				return "GamePlay";
			}
		}

		public GamePlay(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Set(base.Manager.ScoreBranches);
				if (base.Manager.ScoreBranches.Won > 0)
				{
					base.PlayersView.PlayerActive.ShowWon(base.Manager.ScoreBranches.Won);
				}
			}
			base.PlayersView.SetGameScores(base.Manager.Players);
			if ((base.Manager.State & GameState.Play) > GameState.Start)
			{
				if (base.Manager.Players.IsMyTurn)
				{
					ChangeState("TurnPlayer");
				}
				else
				{
					ChangeState("TurnRival");
				}
			}
			else if ((base.Manager.State & GameState.Surrender) > GameState.Start)
			{
				ChangeState("Surrender");
			}
			else if ((base.Manager.State & GameState.RoundOver) > GameState.Start)
			{
				ChangeState("RoundOver");
			}
			else if ((base.Manager.State & GameState.GameOver) > GameState.Start)
			{
				ChangeState("GameOver");
			}
		}
	}

	private class GameReplay : BaseSingleState, IGameState, IState
	{
		public const string Name = "GameReplay";

		private List<BoneView> collection;

		public override string GetName
		{
			get
			{
				return "GameReplay";
			}
		}

		public GameReplay(SingleController gameController)
		{
			controller = gameController;
			collection = new List<BoneView>(20);
		}

		public override void OnEnter(string oldState, object args)
		{
			controller.StatesReset();
			foreach (Player player in base.Manager.Players)
			{
				collection.AddRange(base.PlayersView[player].PullAll());
			}
			collection.AddRange(base.DeskView.PullAll());
			base.HeapView.Back(collection, OnBacked);
		}

		private void OnBacked()
		{
			collection.Clear();
			ChangeState("GameStart");
		}
	}

	private class GameStart : BaseSingleState, IGameState, IState
	{
		public const string Name = "GameStart";

		public override string GetName
		{
			get
			{
				return "GameStart";
			}
		}

		public GameStart(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			controller.manager = InitCore(DominoData.GameCurrent);
			base.GameCanvas.Show();
			base.PlayersView.StartGame(base.Manager.Players.Count);
			base.DeskView.NewGame(base.Manager.Desk.CountBranches);
			base.DeskView.GameName = DominoData.GameCurrent.Name;
			Analytics.SingleGame(DominoData.GameCurrent);
			DominoData.Statistics.SingleStart(DominoData.GameCurrent);
			base.Manager.Players.Local.Avatar = DominoData.User.Avatar;
			base.Manager.Players.Local.Name = DominoData.User.Name;
			base.PlayersView.Show(base.Manager.Players);
			PlayerPanel[] players = base.PlayersView.players;
			foreach (PlayerPanel playerPanel in players)
			{
				playerPanel.avatar.ShowAvatar();
			}
		}

		private GameManager InitCore(GameCurrent current)
		{
			switch (current.gameInfo.gameType)
			{
			case GameType.DrawGame:
				return new GameDraw(current.CountPlayers);
			case GameType.BlockGame:
				return new GameBlock(current.CountPlayers);
			case GameType.AllFives:
				return new GameAllFives(current.CountPlayers);
			case GameType.AllThrees:
				return new GameAllThrees(current.CountPlayers);
			case GameType.Kozel:
				return new GameKozel(current.CountPlayers);
			case GameType.Cross:
				return new GameCross(current.CountPlayers);
			case GameType.Gaple:
				return new GameClassic(current.CountPlayers);
			case GameType.MexicanTrain:
				return new GameClassic(current.CountPlayers);
			case GameType.CustomGame:
				return new GameClassic(current.CountPlayers);
			default:
				throw new Exception("Error: unknown game: " + current.Name);
			}
		}

		public override void OnUpdate(float deltaTime)
		{
			ChangeState("NewRound");
		}
	}

	private class RoundNew : BaseSingleState, IGameState, IState
	{
		public const string Name = "NewRound";

		public override string GetName
		{
			get
			{
				return "NewRound";
			}
		}

		public RoundNew(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			DominoPool.instance.Revert();
			base.Manager.NewRound();
			base.DeskView.NewRound();
			base.PlayersView.NewRound();
			base.PlayersView.SetGameScores(base.Manager.Players);
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Show();
			}
			else
			{
				base.ScoreBranches.Hide();
			}
			ChangeState("Distribution");
		}
	}

	private class RoundOver : BaseSingleState, IGameState, IState
	{
		public const string Name = "RoundOver";

		private List<BoneView> collection;

		private bool flagShowADS;

		public override string GetName
		{
			get
			{
				return "RoundOver";
			}
		}

		public RoundOverView MessageOver
		{
			get
			{
				return RoundOverView.instance;
			}
		}

		public RoundOver(SingleController gameController)
		{
			controller = gameController;
			collection = new List<BoneView>(20);
		}

		public override void OnInit()
		{
			MessageOver.OnClick += MessageOver_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.Manager.Scoring();
			base.Manager.RoundOver();
			RoundOverData roundOverData = new RoundOverData(base.Manager.Players.Count);
			foreach (Player player in base.Manager.Players)
			{
				List<BoneView> list = base.PlayersView[player].PullAll();
				collection.AddRange(list);
				roundOverData.Add(player, list);
			}
			MessageOver.Show(roundOverData);
			if (base.Manager.IsShowScoreBranches)
			{
				base.Manager.ScoreBranches.Over();
				base.ScoreBranches.Hide();
			}
			if (flagShowADS = (base.Manager.State & GameState.GameOver) > GameState.Start)
			{
				controller.StartCoroutine(Tools.Pause(3f, CheckShowAds));
			}
		}

		private void MessageOver_OnClick()
		{
			if (isActive && MessageOver.IsShow && !base.HeapView.IsBackAnimationBusy)
			{
				CheckShowAds();
				MessageOver.Hide();
				collection.AddRange(base.DeskView.PullAll());
				base.HeapView.Back(collection, OnBacked);
			}
		}

		private void OnBacked()
		{
			collection.Clear();
			if ((base.Manager.State & GameState.GameOver) > GameState.Start)
			{
				ChangeState("GameOver");
			}
			else
			{
				ChangeState("NewRound");
			}
		}

		private void CheckShowAds()
		{
			if (flagShowADS)
			{
				flagShowADS = false;
				AdsController.instance.ShowInterstitial();
			}
		}
	}

	private class Surrender : BaseSingleState, IGameState, IState
	{
		public const string Name = "Surrender";

		private List<BoneView> collection;

		public override string GetName
		{
			get
			{
				return "Surrender";
			}
		}

		public Surrender(SingleController gameController)
		{
			controller = gameController;
			collection = new List<BoneView>(20);
		}

		public override void OnEnter(string oldState, object args)
		{
			foreach (Player player in base.Manager.Players)
			{
				List<BoneView> list = base.PlayersView[player].PullAll();
				collection.AddRange(list);
			}
			collection.AddRange(base.DeskView.PullAll());
			base.HeapView.Back(collection, OnBacked);
			base.GameCanvas.Hide();
			DominoData.Statistics.SingleSurrender(DominoData.GameCurrent);
			if (base.Manager.IsShowScoreBranches)
			{
				base.ScoreBranches.Hide();
			}
		}

		private void OnBacked()
		{
			collection.Clear();
			QuitToLobby();
			AdsController.instance.ShowInterstitial();
		}
	}

	private class TurnPlayer : BaseSingleState, IGameState, IState
	{
		public const string Name = "TurnPlayer";

		private TurnData turnData;

		private BoneHandleMove handle;

		private PlayerHandOpen handOpen;

		private PlayerHandController handController;

		private BoneView tileMoving;

		private bool isWaitCompletion;

		public override string GetName
		{
			get
			{
				return "TurnPlayer";
			}
		}

		public ListBone available
		{
			get
			{
				return turnData.available;
			}
			set
			{
				turnData.available = value;
			}
		}

		public bool IsCanAdding
		{
			get
			{
				return !base.Manager.Heap.IsEmpty && turnData.IsCanAdding;
			}
		}

		public bool IsCanMakeTurn
		{
			get
			{
				return turnData.IsCanMakeTurn;
			}
		}

		public TurnPlayer(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			handOpen = base.PlayersView.Local.hand as PlayerHandOpen;
			handController = handOpen as PlayerHandController;
			handController.OnMoveBegin += Hand_OnMoveBegin;
			handController.OnMoveEnd += Hand_OnMoveEnd;
			handController.OnSelectTile += Hand_OnSelectTile;
			handController.OnUnselectTile += Hand_OnUnselectTile;
			handController.OnClickField += Hand_OnClickField;
			base.HeapView.OnClick += HeapView_OnClick;
			MenuComponent.instance.OnMenuShow += OnClickMenu;
		}

		public override void OnEnter(string oldState, object args)
		{
			turnData = base.Manager.GetTurnData();
			available = base.Manager.GetAvailablePlayer();
			base.PlayersView.IndexActive = base.Manager.Players.Index;
			handOpen.SetAvailable(available);
			if (isWaitCompletion)
			{
				Complited();
				return;
			}
			if (tileMoving != null)
			{
				handle = new BoneHandleMove(tileMoving, GetPairingInDesk(tileMoving));
				base.DeskView.SetBacklight(handle);
			}
			CheckingWaitToDo();
		}

		public override void OnEscape()
		{
			OnClickMenu();
		}

		public override void OnReset()
		{
			isWaitCompletion = false;
		}

		public override void OnExit(string newState)
		{
			if (newState != "GameMenu")
			{
				isWaitCompletion = false;
			}
			handOpen.SetAvailable(null);
			base.HeapView.IsActive = false;
			if (handle != null)
			{
				base.DeskView.SetBacklight(handle = null);
			}
		}

		private void Play(Turn turn)
		{
			base.Manager.Play(turn);
			turnData.Play(turn);
			if (turn.Skip)
			{
				ShowingSkip();
			}
			else
			{
				ShowingTurn(turn);
			}
		}

		private void Skip()
		{
			Turn turn = new Turn(base.Manager.Players.Current);
			Play(turn);
		}

		private void ShowingTurn(Turn turn)
		{
			BoneView boneView = base.PlayersView[turn.player.Id].Pull(turn.MoveBone);
			boneView.Show(turn.MoveBone);
			base.DeskView.Turn(turn.MoveBranch, boneView, Complited);
		}

		private void ShowingSkip()
		{
			controller.StartCoroutine(Tools.Pause(0.7f, delegate
			{
				base.PlayersView[base.Manager.Players.Current].Skip(Complited);
			}));
		}

		private void Complited()
		{
			if (isActive)
			{
				turnData = null;
				isWaitCompletion = true;
				base.Manager.Next();
				ChangeState("GamePlay");
			}
			else
			{
				isWaitCompletion = true;
			}
		}

		private void CheckingWaitToDo()
		{
			if (available.Count == 0)
			{
				base.HeapView.IsActive = IsCanAdding;
				if (!IsCanAdding)
				{
					Skip();
				}
			}
			else
			{
				base.HeapView.IsActive = false;
				if (!IsCanMakeTurn)
				{
					Complited();
				}
			}
		}

		private Turn CreateTurnMoving(BoneView tile)
		{
			if (base.Manager.Desk.IsEmpty)
			{
				if (handController.GetNearestBone(tile))
				{
					return base.Manager.CreateTurn(tile.Bone);
				}
			}
			else
			{
				List<BoneView> pairingInDesk = GetPairingInDesk(tile);
				BoneView nearestBone = handController.GetNearestBone(tile, pairingInDesk);
				if (nearestBone != null)
				{
					return base.Manager.CreateTurn(tile.Bone, nearestBone.Bone);
				}
			}
			return null;
		}

		private Turn CreateTurnDoubleClick(BoneView tile, Vector3 position)
		{
			if (base.Manager.Desk.IsEmpty)
			{
				if (handController.GetNearestBonePosition(tile, position))
				{
					return base.Manager.CreateTurn(tile.Bone);
				}
			}
			else
			{
				List<BoneView> pairingInDesk = GetPairingInDesk(tile);
				BoneView nearestBonePosition = handController.GetNearestBonePosition(tile, pairingInDesk, position);
				if (nearestBonePosition != null)
				{
					return base.Manager.CreateTurn(tile.Bone, nearestBonePosition.Bone);
				}
			}
			return null;
		}

		private void HeapView_OnClick(BoneView tile)
		{
			if (isActive && IsCanAdding)
			{
				Bone bone = base.Manager.Adding();
				available = base.Manager.GetAvailablePlayer();
				turnData.Add(bone);
				base.HeapView.Pull(tile);
				base.PlayersView[base.Manager.Players.Current].Push(bone, tile);
				handOpen.SetAvailable(available);
				CheckingWaitToDo();
			}
		}

		private void Hand_OnMoveBegin(BoneView tile)
		{
			tile.mover.Stop();
			SelectTilesOnDesk(tile);
		}

		private void Hand_OnMoveEnd(BoneView tile)
		{
			Turn turn = null;
			tileMoving = null;
			if (isActive)
			{
				if (IsCanMakeTurn && available.Exists((Bone x) => x.Equals(tile.Bone)))
				{
					turn = CreateTurnMoving(tile);
				}
				base.DeskView.SetBacklight(handle = null);
			}
			if (turn != null)
			{
				Play(turn);
			}
			else
			{
				handController.BackToHand(tile);
			}
		}

		private void Hand_OnUnselectTile(BoneView tile)
		{
			base.DeskView.SetBacklight(null);
		}

		private void Hand_OnSelectTile(BoneView tile)
		{
			SelectTilesOnDesk(tile);
		}

		private void Hand_OnClickField(BoneView tile, Vector3 position)
		{
			Turn turn = null;
			tileMoving = null;
			if (isActive)
			{
				if (IsCanMakeTurn && available.Exists((Bone x) => x.Equals(tile.Bone)))
				{
					turn = CreateTurnDoubleClick(tile, position);
				}
				base.DeskView.SetBacklight(handle = null);
			}
			if (turn != null)
			{
				Play(turn);
			}
			else
			{
				handController.TileUnselect();
			}
		}

		private void SelectTilesOnDesk(BoneView tile)
		{
			tileMoving = tile;
			if (isActive && IsCanMakeTurn)
			{
				handle = new BoneHandleMove(tile, GetPairingInDesk(tile));
				base.DeskView.SetBacklight(handle);
			}
		}

		private List<BoneView> GetPairingInDesk(BoneView tile)
		{
			ListBone pairing = base.Manager.Desk.GetPairing(tile.Bone);
			List<BoneView> list = new List<BoneView>();
			foreach (Bone item in pairing)
			{
				list.Add(base.DeskView[item]);
			}
			return list;
		}

		private void OnClickMenu()
		{
			if (isActive)
			{
				ChangeState("GameMenu", "TurnPlayer");
			}
		}
	}

	private class TurnRival : BaseSingleState, IGameState, IState
	{
		public const string Name = "TurnRival";

		private Turn turn;

		private bool isWaitCompletion;

		private int idEntered;

		public override string GetName
		{
			get
			{
				return "TurnRival";
			}
		}

		public TurnRival(SingleController gameController)
		{
			controller = gameController;
			idEntered = 0;
		}

		public override void OnInit()
		{
			MenuComponent.instance.OnMenuShow += OnClickMenu;
		}

		public override void OnEnter(string oldState, object args)
		{
			idEntered++;
			if (isWaitCompletion)
			{
				Completed();
				return;
			}
			base.PlayersView.IndexActive = base.Manager.Players.Index;
			turn = base.Manager.CreateTurn();
			if (oldState == "GamePlay")
			{
				WaitForThinking();
			}
			else
			{
				CheckState();
			}
		}

		public override void OnEscape()
		{
			OnClickMenu();
		}

		public override void OnReset()
		{
			isWaitCompletion = false;
			turn = null;
			idEntered++;
		}

		public override void OnExit(string newState)
		{
			if (newState != "GameMenu")
			{
				isWaitCompletion = false;
			}
		}

		private void WaitForThinking()
		{
			float time = UnityEngine.Random.Range(0.4f, 1f) * 2f;
			int id = ++idEntered;
			controller.StartCoroutine(Tools.Pause(time, delegate
			{
				if (isActive && id == idEntered)
				{
					CheckState();
				}
			}));
		}

		private void CheckState()
		{
			if (turn == null)
			{
				return;
			}
			if (turn.Skip)
			{
				SkipInternal();
				return;
			}
			if (turn.CompletedSingle)
			{
				Completed();
				return;
			}
			Bone pullAdding = turn.PullAdding;
			if (pullAdding == null)
			{
				PlayInternal();
			}
			else
			{
				ShowingAdd(pullAdding);
			}
		}

		private void PlayInternal()
		{
			base.Manager.Play(turn);
			ShowingTurn();
			turn.NextStep();
		}

		private void SkipInternal()
		{
			base.Manager.Play(turn);
			ShowingSkip();
		}

		private void ShowingAdd(Bone addBone)
		{
			BoneView tile = base.HeapView.Pull();
			base.PlayersView[turn.player].Push(addBone, tile, CheckState);
		}

		private void ShowingTurn()
		{
			BoneView boneView = base.PlayersView[turn.player.Id].PullRandom();
			boneView.Show(turn.MoveBone);
			base.DeskView.Turn(turn.MoveBranch, boneView, CheckState);
		}

		private void ShowingSkip()
		{
			base.PlayersView[turn.player].Skip(Completed);
		}

		private void Completed()
		{
			if (isActive)
			{
				isWaitCompletion = false;
				if ((base.Manager.State & GameState.Play) > GameState.Start)
				{
					base.Manager.Next();
				}
				ChangeState("GamePlay");
			}
			else
			{
				isWaitCompletion = true;
			}
		}

		private void OnClickMenu()
		{
			if (isActive)
			{
				ChangeState("GameMenu", "TurnRival");
			}
		}
	}

	private class Games : BaseSingleState, IState
	{
		public const string Name = "Games";

		public override string GetName
		{
			get
			{
				return "Games";
			}
		}

		public Games(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChooseGames.OnChangeView += ChooseGames_OnChangeView;
			base.ChooseGames.OnChooseGame += ChooseGames_OnChooseGame;
			base.ChooseGames.OnButtonClick += ChooseGames_OnButtonClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChooseBlock.Show();
			base.ChooseBlock.Title = TextManager.GetString("SINGLE GAME");
			base.ChooseGames.Show(DominoData.Games.SingleEnable());
		}

		public override void OnEscape()
		{
			base.ChooseBlock.Hide();
			base.ChooseGames.Hide();
		}

		public override void OnExit(string newState)
		{
			base.ChooseGames.Hide();
		}

		private void BackToLobby()
		{
			QuitToLobby();
		}

		private void ChooseGames_OnChangeView(bool isShow)
		{
			if (isActive && !isShow)
			{
				BackToLobby();
			}
		}

		private void ChooseGames_OnChooseGame(GameInfo info)
		{
			if (isActive)
			{
				DominoData.GameCurrent.gameInfo = info;
				ChangeState("Players");
			}
		}

		private void ChooseGames_OnButtonClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	private class Players : BaseSingleState, IState
	{
		public const string Name = "Players";

		public override string GetName
		{
			get
			{
				return "Players";
			}
		}

		public Players(SingleController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ChoosePlayers.OnChoosePlayers += ChoosePlayers_OnChoosePlayer;
			base.ChoosePlayers.OnButtonClick += ChoosePlayers_OnButtonClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			base.ChoosePlayers.Show();
		}

		public override void OnEscape()
		{
			ChangeState("Games");
		}

		public override void OnExit(string newState)
		{
			base.ChoosePlayers.Hide();
		}

		private void ChoosePlayers_OnChoosePlayer(int count)
		{
			if (IsActive)
			{
				DominoData.GameCurrent.CountPlayers = count;
				base.ChooseBlock.Hide();
				ChangeState("GameStart");
			}
		}

		private void ChoosePlayers_OnButtonClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}
	}

	public const string Name = "Single";

	private GameManager manager;

	public override string GetName
	{
		get
		{
			return "Single";
		}
	}

	public MenuComponent Menu
	{
		get
		{
			return MenuComponent.instance;
		}
	}

	public override void OnActive(string oldController, object args)
	{
		CheckInit();
		activeState = states["Enter"];
		activeState.IsActive = true;
		activeState.OnEnter(null, null);
	}

	public override void OnInactive(string newController)
	{
		activeState.OnExit(null);
		activeState.IsActive = false;
	}

	protected void StatesReset()
	{
		foreach (KeyValuePair<string, IState> state in states)
		{
			(state.Value as IGameState).OnReset();
		}
	}

	private void Awake()
	{
		states = new Dictionary<string, IState>();
	}

	private void Start()
	{
		states.Add("Games", new Games(this));
		states.Add("Players", new Players(this));
		states.Add("Enter", new Enter(this));
		states.Add("GameStart", new GameStart(this));
		states.Add("NewRound", new RoundNew(this));
		states.Add("Distribution", new Distribution(this));
		states.Add("GamePlay", new GamePlay(this));
		states.Add("TurnPlayer", new TurnPlayer(this));
		states.Add("TurnRival", new TurnRival(this));
		states.Add("Surrender", new Surrender(this));
		states.Add("RoundOver", new RoundOver(this));
		states.Add("GameOver", new GameOver(this));
		states.Add("GameMenu", new GameMenu(this));
		states.Add("Finish", new Finish(this));
		states.Add("GameReplay", new GameReplay(this));
	}
}
