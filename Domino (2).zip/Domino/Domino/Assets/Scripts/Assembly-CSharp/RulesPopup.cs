using System;
using Dominoes;
using UnityEngine.UI;

public class RulesPopup : PopupBehaviour
{
	public Text textTitle;

	public Text textHeader;

	public Text textContent;

	public ScrollRect scroll;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public string Header
	{
		get
		{
			return textHeader.text;
		}
		set
		{
			textHeader.text = value;
		}
	}

	public string Content
	{
		get
		{
			return textContent.text;
		}
		set
		{
			textContent.text = value;
		}
	}

	public event Action<string> OnClick;

	public override void Show()
	{
		if (DominoData.GameCurrent != null)
		{
			SetData(DominoData.GameCurrent.gameInfo);
		}
		else
		{
			Clear();
		}
		base.Show();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
	}

	private void SetData(GameInfo game)
	{
		Header = TextManager.GetString(game.Name);
		Content = TextManager.GetString("Rules_" + game.Name);
		scroll.verticalNormalizedPosition = 1f;
	}

	private void Clear()
	{
		Header = string.Empty;
		Content = string.Empty;
	}
}
