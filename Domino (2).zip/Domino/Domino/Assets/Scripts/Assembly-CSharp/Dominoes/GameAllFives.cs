namespace Dominoes
{
	public class GameAllFives : GameAllNumber
	{
		public GameAllFives(int players)
			: base(players, 5)
		{
		}
	}
}
