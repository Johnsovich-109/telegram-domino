namespace com.playGenesis.VkUnityPlugin
{
	public class Eroor_17_Behaviour : QueueWorker<VKRequest>
	{
		private VkApi _vkapi;

		private void Start()
		{
			_vkapi = VkApi.VkApiInstance;
		}

		protected override void StartProcessing()
		{
			WebView.Instance.Add(new WebViewRequest
			{
				CallbackAction = OnRequestFinished,
				NavigateToUrl = Utilities.ParseConfirmationUrl(_current.Element.response),
				CloseWhenNavigatedToUrl = "https://oauth.vk.com/blank.html"
			});
		}

		private void OnRequestFinished(WebViewRequest e)
		{
			if (e.Error == null)
			{
				_vkapi.Call(_current.Element);
				ProccessNext();
				return;
			}
			_current.Element.error.error_code = "15";
			_current.Element.error.error_msg = "Access Denied";
			_current.Element.CallBackFunction(_current.Element);
			ProccessNext();
		}
	}
}
