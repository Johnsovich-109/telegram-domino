using UnityEngine;
using UnityEngine.UI;

public class GameMessageSync : GameBehaviour
{
	public Text textMessage;

	public Transform animTarget;

	public float speedCoef = 1f;

	public string Message
	{
		get
		{
			return textMessage.text;
		}
		set
		{
			textMessage.text = value;
		}
	}

	public void Show(string message)
	{
		base.ActiveSelf = true;
		Message = message;
	}

	public void Hide()
	{
		base.ActiveSelf = false;
	}

	private void Start()
	{
		Message = TextManager.GetString("PleaseWaitForSync");
		Hide();
	}

	private void Update()
	{
		animTarget.Rotate(0f, 0f, Time.deltaTime * speedCoef);
	}
}
