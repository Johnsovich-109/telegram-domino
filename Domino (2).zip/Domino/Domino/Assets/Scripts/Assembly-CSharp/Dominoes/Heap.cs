namespace Dominoes
{
	public class Heap : ListBone
	{
		public readonly int Size;

		protected int limit;

		protected readonly Bone[] privateCollection;

		public bool IsEmpty
		{
			get
			{
				return base.Count <= limit;
			}
		}

		public static int CountValuesBone { get; private set; }

		public static int CountInCollection { get; private set; }

		public int Limit
		{
			get
			{
				return limit;
			}
			set
			{
				limit = value;
			}
		}

		public Heap(int boneValues, int limit = 0)
		{
			CountValuesBone = boneValues;
			this.limit = limit;
			Size = boneValues * (boneValues + 1) / 2;
			privateCollection = new Bone[Size];
			int num = 0;
			for (int i = 0; i < boneValues; i++)
			{
				for (int j = i; j < boneValues; j++)
				{
					privateCollection[num] = new Bone(i, j, num);
					num++;
				}
			}
			CountInCollection = Size;
		}

		public virtual void NewRound()
		{
			Clear();
			AddRange(privateCollection);
		}
	}
}
