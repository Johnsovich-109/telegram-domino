using UnityEngine;
using com.playGenesis.VkUnityPlugin;

public class LoginLogoutBridge
{
	private AndroidJavaObject jo;

	public void Login()
	{
		jo = new AndroidJavaObject("com.playgenesis.vkunityplugin.Initializer");
		string val = FormLoginUrl();
		bool flag = jo.CallStatic<bool>("isVkAppPresent", new object[0]);
		if (VkApi.VkSetts.forceOAuth || !flag)
		{
			WebViewAuth();
			return;
		}
		jo.Set("urlBase64", val);
		jo.Call("Init");
	}

	public void Logout()
	{
		using (AndroidJavaObject androidJavaObject = new AndroidJavaObject("com.playgenesis.vkunityplugin.Initializer"))
		{
			VkApi.VkApiInstance.onLoggedOut();
			androidJavaObject.Call("Logout", VkApi.VkSetts.VkAppId.ToString());
		}
	}

	private void WebViewAuth()
	{
		WebViewRequest webViewRequest = new WebViewRequest();
		webViewRequest.NavigateToUrl = FormLoginUrl();
		webViewRequest.CloseWhenNavigatedToUrl = "https://oauth.vk.com/blank.html";
		webViewRequest.CallbackAction = delegate(WebViewRequest w)
		{
			if (w.Error != null)
			{
				VkApi.VkApiInstance.SendMessage("AccessDeniedMessage", "-1#Canceled by user");
			}
			else
			{
				VkApi.VkApiInstance.SendMessage("ReceiveNewTokenMessage", VKToken.ParseFromAuthUrl(w.LastUrlWithParams));
			}
		};
		WebViewRequest element = webViewRequest;
		WebView.Instance.Add(element);
	}

	public string FormLoginUrl()
	{
		VkSettings vkSettings = Resources.Load<VkSettings>("VkSettings");
		string text = string.Join(",", vkSettings.scope.ToArray());
		return "https://oauth.vk.com/authorize?client_id=" + vkSettings.VkAppId + "&scope=" + text + "&redirect_uri=https://oauth.vk.com/blank.html&display=mobile&forceOAuth=" + vkSettings.forceOAuth.ToString() + "&revokeAccess=" + vkSettings.revoke.ToString() + "&v=" + vkSettings.apiVersion + "&response_type=token";
	}
}
