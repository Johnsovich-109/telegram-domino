using UnityEngine;

public class ErrorUI : MonoBehaviour
{
	private static ErrorUI Instance;

	private void Awake()
	{
		Object.DontDestroyOnLoad(base.transform.gameObject);
		if (Instance == null)
		{
			Instance = this;
		}
		else
		{
			Object.DestroyImmediate(base.gameObject);
		}
	}
}
