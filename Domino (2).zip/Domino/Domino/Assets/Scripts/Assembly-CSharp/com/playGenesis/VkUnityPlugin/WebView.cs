using System;
using UnityEngine;

namespace com.playGenesis.VkUnityPlugin
{
	public class WebView : QueueWorker<WebViewRequest>
	{
		private AndroidJavaObject jo;

		public static WebView Instance;

		public event Action<string> WebViewDoneEvent;

		protected void OpenWebView(string openurl, string closeurl)
		{
			jo = new AndroidJavaObject("com.playgenesis.vkunityplugin.Initializer");
			jo.Call("OpenWebView", openurl, closeurl);
		}

		private void Awake()
		{
			if (Instance == null)
			{
				Instance = this;
				UnityEngine.Object.DontDestroyOnLoad(base.transform.gameObject);
			}
			else
			{
				UnityEngine.Object.Destroy(base.gameObject);
			}
		}

		protected override void StartProcessing()
		{
			OpenWebView(_current.Element.NavigateToUrl, _current.Element.CloseWhenNavigatedToUrl);
		}

		public string parseErrorFormUrl(string url)
		{
			if (url.Contains("cancel=1") || url.Contains("fail=1") || url.Contains("error=access_denied"))
			{
				return "Canceled by user";
			}
			if (url.Contains("network_error=1"))
			{
				return "Network error";
			}
			return null;
		}

		private void OnWebViewDoneIntrnal(string url)
		{
			Debug.Log("InternalWebView");
			_current.Element.LastUrlWithParams = url;
			string text = parseErrorFormUrl(url);
			if (!string.IsNullOrEmpty(text))
			{
				_current.Element.Error = new WebViewError(url, text);
			}
			_current.Element.CallbackAction(_current.Element);
			ProccessNext();
		}

		public void WebViewDone(string url)
		{
			Debug.Log("webview done with url " + url);
			if (this.WebViewDoneEvent != null)
			{
				this.WebViewDoneEvent(url);
			}
			OnWebViewDoneIntrnal(url);
		}
	}
}
