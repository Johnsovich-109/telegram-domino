public class PopupsLobby : CurtainManager
{
	public static PopupsLobby instance;

	public CurtainManager foreground;

	public LeaderboardController leaderboard;

	public ShopController shop;

	public ProfileSettingController profile;

	public FriendsInvite friends;

	public MessagePopupAdvanced message;

	public override void Show()
	{
		foreground.Hide();
		base.Show();
	}

	public override void Hide()
	{
		foreground.Hide();
		base.Hide();
	}

	public void ForegroundShow()
	{
		foreground.Show();
	}

	public void ForegroundHide()
	{
		foreground.Hide();
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		Reset();
	}
}
