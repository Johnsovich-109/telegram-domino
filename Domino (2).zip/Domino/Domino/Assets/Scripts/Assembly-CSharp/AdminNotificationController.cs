using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using com.playGenesis.VkUnityPlugin;

public class AdminNotificationController : MonoBehaviour
{
	public InputField input;

	public void SendNotificationToAdmin()
	{
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "apps.sendRequest?user_id=" + input.text + "&text=Новая викторина Вконтакте бросает тебе вызов! Установи игру прямо сейчас!&type=request&name=test1";
		vKRequest.CallBackFunction = OnAppSendRequest;
		VKRequest httprequest = vKRequest;
		VkApi.VkApiInstance.Call(httprequest);
	}

	private void OnAppSendRequest(VKRequest r)
	{
		string empty = string.Empty;
		try
		{
			empty = r.error.error_code;
		}
		catch
		{
			empty = string.Empty;
		}
		if (!string.IsNullOrEmpty(empty))
		{
			GlobalErrorHandler.Instance.Notification.Notify(r);
		}
		else
		{
			GlobalErrorHandler.Instance.Notification.Notity(r.response);
		}
	}

	public void Back()
	{
		SceneManager.LoadScene("StarterScene");
	}
}
