using System;
using UnityEngine;
using UnityEngine.UI;

public class LeaderboardTimeItem : MonoBehaviour
{
	public Text textTitle;

	public Sprite spriteInactive;

	public Sprite spriteActive;

	public Button button;

	public Image image;

	public string nameItem;

	private bool isSelect;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool IsSelect
	{
		get
		{
			return isSelect;
		}
		set
		{
			isSelect = value;
			image.sprite = ((!value) ? spriteInactive : spriteActive);
			button.enabled = !value;
		}
	}

	public event Action<LeaderboardTimeItem> OnClick;

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		button.onClick.AddListener(ButtonClick);
	}

	public void ButtonClick()
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(this);
		}
	}
}
