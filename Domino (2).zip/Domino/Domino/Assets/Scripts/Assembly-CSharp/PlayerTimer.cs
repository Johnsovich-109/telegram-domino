using System;
using UnityEngine;
using UnityEngine.UI;

public class PlayerTimer : GameBehaviour
{
	public Image imageProgress;

	public Text textTime;

	public bool timerSound;

	private float internalCountert;

	private float internalProgress;

	private bool isPlay;

	private AudioSource sound;

	public float Progress
	{
		get
		{
			return internalProgress;
		}
		set
		{
			internalProgress = Mathf.Clamp01(value);
			imageProgress.fillAmount = internalProgress;
		}
	}

	public bool IsPlay
	{
		get
		{
			return isPlay;
		}
		set
		{
			isPlay = value;
		}
	}

	public float CurrentTime
	{
		get
		{
			return internalCountert;
		}
		set
		{
			internalCountert = Mathf.Clamp(value, 0f, DominoSettings.TimeForTurn);
			textTime.text = internalCountert.ToString("#");
			Progress = internalCountert / DominoSettings.TimeForTurn;
		}
	}

	public event Action OnTimerCompleted;

	public void Play()
	{
		if (timerSound)
		{
			sound = GameSounds.GetSource(SoundType.Timer);
			sound.Play();
		}
		Play(DominoSettings.TimeForTurn);
	}

	public void Play(float timeLeft)
	{
		if (timerSound)
		{
			sound = GameSounds.GetSource(SoundType.Timer);
			sound.Play();
		}
		isPlay = true;
		base.ActiveSelf = true;
		CurrentTime = timeLeft;
	}

	public void Stop()
	{
		if (timerSound && (bool)sound)
		{
			sound.Stop();
		}
		CurrentTime = 0f;
		isPlay = false;
		base.ActiveSelf = false;
	}

	private void Start()
	{
		base.ActiveSelf = true;
	}

	private void Update()
	{
		if (!isPlay)
		{
			return;
		}
		if (CurrentTime > 0f)
		{
			CurrentTime -= Time.deltaTime;
			return;
		}
		if (this.OnTimerCompleted != null)
		{
			this.OnTimerCompleted();
		}
		if (timerSound && (bool)sound)
		{
			sound.Stop();
		}
		isPlay = false;
	}
}
