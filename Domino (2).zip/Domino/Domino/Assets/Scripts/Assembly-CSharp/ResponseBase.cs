using System;
using System.Collections.Generic;

public class ResponseBase
{
	public readonly int id;

	public readonly string cmd;

	public readonly string status;

	public readonly string error;

	protected DateTime responseTime;

	protected Dictionary<string, object> dictionary;

	public int TimeLater
	{
		get
		{
			return (int)(DateTime.Now - responseTime).TotalSeconds;
		}
	}

	public ResponseBase(Dictionary<string, object> dict)
	{
		dictionary = dict;
		object value;
		if (dict.TryGetValue("id", out value))
		{
			id = (int)(long)value;
		}
		if (dict.TryGetValue("cmd", out value))
		{
			cmd = (string)value;
		}
		if (dict.TryGetValue("status", out value))
		{
			status = (string)value;
		}
		if (dict.TryGetValue("error", out value))
		{
			error = (string)value;
		}
		responseTime = DateTime.Now;
	}

	protected int GetInt(string key)
	{
		object value;
		if (dictionary.TryGetValue(key, out value))
		{
			return (int)(long)value;
		}
		return 0;
	}

	protected string GetString(string key)
	{
		object value;
		if (dictionary.TryGetValue(key, out value))
		{
			return value as string;
		}
		return string.Empty;
	}
}
