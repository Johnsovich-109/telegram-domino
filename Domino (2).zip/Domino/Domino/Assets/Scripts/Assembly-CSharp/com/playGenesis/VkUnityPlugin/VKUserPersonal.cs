using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUserPersonal
	{
		public int political { get; set; }

		public List<string> langs { get; set; }

		public string religion { get; set; }

		public string inspired_by { get; set; }

		public int people_main { get; set; }

		public int life_main { get; set; }

		public int smoking { get; set; }

		public int alcohol { get; set; }

		public static VKUserPersonal Deserialize(object UserPersonal)
		{
			VKUserPersonal vKUserPersonal = new VKUserPersonal();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)UserPersonal;
			object value;
			if (dictionary.TryGetValue("political", out value))
			{
				vKUserPersonal.political = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("langs", out value2))
			{
				vKUserPersonal.langs = new List<string>();
				foreach (object item in (List<object>)value2)
				{
					vKUserPersonal.langs.Add((string)item);
				}
			}
			object value3;
			if (dictionary.TryGetValue("religion", out value3))
			{
				vKUserPersonal.religion = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("inspired_by", out value4))
			{
				vKUserPersonal.inspired_by = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("people_main", out value5))
			{
				vKUserPersonal.people_main = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("life_main", out value6))
			{
				vKUserPersonal.life_main = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("smoking", out value7))
			{
				vKUserPersonal.smoking = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("alcohol", out value8))
			{
				vKUserPersonal.alcohol = (int)(long)value8;
			}
			return vKUserPersonal;
		}
	}
}
