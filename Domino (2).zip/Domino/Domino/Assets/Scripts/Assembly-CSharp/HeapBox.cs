using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class HeapBox : MonoBehaviour
{
	public Text textCountTiles;

	public Text textTitle;

	public Transform positionShow;

	public Transform positionHide;

	public RectTransform parentTiles;

	public SmoothMover mover;

	public EmergenceByAlphaUI panelInfo;

	public float scaleInHeap = 0.4f;

	private Vector3 scale;

	private DominoPool pool;

	private List<BoneView> collection;

	private int sizeCollection;

	private bool isActive;

	private bool isBackAnimationBusy;

	public int CountTiles
	{
		get
		{
			return collection.Count;
		}
		set
		{
			textCountTiles.text = value.ToString();
		}
	}

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool IsActive
	{
		get
		{
			return isActive;
		}
		set
		{
			if (isActive != value)
			{
				isActive = value;
				mover.Move(((!value) ? positionHide : positionShow).localPosition, 0.3f);
			}
		}
	}

	public bool IsBackAnimationBusy
	{
		get
		{
			return isBackAnimationBusy;
		}
	}

	public event Action<BoneView> OnClick;

	public void NewGame()
	{
		panelInfo.Hide();
	}

	public void NewRound(int size)
	{
		sizeCollection = size;
		while (collection != null && collection.Count > 0)
		{
			InternalPull(0);
		}
		collection = new List<BoneView>(size);
		BoneView[] array = pool.PullTiles(size);
		foreach (BoneView boneView in array)
		{
			boneView.ActiveSelf = true;
			boneView.Hide();
			InternalPush(boneView);
			SetDefaultTransform(boneView);
		}
		CountTiles = collection.Count;
		if (panelInfo.IsHide)
		{
			panelInfo.EmergenceShow();
		}
	}

	public List<BoneView> StartGame(int count)
	{
		List<BoneView> result = Pull(count);
		AlignAllTiles();
		CountTiles = collection.Count;
		return result;
	}

	public void Sync(int count)
	{
		while (collection != null && collection.Count > 0)
		{
			InternalPull(0);
		}
		collection = new List<BoneView>(count);
		BoneView[] array = pool.PullTiles(count);
		foreach (BoneView boneView in array)
		{
			boneView.ActiveSelf = true;
			boneView.Hide();
			InternalPush(boneView);
			SetDefaultTransform(boneView);
		}
		CountTiles = collection.Count;
		AlignAllTiles();
	}

	public void Push(List<BoneView> list)
	{
		if (list == null || list.Count == 0)
		{
			return;
		}
		foreach (BoneView item in list)
		{
			item.Hide();
			InternalPush(item);
			SetDefaultTransform(item);
		}
		CountTiles = collection.Count;
		AlignAllTiles();
	}

	public BoneView Pull()
	{
		BoneView result = InternalPull(0);
		CountTiles = collection.Count;
		return result;
	}

	public List<BoneView> Pull(int count)
	{
		if (collection.Count < count)
		{
			throw new Exception("Error: incorrect command: " + count);
		}
		List<BoneView> list = new List<BoneView>(count);
		for (int i = 0; i < count; i++)
		{
			list.Add(InternalPull(0));
		}
		CountTiles = collection.Count;
		return list;
	}

	public IEnumerable<BoneView> PullAll()
	{
		List<BoneView> result = collection;
		collection = new List<BoneView>(sizeCollection);
		return result;
	}

	public BoneView Pull(BoneView tile)
	{
		BoneView result = InternalPull(collection.FindIndex((BoneView x) => x.Equals(tile)));
		CountTiles = collection.Count;
		return result;
	}

	public void Back(List<BoneView> collection, Action callback = null)
	{
		if (this.collection != null)
		{
			foreach (BoneView item in this.collection)
			{
				item.OnClick -= Tile_OnClick;
			}
		}
		Utils.ListShufle(collection);
		StartCoroutine(BackAnimation(collection, callback));
	}

	internal void ToString(StringBuilder s)
	{
		if (collection.Count == 0)
		{
			s.Append("Is empty");
		}
		else
		{
			foreach (BoneView item in collection)
			{
				s.Append(item.uID + "; ");
			}
		}
		s.AppendLine();
	}

	private IEnumerator BackAnimation(List<BoneView> collection, Action callback)
	{
		isBackAnimationBusy = true;
		for (int i = 0; i < collection.Count; i++)
		{
			collection[i].node.SetParent(parentTiles);
			collection[i].mover.Move(Vector3.zero, DominoSettings.TimeMoveBone);
			collection[i].mover.Scale(scale, DominoSettings.TimeMoveBone);
			collection[i].mover.Rotate(Quaternion.identity, DominoSettings.TimeMoveBone);
			if (i % 5 == 0)
			{
				yield return new WaitForSeconds(0.1f);
			}
		}
		yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
		pool.Revert();
		if (callback != null)
		{
			callback();
		}
		isBackAnimationBusy = false;
	}

	private void AlignAllTiles()
	{
		Vector2 vector = new Vector2(pool.sizeTile.width, pool.sizeTile.height) * scaleInHeap * 1.1f;
		int num = (int)(parentTiles.rect.width / vector.x);
		int num2 = (int)(parentTiles.rect.height / vector.y);
		Vector2 vector2 = new Vector2(parentTiles.rect.width / (float)num, parentTiles.rect.height / (float)num2);
		Vector2 vector3 = new Vector2(parentTiles.rect.xMin + vector2.x * 0.5f, parentTiles.rect.yMax - vector2.y * 0.5f);
		int num3 = 0;
		int num4 = 0;
		foreach (BoneView item in collection)
		{
			item.node.localPosition = new Vector3(vector3.x + (float)num3 * vector2.x, vector3.y - (float)num4 * vector2.y);
			item.node.localScale = scale;
			if (++num3 >= num)
			{
				num3 = 0;
				num4++;
			}
		}
	}

	private void InternalPush(BoneView item)
	{
		collection.Add(item);
		item.node.SetParent(parentTiles);
		item.OnClick += Tile_OnClick;
	}

	private BoneView InternalPull(int index)
	{
		if (index < 0)
		{
			return null;
		}
		BoneView boneView = collection[index];
		collection.RemoveAt(index);
		boneView.OnClick -= Tile_OnClick;
		return boneView;
	}

	private void SetDefaultTransform(BoneView item)
	{
		item.node.localPosition = Vector3.zero;
		item.node.localScale = scale;
		item.node.localRotation = Quaternion.identity;
	}

	private void Tile_OnClick(BoneView bone)
	{
		if (isActive && this.OnClick != null)
		{
			this.OnClick(bone);
		}
	}

	private void Start()
	{
		pool = DominoPool.instance;
		scale = Vector3.one * scaleInHeap;
		mover.node.localPosition = positionHide.localPosition;
		Title = TextManager.GetString(Title).ToUpper();
	}

	private IEnumerator Autoplay()
	{
		Debug.LogError("Heap autorun");
		while (true)
		{
			if (isActive)
			{
				yield return new WaitForSeconds(0.3f);
				for (int i = 0; i < collection.Count; i++)
				{
					if (!isActive)
					{
						break;
					}
					collection[i].OnButtonClick();
					yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
				}
			}
			yield return null;
		}
	}
}
