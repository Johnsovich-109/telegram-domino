using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class PlayerHand : MonoBehaviour
{
	private const int capacity = 12;

	public float scaleInHand;

	protected List<BoneView> collection;

	protected Vector3 scaleInHandVector;

	protected Transform node;

	protected PlayerPanel player;

	public int Count
	{
		get
		{
			return collection.Count;
		}
	}

	public BoneView this[int index]
	{
		get
		{
			return collection[index];
		}
		set
		{
			collection[index] = value;
		}
	}

	public BoneView this[Bone bone]
	{
		get
		{
			int num = FindBone(bone.Id);
			if (num < 0)
			{
				return null;
			}
			return collection[num];
		}
	}

	public void Init(PlayerPanel playerPanel)
	{
		collection = new List<BoneView>(12);
		node = base.transform;
		player = playerPanel;
	}

	public virtual void Sync(Player player)
	{
		collection = new List<BoneView>(12);
		collection.AddRange(DominoPool.instance.PullTiles(player.Count));
		foreach (BoneView item in collection)
		{
			item.node.SetParent(node);
		}
	}

	public virtual void Push(Bone bone, BoneView tile, Action callback)
	{
		collection.Add(tile);
		tile.node.SetParent(node);
	}

	public virtual void Push(ListBone list, List<BoneView> tiles)
	{
		collection.AddRange(tiles);
		foreach (BoneView tile in tiles)
		{
			tile.node.SetParent(node);
		}
	}

	public virtual BoneView Pull(Bone bone)
	{
		if (collection.Count == 0)
		{
			return null;
		}
		int num = FindBone(bone.Id);
		if (num == -1)
		{
			return null;
		}
		BoneView result = collection[num];
		collection.RemoveAt(num);
		return result;
	}

	public virtual BoneView PullRandom()
	{
		if (collection.Count == 0)
		{
			return null;
		}
		BoneView result = collection[0];
		collection.RemoveAt(0);
		return result;
	}

	public virtual List<BoneView> PullAll()
	{
		List<BoneView> result = collection;
		collection = new List<BoneView>(12);
		return result;
	}

	public virtual BoneView GetBone(Bone moveBone)
	{
		throw new NotImplementedException();
	}

	public virtual void Clear()
	{
		collection.Clear();
	}

	protected IEnumerator SoundPlaying()
	{
		yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
		for (int i = 0; i < Count; i++)
		{
			GameSounds.Play(SoundType.Tile);
			yield return new WaitForSeconds(0.1f);
		}
	}

	protected int FindBone(int id)
	{
		for (int i = 0; i < collection.Count; i++)
		{
			if (collection[i].Id == id)
			{
				return i;
			}
		}
		return -1;
	}
}
