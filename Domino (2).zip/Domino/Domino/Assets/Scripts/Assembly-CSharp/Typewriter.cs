using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
[RequireComponent(typeof(LimitVisibleCharacters))]
public class Typewriter : MonoBehaviour
{
	private float _timer;

	private void Start()
	{
	}

	private void Update()
	{
		_timer += Time.deltaTime;
		if ((int)(_timer * 10f) <= GetComponent<Text>().text.Length)
		{
			GetComponent<LimitVisibleCharacters>().visibleCharacterCount = (int)(_timer * 10f);
		}
		else
		{
			_timer = 0f;
		}
	}
}
