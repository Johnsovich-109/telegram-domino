using UnityEngine.UI;

public class ProfileStatistic : GameBehaviour
{
	public Text textTitle;

	public ProfileDiagram diagram;

	public TextValuePair gamePlayed;

	public TextValuePair gameFinished;

	public TextValuePair gameScored;

	public Text[] texts;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public void Set(int wins, int losse)
	{
		diagram.Set(wins, losse);
		gamePlayed.Value = wins.ToString();
		gameFinished.Value = losse.ToString();
		gameScored.Title = (wins + losse).ToString();
	}

	public void Set(StatisticItem statistics)
	{
		diagram.Set(statistics.win, statistics.loss);
		gamePlayed.Value = statistics.start.ToString();
		gameFinished.Value = statistics.finish.ToString();
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		gamePlayed.Title = TextManager.GetString("Played") + ": ";
		gameFinished.Title = TextManager.GetString("Finished") + ": ";
		gameScored.Title = TextManager.GetString("Scored") + ": ";
	}
}
