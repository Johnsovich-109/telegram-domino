namespace com.playGenesis.VkUnityPlugin
{
	public class FileForUpload
	{
		public string filename;

		public byte[] data;

		public string mimeType;
	}
}
