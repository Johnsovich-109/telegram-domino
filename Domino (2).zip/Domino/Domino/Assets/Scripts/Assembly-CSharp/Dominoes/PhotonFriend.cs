using System.Collections.Generic;

namespace Dominoes
{
	public class PhotonFriend : FriendData
	{
		public int balance1;

		public bool isNew;

		public int status;

		public PhotonFriend(Dictionary<string, object> dict)
		{
			object value;
			if (dict.TryGetValue("id", out value))
			{
				id = value.ToString();
			}
			if (dict.TryGetValue("username", out value))
			{
				username = (string)value;
			}
			if (dict.TryGetValue("avatar", out value))
			{
				avatar = (string)value;
			}
			if (dict.TryGetValue("balance1", out value))
			{
				balance1 = (int)(long)value;
			}
			if (dict.TryGetValue("new", out value))
			{
				isNew = (bool)value;
			}
			if (dict.TryGetValue("status", out value))
			{
				status = (int)(long)value;
			}
		}
	}
}
