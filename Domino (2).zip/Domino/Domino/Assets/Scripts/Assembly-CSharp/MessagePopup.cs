using System;
using UnityEngine.UI;

public class MessagePopup : PopupBehaviour
{
	public Text textTitle;

	public Text textMessage;

	public Text[] textsButton;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public string Message
	{
		get
		{
			return textMessage.text;
		}
		set
		{
			textMessage.text = value;
		}
	}

	public event Action<string> OnClick;

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	public void Show(string title, string message)
	{
		Title = title;
		Message = message;
		base.Show();
	}

	private void Start()
	{
		for (int i = 0; i < textsButton.Length; i++)
		{
			textsButton[i].text = TextManager.GetString(textsButton[i].text);
		}
	}
}
