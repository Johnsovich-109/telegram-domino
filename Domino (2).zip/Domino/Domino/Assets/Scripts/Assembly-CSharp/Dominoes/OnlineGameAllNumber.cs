namespace Dominoes
{
	public class OnlineGameAllNumber : OnlineGame, ISingleGame, IOnlineGame
	{
		public OnlineGameAllNumber(ISingleGame single)
			: base(single)
		{
		}

		public override GameState Play(Turn turn)
		{
			GameState result = base.Play(turn);
			if (!turn.player.IsLocal)
			{
				base.ScoreBranches.Play(turn.Skip);
				base.Players.Current.Score.PlayWon += base.ScoreBranches.Won;
			}
			return result;
		}

		public override void RoundOver()
		{
			base.ScoreBranches.Over();
			base.RoundOver();
		}

		public override void OnlineGameOver(OnlineGameResult data)
		{
			base.ScoreBranches.Over();
			base.OnlineGameOver(data);
		}

		public override void OnlineSkip(int senderId)
		{
			base.ScoreBranches.Play(true);
			base.OnlineSkip(senderId);
		}

		public override void OnlinePlay(int boneId, int branch, int senderId)
		{
			base.OnlinePlay(boneId, branch, senderId);
		}

		public override void OnlineSync(GameSync data)
		{
			base.OnlineSync(data);
			base.ScoreBranches.Play(false);
		}
	}
}
