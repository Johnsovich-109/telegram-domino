using System.Collections.Generic;

namespace Dominoes
{
	public class RoomInvite
	{
		public readonly bool correctParse;

		private string nameRoom;

		private string nameServer;

		private string namePlayer;

		private string mode;

		private string paramms;

		private string username;

		private int table;

		private int playersInRoom;

		private int maxPlayers;

		private int bet;

		public string NameRoom
		{
			get
			{
				return nameRoom;
			}
		}

		public string NameServer
		{
			get
			{
				return nameServer;
			}
		}

		public string Mode
		{
			get
			{
				return mode;
			}
		}

		public string NamePlayer
		{
			get
			{
				return namePlayer;
			}
		}

		public int Table
		{
			get
			{
				return table;
			}
		}

		public string Username
		{
			get
			{
				return username;
			}
		}

		public int PlayersInRoom
		{
			get
			{
				return playersInRoom;
			}
		}

		public int MaxPlayers
		{
			get
			{
				return maxPlayers;
			}
		}

		public int Bet
		{
			get
			{
				return bet;
			}
		}

		public RoomInvite(Dictionary<string, object> dict)
		{
			if (correctParse = Parse(dict))
			{
				ParseParrams(paramms);
			}
		}

		private void ParseParrams(string paramms)
		{
			string[] array = paramms.Split(':');
			maxPlayers = int.Parse(array[0]);
			bet = int.Parse(array[1]);
			playersInRoom = int.Parse(array[2]);
			username = array[3];
			table = int.Parse(array[4]);
		}

		private bool Parse(Dictionary<string, object> dict)
		{
			object value;
			if (dict.TryGetValue("r", out value))
			{
				nameRoom = (string)value;
				if (dict.TryGetValue("h", out value))
				{
					nameServer = (string)value;
					if (dict.TryGetValue("a", out value))
					{
						namePlayer = (string)value;
						if (dict.TryGetValue("p", out value))
						{
							paramms = (string)value;
							if (dict.TryGetValue("md", out value))
							{
								mode = (string)value;
							}
							return true;
						}
						return false;
					}
					return false;
				}
				return false;
			}
			return false;
		}
	}
}
