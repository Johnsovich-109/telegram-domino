using System;
using System.Collections.Generic;
using OneSignalPush.MiniJSON;
using UnityEngine;

public class GameControllerExample : MonoBehaviour
{
	private static string extraMessage;

	private void Start()
	{
		extraMessage = null;
		OneSignal.SetLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
		OneSignal.StartInit("b2f7f966-d8cc-11e4-bed1-df8f05be55ba").HandleNotificationReceived(HandleNotificationReceived).HandleNotificationOpened(HandleNotificationOpened)
			.EndInit();
		OneSignal.inFocusDisplayType = OneSignal.OSInFocusDisplayOption.Notification;
		OneSignal.permissionObserver += OneSignal_permissionObserver;
		OneSignal.subscriptionObserver += OneSignal_subscriptionObserver;
		OSPermissionSubscriptionState permissionSubscriptionState = OneSignal.GetPermissionSubscriptionState();
		Debug.Log("pushState.subscriptionStatus.subscribed : " + permissionSubscriptionState.subscriptionStatus.subscribed);
		Debug.Log("pushState.subscriptionStatus.userId : " + permissionSubscriptionState.subscriptionStatus.userId);
	}

	private void OneSignal_subscriptionObserver(OSSubscriptionStateChanges stateChanges)
	{
		Debug.Log("stateChanges: " + stateChanges);
		Debug.Log("stateChanges.to.userId: " + stateChanges.to.userId);
		Debug.Log("stateChanges.to.subscribed: " + stateChanges.to.subscribed);
	}

	private void OneSignal_permissionObserver(OSPermissionStateChanges stateChanges)
	{
		Debug.Log("stateChanges.to.status: " + stateChanges.to.status);
	}

	private static void HandleNotificationReceived(OSNotification notification)
	{
		OSNotificationPayload payload = notification.payload;
		string body = payload.body;
		MonoBehaviour.print("GameControllerExample:HandleNotificationReceived: " + body);
		MonoBehaviour.print("displayType: " + notification.displayType);
		extraMessage = "Notification received with text: " + body;
		Dictionary<string, object> additionalData = payload.additionalData;
		if (additionalData == null)
		{
			Debug.Log("[HandleNotificationReceived] Additional Data == null");
		}
		else
		{
			Debug.Log("[HandleNotificationReceived] message " + body + ", additionalData: " + Json.Serialize(additionalData));
		}
	}

	public static void HandleNotificationOpened(OSNotificationOpenedResult result)
	{
		OSNotificationPayload payload = result.notification.payload;
		string body = payload.body;
		string actionID = result.action.actionID;
		MonoBehaviour.print("GameControllerExample:HandleNotificationOpened: " + body);
		extraMessage = "Notification opened with text: " + body;
		Dictionary<string, object> additionalData = payload.additionalData;
		if (additionalData == null)
		{
			Debug.Log("[HandleNotificationOpened] Additional Data == null");
		}
		else
		{
			Debug.Log("[HandleNotificationOpened] message " + body + ", additionalData: " + Json.Serialize(additionalData));
		}
		if (actionID != null)
		{
			extraMessage = "Pressed ButtonId: " + actionID;
		}
	}

	private void OnGUI()
	{
		GUIStyle gUIStyle = new GUIStyle("button");
		gUIStyle.fontSize = 30;
		GUIStyle gUIStyle2 = new GUIStyle("box");
		gUIStyle2.fontSize = 30;
		GUI.Box(new Rect(10f, 10f, 390f, 340f), "Test Menu", gUIStyle2);
		if (GUI.Button(new Rect(60f, 80f, 300f, 60f), "SendTags", gUIStyle))
		{
			OneSignal.SendTag("UnityTestKey", "TestValue");
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("UnityTestKey2", "value2");
			dictionary.Add("UnityTestKey3", "value3");
			OneSignal.SendTags(dictionary);
		}
		if (GUI.Button(new Rect(60f, 170f, 300f, 60f), "GetIds", gUIStyle))
		{
			OneSignal.IdsAvailable(delegate(string userId, string pushToken)
			{
				extraMessage = "UserID:\n" + userId + "\n\nPushToken:\n" + pushToken;
			});
		}
		if (GUI.Button(new Rect(60f, 260f, 300f, 60f), "TestNotification", gUIStyle))
		{
			extraMessage = "Waiting to get a OneSignal userId. Uncomment OneSignal.SetLogLevel in the Start method if it hangs here to debug the issue.";
			OneSignal.IdsAvailable(delegate(string userId, string pushToken)
			{
				if (pushToken != null)
				{
					Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
					dictionary2["contents"] = new Dictionary<string, string> { { "en", "Test Message" } };
					dictionary2["include_player_ids"] = new List<string> { userId };
					dictionary2["send_after"] = DateTime.Now.ToUniversalTime().AddSeconds(30.0).ToString("U");
					extraMessage = "Posting test notification now.";
					OneSignal.PostNotification(dictionary2, delegate(Dictionary<string, object> responseSuccess)
					{
						extraMessage = "Notification posted successful! Delayed by about 30 secounds to give you time to press the home button to see a notification vs an in-app alert.\n" + Json.Serialize(responseSuccess);
					}, delegate(Dictionary<string, object> responseFailure)
					{
						extraMessage = "Notification failed to post:\n" + Json.Serialize(responseFailure);
					});
				}
				else
				{
					extraMessage = "ERROR: Device is not registered.";
				}
			});
		}
		if (extraMessage != null)
		{
			gUIStyle2.alignment = TextAnchor.UpperLeft;
			gUIStyle2.wordWrap = true;
			GUI.Box(new Rect(10f, 390f, Screen.width - 20, Screen.height - 400), extraMessage, gUIStyle2);
		}
	}
}
