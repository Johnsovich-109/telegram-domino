public class OSSubscriptionStateChanges
{
	public OSSubscriptionState to;

	public OSSubscriptionState from;
}
