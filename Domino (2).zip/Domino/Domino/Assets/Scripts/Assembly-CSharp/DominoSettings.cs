using UnityEngine;

[ExecuteInEditMode]
public class DominoSettings : MonoBehaviour
{
	public static float TimeForTurn = 30f;

	public const float TimeWaitBeforToGame = 9f;

	public const float TimeMoveHeap = 0.3f;

	public static float TimeMoveBone = 0.4f;

	public const float DeltaTimePushBone = 0.1f;

	public const float RivalThinkingTime = 2f;

	public const float TimeSwitchBoneColor = 0.2f;

	public const float WaitBeforeSkip = 0.7f;

	public const float TimeShowMessage = 0.5f;

	public static bool Backlight = true;

	public static bool Music = true;

	public static bool Sound = true;

	public static bool AdsEnable = true;

	public const float TimeBackoutScreen = 0.3f;

	public static int CoinsPerRewarVideo = 100;

	private const float speedTime = 1f;

	private void Awake()
	{
	}

	private void Start()
	{
		Screen.sleepTimeout = 180;
	}
}
