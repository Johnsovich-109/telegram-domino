using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPoll
	{
		public long id { get; set; }

		public long owner_id { get; set; }

		public long created { get; set; }

		public int is_closed { get; set; }

		public string question { get; set; }

		public int votes { get; set; }

		public long answer_id { get; set; }

		public List<VKPollAnswer> answers { get; set; }

		public static VKPoll Deserialize(object poll)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)poll;
			VKPoll vKPoll = new VKPoll();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKPoll.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("owner_id", out value2))
			{
				vKPoll.owner_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("created", out value3))
			{
				vKPoll.created = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("is_closed", out value4))
			{
				vKPoll.is_closed = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("question", out value5))
			{
				vKPoll.question = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("votes", out value6))
			{
				vKPoll.votes = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("answer_id", out value7))
			{
				vKPoll.answer_id = (long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("answers", out value8))
			{
				List<VKPollAnswer> list = new List<VKPollAnswer>();
				List<object> list2 = (List<object>)value8;
				foreach (object item in list2)
				{
					list.Add(VKPollAnswer.Dererialize(item));
				}
				vKPoll.answers = list;
			}
			return vKPoll;
		}
	}
}
