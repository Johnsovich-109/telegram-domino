using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKGroup
	{
		public long id { get; set; }

		public string name { get; set; }

		public string screen_name { get; set; }

		public int is_closed { get; set; }

		public string deactivated { get; set; }

		public int is_admin { get; set; }

		public int admin_level { get; set; }

		public int is_member { get; set; }

		public string type { get; set; }

		public string photo_50 { get; set; }

		public string photo_100 { get; set; }

		public string photo_200 { get; set; }

		public long city { get; set; }

		public long country { get; set; }

		public VKPlace place { get; set; }

		public string description { get; set; }

		public string wiki_page { get; set; }

		public int members_count { get; set; }

		public VKCounters counters { get; set; }

		public long start_date { get; set; }

		public long finish_date { get; set; }

		public int can_post { get; set; }

		public int can_see_all_posts { get; set; }

		public int can_upload_doc { get; set; }

		public int can_create_topic { get; set; }

		public string activity { get; set; }

		public string status { get; set; }

		public string contacts { get; set; }

		public string links { get; set; }

		public long fixed_post { get; set; }

		public int verified { get; set; }

		public string site { get; set; }

		public static VKGroup Deserialise(object group)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)group;
			VKGroup vKGroup = new VKGroup();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKGroup.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("name", out value2))
			{
				vKGroup.name = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("screen_name", out value3))
			{
				vKGroup.screen_name = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("is_closed", out value4))
			{
				vKGroup.is_closed = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("deactivated", out value5))
			{
				vKGroup.deactivated = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("is_admin", out value6))
			{
				vKGroup.is_admin = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("admin_level", out value7))
			{
				vKGroup.admin_level = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("is_member", out value8))
			{
				vKGroup.is_member = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("type", out value9))
			{
				vKGroup.type = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("photo_50", out value10))
			{
				vKGroup.photo_50 = (string)value10;
			}
			object value11;
			if (dictionary.TryGetValue("photo_100", out value11))
			{
				vKGroup.photo_100 = (string)value11;
			}
			object value12;
			if (dictionary.TryGetValue("photo_200", out value12))
			{
				vKGroup.photo_200 = (string)value12;
			}
			object value13;
			if (dictionary.TryGetValue("city", out value13))
			{
				vKGroup.city = (long)value13;
			}
			object value14;
			if (dictionary.TryGetValue("country", out value14))
			{
				vKGroup.country = (long)value14;
			}
			object value15;
			if (dictionary.TryGetValue("place", out value15))
			{
				vKGroup.place = VKPlace.Deserialize(value15);
			}
			object value16;
			if (dictionary.TryGetValue("description", out value16))
			{
				vKGroup.description = (string)value16;
			}
			object value17;
			if (dictionary.TryGetValue("wiki_page", out value17))
			{
				vKGroup.wiki_page = (string)value17;
			}
			object value18;
			if (dictionary.TryGetValue("members_count", out value18))
			{
				vKGroup.members_count = (int)(long)value18;
			}
			object value19;
			if (dictionary.TryGetValue("counters", out value19))
			{
				vKGroup.counters = VKCounters.Deserialize(value19);
			}
			object value20;
			if (dictionary.TryGetValue("start_date", out value20))
			{
				vKGroup.start_date = (long)value20;
			}
			object value21;
			if (dictionary.TryGetValue("finish_date", out value21))
			{
				vKGroup.finish_date = (long)value21;
			}
			object value22;
			if (dictionary.TryGetValue("can_post", out value22))
			{
				vKGroup.can_post = (int)(long)value22;
			}
			object value23;
			if (dictionary.TryGetValue("can_see_all_posts", out value23))
			{
				vKGroup.can_see_all_posts = (int)(long)value23;
			}
			object value24;
			if (dictionary.TryGetValue("can_upload_doc", out value24))
			{
				vKGroup.can_upload_doc = (int)(long)value24;
			}
			object value25;
			if (dictionary.TryGetValue("can_create_topic", out value25))
			{
				vKGroup.can_create_topic = (int)(long)value25;
			}
			object value26;
			if (dictionary.TryGetValue("activity", out value26))
			{
				vKGroup.activity = (string)value26;
			}
			object value27;
			if (dictionary.TryGetValue("status", out value27))
			{
				vKGroup.status = (string)value27;
			}
			object value28;
			if (dictionary.TryGetValue("contacts", out value28))
			{
				vKGroup.contacts = (string)value28;
			}
			object value29;
			if (dictionary.TryGetValue("links", out value29))
			{
				vKGroup.links = (string)value29;
			}
			object value30;
			if (dictionary.TryGetValue("fixed_post", out value30))
			{
				vKGroup.fixed_post = (long)value30;
			}
			object value31;
			if (dictionary.TryGetValue("verified", out value31))
			{
				vKGroup.verified = (int)(long)value31;
			}
			object value32;
			if (dictionary.TryGetValue("site", out value32))
			{
				vKGroup.site = (string)value32;
			}
			return vKGroup;
		}
	}
}
