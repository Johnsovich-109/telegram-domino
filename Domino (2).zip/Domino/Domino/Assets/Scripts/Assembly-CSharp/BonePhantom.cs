using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BonePhantom : MonoBehaviour
{
	private const float Timeout = 0.2f;

	public Image image;

	public Color colorShow = Color.white;

	public Color colorHide = Color.clear;

	internal Transform node;

	private int coroutineSwithColor;

	public bool IsShow
	{
		get
		{
			return base.gameObject.activeSelf;
		}
		set
		{
			base.gameObject.SetActive(value);
		}
	}

	public float Scale
	{
		set
		{
			node.localScale = Vector3.one * value;
		}
	}

	public void Init()
	{
		node = base.transform;
	}

	public void Revert()
	{
		coroutineSwithColor = 0;
		IsShow = false;
	}

	public void Show()
	{
		IsShow = true;
		image.color = colorHide;
		StartCoroutine(SwitchColor(colorShow));
	}

	public void Show(Transform parent)
	{
		Show();
		Set(parent);
	}

	public void Hide(Action callback)
	{
		StartCoroutine(SwitchColor(colorHide, callback));
	}

	public void Set(Transform parent)
	{
		base.transform.SetParent(parent);
		base.transform.localPosition = Vector3.zero;
		base.transform.localScale = Vector3.one;
		base.transform.localRotation = Quaternion.identity;
	}

	private void Awake()
	{
	}

	private void Start()
	{
	}

	private IEnumerator SwitchColor(Color colorTo, Action callback = null)
	{
		float counterTime = 0f;
		Color colorFrom = image.color;
		int id = ++coroutineSwithColor;
		while (counterTime < 0.2f && id == coroutineSwithColor)
		{
			counterTime += Time.deltaTime;
			image.color = Color.Lerp(colorFrom, colorTo, counterTime / 0.2f);
			yield return null;
		}
		if (callback != null)
		{
			callback();
		}
	}
}
