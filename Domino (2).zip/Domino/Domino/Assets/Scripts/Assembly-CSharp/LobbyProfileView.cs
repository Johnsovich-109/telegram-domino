using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class LobbyProfileView : MonoBehaviour
{
	public Text textUsername;

	public AvatarView playerAvatar;

	public BalanceView balance;

	private string username;

	public string AvatarURL
	{
		get
		{
			return playerAvatar.AvatarURL;
		}
		set
		{
			playerAvatar.AvatarURL = value;
		}
	}

	public string Username
	{
		get
		{
			return textUsername.text;
		}
		set
		{
			if (value.Length == 0)
			{
				textUsername.text = TextManager.GetString("Player");
			}
			else
			{
				textUsername.text = Tools.Username(value, 15);
			}
		}
	}

	public int Balance
	{
		get
		{
			return balance.Balance;
		}
		set
		{
			balance.Balance = value;
		}
	}

	private void Awake()
	{
	}

	private void Start()
	{
		playerAvatar.ShowAvatar();
	}

	public void AddBalance(int balance)
	{
		this.balance.AddBalance(balance);
	}
}
