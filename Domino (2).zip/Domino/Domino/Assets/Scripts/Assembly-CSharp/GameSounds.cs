using System;
using System.Collections.Generic;
using UnityEngine;

public class GameSounds : MonoBehaviour
{
	public static GameSounds instance;

	public List<AudioSource> audioSources;

	private Dictionary<SoundType, AudioSource> dict;

	public static void Play(SoundType soundType)
	{
		if (instance != null)
		{
			instance.PlayInternal(soundType);
		}
	}

	public static AudioSource GetSource(SoundType soundType)
	{
		if (instance != null)
		{
			return instance.GetSourceInternal(soundType);
		}
		return null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		dict = new Dictionary<SoundType, AudioSource>();
		Add(SoundType.Button);
		Add(SoundType.GameOver);
		Add(SoundType.RoundOver);
		Add(SoundType.Scoring);
		Add(SoundType.Select);
		Add(SoundType.Skip);
		Add(SoundType.Tile);
		Add(SoundType.Timer);
	}

	private void OnDestroy()
	{
		instance = null;
	}

	private AudioSource GetSourceInternal(SoundType soundType)
	{
		return dict[soundType];
	}

	private void Reset()
	{
		audioSources = new List<AudioSource>(GetComponentsInChildren<AudioSource>());
	}

	private void PlayInternal(SoundType soundType)
	{
		dict[soundType].Play();
	}

	private void Add(SoundType soundType)
	{
		string soundName = soundType.ToString();
		AudioSource audioSource = audioSources.Find((AudioSource x) => x.name == soundName);
		if (audioSource == null)
		{
			throw new NullReferenceException();
		}
		dict.Add(soundType, audioSource);
	}
}
