using System;
using Dominoes;
using UnityEngine;


public class UnityAdsController : MonoBehaviour
{
	private string gameID = "1375726";


}
