public abstract class BaseGameState : BaseState, IState
{
	protected ChooseCanvas ChooseBlock
	{
		get
		{
			return ChooseCanvas.instance;
		}
	}

	protected ChooseGames ChooseGames
	{
		get
		{
			return ChooseCanvas.instance.chooseGames;
		}
	}

	protected ChoosePlayers ChoosePlayers
	{
		get
		{
			return ChooseCanvas.instance.choosePlayers;
		}
	}

	protected ChooseRate ChooseRates
	{
		get
		{
			return ChooseCanvas.instance.chooseRates;
		}
	}

	protected ChooseFriends ChooseFriends
	{
		get
		{
			return ChooseCanvas.instance.chooseFriends;
		}
	}

	protected GameCanvas GameCanvas
	{
		get
		{
			return GameCanvas.instance;
		}
	}

	protected HeapBox HeapView
	{
		get
		{
			return GameCanvas.instance.heap;
		}
	}

	protected PlayersManager PlayersView
	{
		get
		{
			return GameCanvas.instance.players;
		}
	}

	protected DeskView DeskView
	{
		get
		{
			return GameCanvas.instance.table;
		}
	}

	protected PanelBranchValues ScoreBranches
	{
		get
		{
			return GameCanvas.instance.branchValues;
		}
	}

	protected PopupsPlay PlayPopups
	{
		get
		{
			return PopupsPlay.instance;
		}
	}

	protected PopupsGeneral GeneralPopups
	{
		get
		{
			return PopupsGeneral.instance;
		}
	}

	protected GameMenuPopup MenuPopup
	{
		get
		{
			return PopupsPlay.instance.gameMenu;
		}
	}

	protected RulesPopup RulesPopup
	{
		get
		{
			return PopupsPlay.instance.rules;
		}
	}

	protected StatisticsPopup StatisticsPopup
	{
		get
		{
			return PopupsPlay.instance.statistics;
		}
	}

	protected MessagePopup Message
	{
		get
		{
			return PopupsPlay.instance.message;
		}
	}
}
