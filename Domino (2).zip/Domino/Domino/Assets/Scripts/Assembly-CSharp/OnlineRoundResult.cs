using System;
using Dominoes;
using ExitGames.Client.Photon;

public class OnlineRoundResult
{
	public bool IsBlocked;

	public int[] ScoreGame;

	public int[] ScoreRound;

	public int[] ScoreWon;

	public int[] ScoreMemory;

	public int RoundNext;

	public int[][] Opponents;

	private Hashtable hashtable;

	private object this[byte key]
	{
		get
		{
			return hashtable[key];
		}
	}

	public OnlineRoundResult(Hashtable hashtable, Func<int, int> function)
	{
		this.hashtable = hashtable;
		ScoreRound = (int[])this[0];
		IsBlocked = (bool)this[1];
		ScoreGame = (int[])this[2];
		RoundNext = (int)this[3];
		Opponents = (int[][])this[4];
		ScoreMemory = (int[])this[5];
		ScoreWon = (int[])this[6];
		TranslatorIndexes(function);
	}

	public OnlineRoundResult(GameSync sync)
	{
		ScoreRound = sync.scoresRound;
		ScoreGame = sync.scoresGame;
		ScoreWon = sync.scoresWon;
		ScoreMemory = sync.scoresMemory;
		Opponents = sync.idsBoneByPlayers;
	}

	private void TranslatorIndexes(Func<int, int> function)
	{
		ScoreGame = IndexTranslatorInArray(function, ScoreGame);
		ScoreRound = IndexTranslatorInArray(function, ScoreRound);
		ScoreWon = IndexTranslatorInArray(function, ScoreWon);
		ScoreMemory = IndexTranslatorInArray(function, ScoreMemory);
		Opponents = IndexTranslatorInArray(function, Opponents);
	}

	private int[] IndexTranslatorInArray(Func<int, int> function, int[] array)
	{
		int[] array2 = new int[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array2[function(i + 1)] = array[i];
		}
		return array2;
	}

	private int[][] IndexTranslatorInArray(Func<int, int> function, int[][] array)
	{
		int[][] array2 = new int[array.Length][];
		for (int i = 0; i < array.Length; i++)
		{
			array2[function(i + 1)] = array[i];
		}
		return array2;
	}
}
