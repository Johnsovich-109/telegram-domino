using System;
using System.Collections.Generic;
using System.Linq;

namespace Dominoes
{
	public abstract class GameManager : GameManagerTools, ISingleGame
	{
		protected Heap heap;

		protected Desk desk;

		protected PlayersController players;

		protected ScoreBranches scoreBranches;

		protected ScoresController scores;

		protected GameState state;

		protected Random random;

		protected int[] startDoubleArray;

		protected int finalScore;

		protected int numberBonesGive;

		protected int numberOfBranches;

		protected int numberOfBoneValues;

		public Heap Heap
		{
			get
			{
				return heap;
			}
			set
			{
				heap = value;
			}
		}

		public Desk Desk
		{
			get
			{
				return desk;
			}
		}

		public PlayersController Players
		{
			get
			{
				return players;
			}
		}

		public GameState State
		{
			get
			{
				return state;
			}
			set
			{
				state = value;
			}
		}

		public bool IsShowScoreBranches
		{
			get
			{
				return ScoreBranches != null;
			}
		}

		public ScoreBranches ScoreBranches
		{
			get
			{
				return scoreBranches;
			}
		}

		public ScoresController Scores
		{
			get
			{
				return scores;
			}
		}

		public int NumberOfBoneValues
		{
			get
			{
				return numberOfBoneValues;
			}
		}

		public int NumberOfBranches
		{
			get
			{
				return numberOfBranches;
			}
		}

		public int NumberBonesGive
		{
			get
			{
				return numberBonesGive;
			}
		}

		public int FinalScore
		{
			get
			{
				return finalScore;
			}
			set
			{
				finalScore = value;
			}
		}

		protected GameManager(int numberOfPlayers, int numberOfBranches, int numberOfBoneValues)
		{
			this.numberOfBranches = numberOfBranches;
			this.numberOfBoneValues = numberOfBoneValues;
			state = GameState.Start;
			heap = new Heap(numberOfBoneValues);
			desk = new Desk(numberOfBranches);
			players = new PlayersController(numberOfPlayers);
			scores = new ScoresController(players);
		}

		public virtual void NewRound()
		{
			heap.NewRound();
			desk.NewRound();
			players.NewRound();
			scores.NewRound();
			Distribution(numberBonesGive);
			GameStart();
			state = GameState.Play;
		}

		protected virtual void GameStart()
		{
			Player player = GetStartPlayerByDoubles(players, startDoubleArray);
			if (player == null)
			{
				player = GetStartPlayerByMaxBone(players);
			}
			players.Index = player.Id;
		}

		protected void Distribution(int numberBones)
		{
			for (int i = 0; i < players.Count; i++)
			{
				players[i].Push(heap.PullRandom(numberBones));
			}
		}

		public virtual Bone Adding()
		{
			if (heap.IsEmpty)
			{
				return null;
			}
			Bone bone = heap.PullRandom();
			players.Current.Add(bone);
			return bone;
		}

		public virtual GameState Play(Turn turn)
		{
			bool skip = turn.Skip;
			players.Current.Skip = skip;
			if (!skip)
			{
				players.Last = turn.player;
				turn.player.Pull(turn.MoveBone);
				desk.Play(turn);
			}
			return state = GetStateGame();
		}

		public virtual GameState Next()
		{
			players.Next();
			return state = GetStateGame();
		}

		public virtual GameState Surrender()
		{
			state = (GameState)50;
			return state;
		}

		public virtual GameState Scoring()
		{
			foreach (Player player in players)
			{
				player.Score.Bones = 0;
				foreach (Bone item in player)
				{
					player.Score.Bones += item.Value;
				}
				player.Score.Round = player.Score.Bones;
				player.Score.Game += player.Score.Round;
			}
			if (CheckGameOver())
			{
				state = (GameState)18;
			}
			return state;
		}

		public virtual bool CheckLocalWin()
		{
			return players.Local.Score.GameTotal >= finalScore;
		}

		public virtual void RoundOver()
		{
			scores.RoundOver(state);
		}

		public virtual bool CheckRetake()
		{
			return false;
		}

		public virtual Turn CreateTurn()
		{
			Turn turn = new Turn(players.Current);
			ListBone availablePlayer = GetAvailablePlayer();
			if (availablePlayer.Count == 0 && !heap.IsEmpty)
			{
				List<Branch> branchAvailable = desk.BranchAvailable;
				while (!heap.IsEmpty)
				{
					Bone addBone = heap.PullRandom();
					turn.adding.Add(addBone);
					if (branchAvailable.Exists((Branch x) => addBone.Pairing(x.head.value)))
					{
						availablePlayer.Add(addBone);
						break;
					}
				}
			}
			if (turn.adding.Count > 0)
			{
				turn.player.AddRange(turn.adding);
			}
			if (availablePlayer.Count == 0)
			{
				return turn;
			}
			Bone bone = availablePlayer.GetMaxBone();
			turn.moveBone.Add(bone);
			if (desk.IsEmpty)
			{
				turn.moveBranch.Add(0);
			}
			else
			{
				IEnumerable<Branch> collection = desk.Where((Branch x) => x.IsInit && bone.Pairing(x.head.value));
				turn.moveBranch.Add(Min(collection, (Branch x) => x.Count).id);
			}
			return turn;
		}

		public Turn CreateTurn(Bone tile)
		{
			Turn turn = new Turn(players.Current);
			turn.moveBone.Add(tile);
			turn.moveBranch.Add(0);
			return turn;
		}

		public Turn CreateTurn(Bone moveBone, Bone deskBone)
		{
			Turn turn = new Turn(players.Current);
			Branch branch = desk.Find((Branch x) => x.head.bone.Equals(deskBone) && x.Pairing(moveBone));
			turn.moveBone.Add(moveBone);
			turn.moveBranch.Add(branch.id);
			return turn;
		}

		public virtual GameState GetStateGame()
		{
			if (players.Exists((Player player) => player.IsEmpty))
			{
				return (GameState)6;
			}
			if (heap.IsEmpty && !players.Exists((Player player) => !player.Skip))
			{
				return (GameState)10;
			}
			return GameState.Play;
		}

		public virtual TurnData GetTurnData()
		{
			return new TurnData();
		}

		public virtual ListBone GetAvailablePlayer()
		{
			if (desk.IsEmpty)
			{
				int i;
				for (i = 0; i < startDoubleArray.Length; i++)
				{
					Bone bone = players.Current.Find((Bone x) => x.IsDouble && x.SideA == startDoubleArray[i]);
					if (bone != null)
					{
						return new ListBone(bone);
					}
				}
				return new ListBone(players.Current.GetMaxBone());
			}
			return GetAvailable(players.Current);
		}

		protected ListBone GetAvailable(Player player)
		{
			return new ListBone(player.Where((Bone x) => CheckAvailable(x)));
		}

		protected bool CheckAvailable(Bone bone)
		{
			return desk.BranchAvailable.Exists((Branch branch) => branch.Pairing(bone));
		}

		protected bool CheckGameOver()
		{
			return players.Exists((Player x) => x.Score.GameTotal >= finalScore);
		}
	}
}
