namespace Dominoes
{
	public class HeapOnline : Heap
	{
		public HeapOnline(int boneValues, int limit = 0)
			: base(boneValues, limit)
		{
		}

		public override void NewRound()
		{
			Clear();
			Bone item = new Bone(0, 0, 0);
			for (int i = 0; i < Heap.CountInCollection; i++)
			{
				Add(item);
			}
		}

		public ListBone PullBones(int[] ids)
		{
			ListBone listBone = new ListBone(ids.Length);
			for (int i = 0; i < ids.Length; i++)
			{
				listBone.Add(privateCollection[ids[i]]);
			}
			RemoveRange(0, listBone.Count);
			return listBone;
		}

		public Bone PullBone(int id)
		{
			Bone result = privateCollection[id];
			RemoveAt(0);
			return result;
		}

		public Bone GetBone(int id)
		{
			return privateCollection[id];
		}

		public ListBone GetBones(int[] ids)
		{
			if (ids == null)
			{
				return null;
			}
			ListBone listBone = new ListBone(ids.Length);
			for (int i = 0; i < ids.Length; i++)
			{
				listBone.Add(GetBone(ids[i]));
			}
			return listBone;
		}
	}
}
