using System.Collections.Generic;

public class ResponseInit : ResponseBase
{
	public readonly string username;

	public readonly string avatar;

	public readonly int balance;

	public readonly int second_balance;

	public readonly bool ad_enable;

	public readonly bool daily_bonus;

	public readonly int daily_bonus_level;

	public readonly int daily_reward;

	public readonly int bonus_timer;

	public readonly int exp;

	public readonly int lvl;

	public readonly int new_mail;

	public readonly int[] exps;

	public readonly int[] new_notification;

	public ResponseInit(Dictionary<string, object> dict)
		: base(dict)
	{
		object value;
		if (dict.TryGetValue("username", out value))
		{
			username = (string)value;
		}
		if (dict.TryGetValue("avatar", out value))
		{
			avatar = (string)value;
		}
		if (dict.TryGetValue("balance", out value))
		{
			balance = (int)(long)value;
		}
		if (dict.TryGetValue("second_balance", out value))
		{
			second_balance = (int)(long)value;
		}
		if (dict.TryGetValue("ad_enable", out value))
		{
			ad_enable = (bool)value;
		}
		if (dict.TryGetValue("daily_bonus", out value))
		{
			daily_bonus = (bool)value;
		}
		if (dict.TryGetValue("daily_bonus_level", out value))
		{
			daily_bonus_level = (int)(long)value;
		}
		if (dict.TryGetValue("daily_reward", out value))
		{
			daily_reward = (int)(long)value;
		}
		if (dict.TryGetValue("bonus_timer", out value))
		{
			bonus_timer = (int)(long)value;
		}
		if (dict.TryGetValue("exp", out value))
		{
			exp = (int)(long)value;
		}
		if (dict.TryGetValue("exps", out value))
		{
			exps = ToIntArray(value);
		}
		if (dict.TryGetValue("lvl", out value))
		{
			lvl = (int)(long)value;
		}
		if (dict.TryGetValue("new_mail", out value))
		{
			new_mail = (int)(long)value;
		}
		if (dict.TryGetValue("new_notification", out value))
		{
			new_notification = ToIntArray(value);
		}
	}

	private int[] ToIntArray(object obj)
	{
		List<object> list = (List<object>)obj;
		int[] array = new int[list.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (int)(long)list[i];
		}
		return array;
	}
}
