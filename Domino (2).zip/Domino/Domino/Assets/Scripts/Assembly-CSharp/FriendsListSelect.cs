using System;
using System.Collections.Generic;
using System.Linq;
using Dominoes;
using UnityEngine;

public class FriendsListSelect : MonoBehaviour
{
	public List<FriendsListItem> listFriends;

	public List<FriendsListItem> listRandomPlayer;

	private bool init;

	public int viewLimit = 20;

	private int sizeRoom;

	public int SizeRoom
	{
		get
		{
			return sizeRoom;
		}
		set
		{
			sizeRoom = value;
		}
	}

	public event Action<FriendData> OnFriendClick;

	public void Init()
	{
		if (init)
		{
			return;
		}
		foreach (FriendsListItem listFriend in listFriends)
		{
			listFriend.OnClick += Friend_OnClick;
			listFriend.Set(null);
		}
		init = true;
	}

	public void Set(List<FriendData> friendsList)
	{
		if (listFriends.Count == 0)
		{
			throw new Exception("The list friends was not initialized");
		}
		Init();
		if (friendsList == null)
		{
			HideAllItems();
		}
		else
		{
			RefreshItems(friendsList);
		}
	}

	public void Add(FriendData data)
	{
		FriendsListItem friendsListItem = listFriends.FindLast((FriendsListItem x) => !x.ActiveSelf);
		if (friendsListItem == null)
		{
			FriendsListItem friendsListItem2 = CreateFriendItem(listFriends[0]);
			friendsListItem2.Set(data);
		}
		else
		{
			friendsListItem.Set(data);
		}
		ShowRandom(sizeRoom - 1 - listFriends.Count((FriendsListItem x) => x.ActiveSelf));
	}

	public void Remove(FriendData data)
	{
		int num = listFriends.FindIndex((FriendsListItem x) => x.FriendData.id == data.id);
		if (num > -1)
		{
			listFriends[num].ActiveSelf = false;
		}
		ShowRandom(sizeRoom - 1 - listFriends.Count((FriendsListItem x) => x.ActiveSelf));
	}

	private void RefreshItems(List<FriendData> listData)
	{
		while (listFriends.Count < listData.Count && listFriends.Count < viewLimit)
		{
			CreateFriendItem(listFriends[0]);
		}
		while (listFriends.Count > viewLimit)
		{
			RemoveFriendItem(0);
		}
		for (int i = 0; i < listData.Count; i++)
		{
			listFriends[i].Set(listData[i]);
		}
		for (int j = listData.Count; j < listFriends.Count; j++)
		{
			listFriends[j].Set(null);
		}
		ShowRandom(sizeRoom - 1 - listData.Count);
	}

	private void HideAllItems()
	{
		for (int i = 0; i < listFriends.Count; i++)
		{
			listFriends[i].ActiveSelf = false;
		}
		ShowRandom(0);
	}

	private void ShowRandom(int count)
	{
		for (int i = 0; i < listRandomPlayer.Count; i++)
		{
			listRandomPlayer[i].gameObject.SetActive(i < count);
		}
	}

	private void Start()
	{
		string @string = TextManager.GetString("Random player");
		foreach (FriendsListItem item in listRandomPlayer)
		{
			item.textName.text = @string;
		}
		Init();
	}

	private FriendsListItem CreateFriendItem(FriendsListItem prototype)
	{
		FriendsListItem friendsListItem = UnityEngine.Object.Instantiate(prototype);
		friendsListItem.transform.SetParent(prototype.transform.parent);
		friendsListItem.transform.localScale = prototype.transform.localScale;
		friendsListItem.OnClick += Friend_OnClick;
		listFriends.Add(friendsListItem);
		return friendsListItem;
	}

	private void RemoveFriendItem(int index)
	{
		if (listFriends.Count > index)
		{
			FriendsListItem friendsListItem = listFriends[index];
			listFriends.RemoveAt(index);
			UnityEngine.Object.DestroyObject(friendsListItem.gameObject);
			return;
		}
		throw new IndexOutOfRangeException("The list of objects is empty");
	}

	private void Friend_OnClick(FriendData friendData)
	{
		if (this.OnFriendClick != null)
		{
			this.OnFriendClick(friendData);
		}
	}
}
