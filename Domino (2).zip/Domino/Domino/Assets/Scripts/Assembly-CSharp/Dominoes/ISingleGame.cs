namespace Dominoes
{
	public interface ISingleGame
	{
		Desk Desk { get; }

		Heap Heap { get; set; }

		bool IsShowScoreBranches { get; }

		PlayersController Players { get; }

		ScoreBranches ScoreBranches { get; }

		ScoresController Scores { get; }

		GameState State { get; set; }

		int NumberOfBoneValues { get; }

		int NumberOfBranches { get; }

		int NumberBonesGive { get; }

		int FinalScore { get; set; }

		Bone Adding();

		bool CheckRetake();

		bool CheckLocalWin();

		Turn CreateTurn();

		Turn CreateTurn(Bone tile);

		Turn CreateTurn(Bone moveBone, Bone deskBone);

		ListBone GetAvailablePlayer();

		GameState GetStateGame();

		TurnData GetTurnData();

		void NewRound();

		GameState Next();

		GameState Play(Turn turn);

		void RoundOver();

		GameState Scoring();

		GameState Surrender();
	}
}
