using System;
using System.Collections.Generic;

namespace Dominoes
{
	public class Responses
	{
		public ResponseInit init;

		public Dictionary<string, ResponseLeaderboard> lbs;

		public bool IsInit
		{
			get
			{
				return init != null;
			}
		}

		public Responses()
		{
			lbs = new Dictionary<string, ResponseLeaderboard>();
		}

		internal void Save()
		{
			throw new NotImplementedException();
		}
	}
}
