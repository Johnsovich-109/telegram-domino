using UnityEngine;

public class VKFriedImage
{
	public Texture2D Img;

	public long VKUserId;
}
