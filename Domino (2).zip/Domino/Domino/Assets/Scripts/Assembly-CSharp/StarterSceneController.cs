using UnityEngine;
using UnityEngine.SceneManagement;
using com.playGenesis.VkUnityPlugin;

public class StarterSceneController : MonoBehaviour
{
	public void Start()
	{
		if (!VkApi.VkApiInstance.IsUserLoggedIn)
		{
			VkApi.VkApiInstance.Login();
		}
	}

	public void TestCaptcha()
	{
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "captcha.force";
		vKRequest.CallBackFunction = OnCaptchaForse;
		VKRequest httprequest = vKRequest;
		VkApi.VkApiInstance.Call(httprequest);
	}

	private void OnCaptchaForse(VKRequest result)
	{
		if (result.error != null)
		{
			GlobalErrorHandler globalErrorHandler = Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(result);
			}
		}
		else
		{
			Debug.Log(result.response);
		}
	}

	public void SendNotificationToAdmin()
	{
		SceneManager.LoadScene("NotificationToAdmin");
	}

	public void FriendsGet()
	{
		SceneManager.LoadScene("Friends");
	}

	public void ShareScreenShot()
	{
		SceneManager.LoadScene("ScreenShotShareDemo");
	}

	public void Logout()
	{
		VkApi.VkApiInstance.Logout();
		SceneManager.LoadScene("LoginScene");
	}
}
