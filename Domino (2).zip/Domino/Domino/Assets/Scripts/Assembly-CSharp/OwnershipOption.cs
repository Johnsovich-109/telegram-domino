public enum OwnershipOption
{
	Fixed = 0,
	Takeover = 1,
	Request = 2
}
