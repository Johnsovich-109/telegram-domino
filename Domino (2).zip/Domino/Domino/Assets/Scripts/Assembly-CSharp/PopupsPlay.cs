using UnityEngine.UI;

public class PopupsPlay : CurtainManager
{
	public static PopupsPlay instance;

	public Image imageBackground;

	public GameMenuPopup gameMenu;

	public RulesPopup rules;

	public StatisticsPopup statistics;

	public GameOverPopup gameOver;

	public GameStartedPopup gameStarted;

	public MessagePopup message;

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		Reset();
	}
}
