using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Dominoes;
using ExitGames.Client.Photon;
using MiniJSON;
using Photon;
using UnityEngine;

public class PhotonClient : PunBehaviour
{
	[SerializeField]
	private PhotonStates currentState = PhotonStates.Disconnect;

	[SerializeField]
	private PhotonStates targetState = PhotonStates.Disconnect;

	private GameRoom room;

	private IOnlineGame manager;

	private float pingTimeout;

	private float pingInterval = 3f;

	private int pongCounter;

	private readonly int MaxPongDrop = 3;

	private int stepNumber;

	public PhotonStates TargetState
	{
		get
		{
			return targetState;
		}
		set
		{
			targetState = value;
		}
	}

	public PhotonStates CurrentState
	{
		get
		{
			return currentState;
		}
		set
		{
			if (currentState != value)
			{
				currentState = value;
				if (this.OnChangeState != null)
				{
					this.OnChangeState(targetState, currentState);
				}
			}
		}
	}

	public string DeviceUID
	{
		get
		{
			return MainSettings.DeviceUID;
		}
	}

	public ConnectionState ConnectState
	{
		get
		{
			return PhotonNetwork.connectionState;
		}
	}

	public event Action<PhotonResponse> OnLobbyChange;

	public event Action<PhotonStates, PhotonStates> OnChangeState;

	public event Action<PhotonResponse> OnResponse;

	public event Action<string> OnClientFailed;

	public event Action<string, object[]> OnRoomChange;

	internal void ConnectToMaster()
	{
		room = null;
		TargetState = PhotonStates.ToMaster;
	}

	internal void ConnectToLobby()
	{
		room = null;
		TargetState = PhotonStates.ToLobby;
	}

	internal void ConnectToGame(IOnlineGame manager, GameRoom room)
	{
		JoinRandomRoom(manager, room);
		TargetState = PhotonStates.ToGame;
	}

	private IEnumerator ObserverOfState()
	{
		while (true)
		{
			if (CurrentState == TargetState || CurrentState == PhotonStates.Connecting)
			{
				yield return null;
				continue;
			}
			switch (TargetState)
			{
			case PhotonStates.ToMaster:
				yield return StartCoroutine(InternalConnectToMaster());
				break;
			case PhotonStates.ToLobby:
				yield return StartCoroutine(InternalConnectToLobby());
				break;
			case PhotonStates.ToGame:
				yield return StartCoroutine(InternalConnectToGame());
				break;
			}
			yield return null;
		}
	}

	private IEnumerator InternalConnectToMaster()
	{
		switch (CurrentState)
		{
		case PhotonStates.Disconnect:
			yield return StartCoroutine(TryConnectTo(PhotonStates.ToMaster));
			break;
		case PhotonStates.ToLobby:
			LeaveLobby();
			break;
		case PhotonStates.ToGame:
			yield return StartCoroutine(LeavingRoom());
			break;
		}
	}

	private IEnumerator InternalConnectToLobby()
	{
		switch (CurrentState)
		{
		case PhotonStates.Disconnect:
			yield return StartCoroutine(ToLobbyFromDisconnect());
			break;
		case PhotonStates.ToMaster:
			yield return StartCoroutine(ToLobbyFromMaster());
			break;
		case PhotonStates.ToGame:
			yield return StartCoroutine(ToLobbyFromGame());
			break;
		}
	}

	private IEnumerator ToLobbyFromDisconnect()
	{
		yield return StartCoroutine(TryConnectTo(PhotonStates.ToLobby));
		JoinLobby();
	}

	private IEnumerator ToLobbyFromMaster()
	{
		JoinLobby();
		while (CurrentState == PhotonStates.Connecting)
		{
			yield return null;
		}
	}

	private IEnumerator ToLobbyFromGame()
	{
		yield return StartCoroutine(LeavingRoom());
		JoinLobby();
		while (CurrentState == PhotonStates.Connecting)
		{
			yield return null;
		}
	}

	private IEnumerator InternalConnectToGame()
	{
		switch (CurrentState)
		{
		case PhotonStates.Disconnect:
			yield return StartCoroutine(ToGameFromDisconnect());
			break;
		case PhotonStates.ToMaster:
			yield return StartCoroutine(ToGameFromMaster());
			break;
		case PhotonStates.ToLobby:
			yield return StartCoroutine(ToGameFromMaster());
			break;
		}
	}

	private IEnumerator ToGameFromDisconnect()
	{
		if (room == null)
		{
			yield return StartCoroutine(TryConnectTo(PhotonStates.ToGame));
			yield break;
		}
		yield return new WaitForSeconds(2f);
		PhotonNetwork.ReconnectAndRejoin();
		currentState = PhotonStates.Connecting;
		while (currentState != PhotonStates.Disconnect && currentState != PhotonStates.ToGame)
		{
			yield return null;
		}
	}

	private IEnumerator ToGameFromMaster()
	{
		JoinRandomRoom(manager, room);
		while (CurrentState == PhotonStates.Connecting)
		{
			yield return null;
		}
	}

	private IEnumerator TryConnectTo(PhotonStates target)
	{
		int counter = 0;
		do
		{
			if (counter++ > 0)
			{
				yield return new WaitForSeconds(1f);
			}
			CurrentState = PhotonStates.Connecting;
			PhotonNetwork.AuthValues = new AuthenticationValues(DeviceUID);
			PhotonNetwork.ConnectUsingSettings("1");
			while (CurrentState == PhotonStates.Connecting)
			{
				yield return null;
			}
		}
		while (TargetState == target && CurrentState != 0);
	}

	public override void OnConnectedToMaster()
	{
		CurrentState = PhotonStates.ToMaster;
	}

	public override void OnConnectionFail(DisconnectCause cause)
	{
		CurrentState = PhotonStates.Disconnect;
	}

	public override void OnConnectedToPhoton()
	{
	}

	public override void OnFailedToConnectToPhoton(DisconnectCause cause)
	{
		CurrentState = PhotonStates.Disconnect;
	}

	public override void OnDisconnectedFromPhoton()
	{
		CurrentState = PhotonStates.Disconnect;
	}

	internal void JoinLobby()
	{
		TypedLobby typedLobby = new TypedLobby("dominoes", LobbyType.SqlLobby);
		PhotonNetwork.JoinLobby(typedLobby);
		CurrentState = PhotonStates.Connecting;
	}

	internal void LeaveLobby()
	{
		if (currentState == PhotonStates.ToLobby)
		{
			PhotonNetwork.LeaveLobby();
			CurrentState = PhotonStates.ToMaster;
		}
	}

	public override void OnJoinedLobby()
	{
		CurrentState = PhotonStates.ToLobby;
		OpCustom(140, GetHT());
		SendLobbyChange("joined_lobby");
	}

	private void OnResponseHandler(OperationResponse response)
	{
		if (response.ReturnCode != 0)
		{
			return;
		}
		if (response.OperationCode == 249)
		{
			PingReceived();
			return;
		}
		short num = (short)response.Parameters[244];
		if (num == 140)
		{
			ExitGames.Client.Photon.Hashtable hashtable = response[245] as ExitGames.Client.Photon.Hashtable;
			ReceivedFriends(hashtable);
		}
	}

	private void PingReceived()
	{
		pingTimeout = 0f;
		pongCounter = 0;
	}

	private void ReceivedFriends(ExitGames.Client.Photon.Hashtable hashtable)
	{
		Dictionary<string, object> dictionary = Json.Deserialize(hashtable[(byte)1] as string) as Dictionary<string, object>;
		SendLobbyChange("received_friends", dictionary);
	}

	private string ToString(OperationResponse response)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("ReturnCode: " + response.ReturnCode);
		stringBuilder.AppendLine("OperationCode: " + response.OperationCode);
		stringBuilder.AppendLine("Parammetrs: ");
		foreach (KeyValuePair<byte, object> parameter in response.Parameters)
		{
			stringBuilder.AppendLine(parameter.Key + ": '" + parameter.Value.ToString() + "' [" + parameter.Value.GetType().Name + "] ");
		}
		return stringBuilder.ToString();
	}

	public void SendInvite(string[] ids)
	{
		int[] array = new int[ids.Length];
		int[] array2 = new int[ids.Length];
		for (int i = 0; i < ids.Length; i++)
		{
			array[i] = i + 2;
			array2[i] = int.Parse(ids[i]);
		}
		OpCustom(137, GetHT(array2, array));
	}

	private void OpCustom(short eventCode, ExitGames.Client.Photon.Hashtable param)
	{
		Dictionary<byte, object> dictionary = new Dictionary<byte, object>();
		dictionary[244] = eventCode;
		dictionary[245] = param;
		dictionary[252] = new int[1];
		PhotonNetwork.networkingPeer.OpCustom(100, dictionary, true);
	}

	private void SendLobbyChange(string message, params object[] args)
	{
		if (this.OnLobbyChange != null)
		{
			this.OnLobbyChange(new PhotonResponse(message, args));
		}
	}

	public void CreateRoom(IOnlineGame manager, GameRoom room)
	{
		this.room = room;
		this.manager = manager;
		CreateRoom(room);
		TargetState = PhotonStates.ToGame;
		CurrentState = PhotonStates.Connecting;
	}

	public void JoinFriendRoom(IOnlineGame manager, GameRoom room, RoomInvite invite)
	{
		this.room = room;
		this.manager = manager;
		PhotonNetwork.JoinRoom(invite.NameRoom);
		TargetState = PhotonStates.ToGame;
		CurrentState = PhotonStates.Connecting;
	}

	private void JoinRandomRoom(IOnlineGame manager, GameRoom room)
	{
		this.room = room;
		this.manager = manager;
		JoinRoom(room);
		CurrentState = PhotonStates.Connecting;
	}

	public override void OnPhotonRandomJoinFailed(object[] codeAndMsg)
	{
		Debug.Log("OnPhotonRandomJoinFailed " + codeAndMsg[1]);
		CreateRoom(room);
	}

	public override void OnPhotonJoinRoomFailed(object[] codeAndMsg)
	{
		Debug.Log(string.Concat("OnPhotonJoinRoomFailed ", codeAndMsg[1], " ", codeAndMsg[0]));
		SendFailed("join_room");
	}

	public override void OnOperationFailed(OperationResponse operationResponse)
	{
		Sync();
	}

	private void Awake()
	{
		PhotonNetwork.OnEventCall = (PhotonNetwork.EventCallback)Delegate.Combine(PhotonNetwork.OnEventCall, new PhotonNetwork.EventCallback(OnEventCallHandler));
		PhotonNetwork.OnResponse = (PhotonNetwork.EventResponseCallback)Delegate.Combine(PhotonNetwork.OnResponse, new PhotonNetwork.EventResponseCallback(OnResponseHandler));
	}

	private void Start()
	{
		StartCoroutine(ObserverOfState());
	}

	private void Update()
	{
		if (currentState == PhotonStates.ToGame && (pingTimeout += Time.deltaTime) >= pingInterval)
		{
			if (pongCounter >= MaxPongDrop)
			{
				Debug.Log("[" + DateTime.Now.TimeOfDay.ToString() + "]: PING DC: " + pongCounter);
				pongCounter = 0;
				PhotonNetwork.Disconnect();
			}
			else
			{
				PhotonNetwork.networkingPeer.OpCustom(249, new Dictionary<byte, object>(), true);
				pongCounter++;
			}
			pingTimeout = 0f;
		}
	}

	private void OnDestroy()
	{
		PhotonNetwork.OnEventCall = (PhotonNetwork.EventCallback)Delegate.Remove(PhotonNetwork.OnEventCall, new PhotonNetwork.EventCallback(OnEventCallHandler));
		PhotonNetwork.OnResponse = (PhotonNetwork.EventResponseCallback)Delegate.Remove(PhotonNetwork.OnResponse, new PhotonNetwork.EventResponseCallback(OnResponseHandler));
		PhotonNetwork.LeaveRoom();
	}

	private void SendFailed(string message)
	{
		if (this.OnClientFailed != null)
		{
			this.OnClientFailed(message);
		}
	}

	private void _LeaveRoom()
	{
		Debug.Log("Leave room...");
		if (room != null && PhotonNetwork.networkingPeer.State == ClientState.Joined)
		{
			PhotonNetwork.LeaveRoom();
			room.Leave();
		}
	}

	private IEnumerator LeavingRoom()
	{
		Debug.Log("Leaving room...");
		while (PhotonNetwork.networkingPeer.State == ClientState.Joining)
		{
			yield return null;
		}
		if (PhotonNetwork.networkingPeer.State == ClientState.Joined)
		{
			PhotonNetwork.LeaveRoom();
		}
		CurrentState = PhotonStates.ToMaster;
	}

	internal void Disconnect()
	{
		targetState = PhotonStates.Disconnect;
		room = null;
		PhotonNetwork.Disconnect();
	}

	internal void ReadyInGame(bool flag)
	{
		Debug.Log("Send ready");
		ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable();
		hashtable.Add("ready", flag);
		ExitGames.Client.Photon.Hashtable playerCustomProperties = hashtable;
		PhotonNetwork.SetPlayerCustomProperties(playerCustomProperties);
	}

	internal void ReadyEndRound()
	{
		Debug.Log("Send ready");
		ExitGames.Client.Photon.Hashtable hT = GetHT(9, GetHT());
		PhotonNetwork.RaiseEvent(10, hT, true, null);
	}

	internal void Add()
	{
		Debug.Log("Send add");
		ExitGames.Client.Photon.Hashtable hT = GetHT(12, GetHT(stepNumber++));
		PhotonNetwork.RaiseEvent(10, hT, true, null);
	}

	internal void Play(Bone moveBone, int moveBranch)
	{
		Debug.Log("Send play: " + moveBone.Id + " in " + moveBranch + " branch.");
		ExitGames.Client.Photon.Hashtable hT = GetHT(11, GetHT(moveBone.Id, moveBranch, stepNumber++));
		PhotonNetwork.RaiseEvent(10, hT, true, null);
	}

	internal void Skip()
	{
		Debug.Log("Send skip");
		ExitGames.Client.Photon.Hashtable hT = GetHT(13, GetHT(stepNumber++));
		PhotonNetwork.RaiseEvent(10, hT, true, null);
	}

	internal void Sync()
	{
		Debug.Log("Send sync");
		ExitGames.Client.Photon.Hashtable hT = GetHT();
		PhotonNetwork.RaiseEvent(12, hT, true, null);
	}

	private ExitGames.Client.Photon.Hashtable GetHT(params object[] args)
	{
		ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable(args.Length);
		for (byte b = 0; b < args.Length; b++)
		{
			hashtable.Add(b, args[b]);
		}
		return hashtable;
	}

	private void OnEventCallHandler(byte eventCode, object content, int senderId)
	{
		ExitGames.Client.Photon.Hashtable hashtable = (ExitGames.Client.Photon.Hashtable)content;
		EventCallHandletToString(eventCode, senderId, hashtable);
		int senderId2 = IndexTranslator(senderId);
		switch (eventCode)
		{
		case 10:
			GameCommand(hashtable, senderId2);
			break;
		case 30:
			Method_Start(hashtable, senderId2);
			break;
		case 12:
			Method_Sync(hashtable);
			break;
		case 50:
			Method_GameOver(hashtable, senderId);
			break;
		}
	}

	private void EventCallHandletToString(byte eventCode, int senderId, ExitGames.Client.Photon.Hashtable hashtable)
	{
		StringBuilder stringBuilder = new StringBuilder("OnEventCallHandler\n");
		stringBuilder.AppendFormat("Network OnEvent - code: {0}; SenderId: {1} (Real {2});\n", eventCode, senderId, IndexTranslator(senderId));
		stringBuilder.AppendLine(" --- HASHTABLE --- ");
		stringBuilder.AppendLine(HashtableToString(hashtable));
	}

	private void GameCommand(ExitGames.Client.Photon.Hashtable properties, int senderId)
	{
		if (properties.ContainsKey((byte)0))
		{
			int num = (int)properties[(byte)0];
			ExitGames.Client.Photon.Hashtable hashtable = (ExitGames.Client.Photon.Hashtable)properties[(byte)1];
			switch (num)
			{
			case 11:
				Method_Place(hashtable, senderId);
				break;
			case 13:
				Method_Skip(hashtable, senderId);
				break;
			case 32:
				Method_Add(hashtable, senderId);
				break;
			case 35:
				Method_RoundOver(hashtable, senderId);
				break;
			}
		}
	}

	private void Method_Start(ExitGames.Client.Photon.Hashtable properties, int senderId)
	{
		int[] ids = properties[0] as int[];
		int index = (int)properties[1];
		DominoSettings.TimeForTurn = (int)properties[2];
		manager.OnlineStart(ids, IndexTranslator(index), PhotonNetwork.player.ID);
		SendResponse("start_game");
	}

	private void Method_Place(ExitGames.Client.Photon.Hashtable properties, int senderId)
	{
		int boneId = (int)properties[(byte)0];
		int branch = (int)properties[(byte)1];
		manager.OnlinePlay(boneId, branch, senderId);
		SendResponse("place");
	}

	private void Method_Add(ExitGames.Client.Photon.Hashtable hashtable, int senderId)
	{
		int[] ids = (int[])hashtable[(byte)0];
		int count = (int)hashtable[(byte)1];
		int index = (int)hashtable[(byte)2];
		manager.OnlineAdd(ids, count, IndexTranslator(index));
		SendResponse("add");
	}

	private void Method_Skip(ExitGames.Client.Photon.Hashtable hashtable, int senderId)
	{
		manager.OnlineSkip(senderId);
		SendResponse("skip");
	}

	private void Method_Sync(ExitGames.Client.Photon.Hashtable hashtable)
	{
		if (hashtable != null && hashtable.Count >= 10)
		{
			GameSync gameSync = new GameSync(hashtable, IndexTranslator);
			manager.OnlineSync(gameSync);
			if (gameSync.IsRoundOver && !gameSync.IsGameOver)
			{
				OnlineRoundResult data = new OnlineRoundResult(gameSync);
				manager.OnlineRoundOver(data);
			}
			SendResponse("sync");
		}
	}

	private void Method_RoundOver(ExitGames.Client.Photon.Hashtable hashtable, int senderId)
	{
		OnlineRoundResult data = new OnlineRoundResult(hashtable, IndexTranslator);
		manager.OnlineRoundOver(data);
		SendResponse("round_over");
	}

	private void Method_GameOver(ExitGames.Client.Photon.Hashtable hashtable, int senderId)
	{
		OnlineGameResult data = new OnlineGameResult(hashtable, IndexTranslator);
		manager.OnlineGameOver(data);
		SendResponse("game_over");
	}

	private int IndexTranslator(int index)
	{
		int count = manager.Players.Count;
		return (index - PhotonNetwork.player.ID + count) % count;
	}

	private int[] IndexTranslatorInArray(int[] array)
	{
		int[] array2 = new int[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array2[IndexTranslator(i + 1)] = array[i];
		}
		return array2;
	}

	private int[][] IndexTranslatorInArray(int[][] array)
	{
		int[][] array2 = new int[array.Length][];
		for (int i = 0; i < array.Length; i++)
		{
			array2[IndexTranslator(i + 1)] = array[i];
		}
		return array2;
	}

	private void SendResponse(string message)
	{
		if (this.OnResponse != null)
		{
			this.OnResponse(new PhotonResponse(message));
		}
	}

	private static string HashtableToString(ExitGames.Client.Photon.Hashtable properties)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (DictionaryEntry property in properties)
		{
			stringBuilder.Append(string.Concat(property.Key, ":\t\t"));
			if (property.Value == null)
			{
				stringBuilder.AppendLine("Is null");
			}
			else if (property.Value is int[])
			{
				stringBuilder.AppendLine(Utils.ToString(property.Value as int[]));
			}
			else if (property.Value is string[])
			{
				stringBuilder.AppendLine(Utils.ToString(property.Value as string[]));
			}
			else if (property.Value is int[][])
			{
				stringBuilder.AppendLine(Utils.ToString(property.Value as int[][]));
			}
			else
			{
				stringBuilder.AppendLine(property.Value.ToString());
			}
		}
		return stringBuilder.ToString();
	}

	private void CreateRoom(GameRoom room)
	{
		RoomOptions roomOptions = new RoomOptions();
		roomOptions.MaxPlayers = (byte)room.Size;
		roomOptions.CustomRoomProperties = new ExitGames.Client.Photon.Hashtable
		{
			{ "C0", room.Bet },
			{ "C1", room.FriendGame },
			{ "C2", room.Size },
			{ "C3", room.NameOnline },
			{ "logicName", "dominoes" }
		};
		roomOptions.CustomRoomPropertiesForLobby = new string[4] { "C0", "C1", "C2", "C3" };
		PhotonNetwork.CreateRoom(string.Empty, roomOptions, PhotonNetwork.lobby);
	}

	private void JoinRoom(GameRoom game)
	{
		string sqlLobbyFilter = string.Format("C0 = {0} AND C1 = {1} AND C2 = {2} AND C3 = '{3}'", game.Bet, game.FriendGame, game.Size, game.NameOnline);
		ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable();
		hashtable.Add("cacheIndex", 2);
		ExitGames.Client.Photon.Hashtable expectedCustomRoomProperties = hashtable;
		PhotonNetwork.JoinRandomRoom(expectedCustomRoomProperties, 4, MatchmakingMode.RandomMatching, PhotonNetwork.lobby, sqlLobbyFilter);
	}

	public override void OnJoinedRoom()
	{
		SendEvent("room_joined");
		CurrentState = PhotonStates.ToGame;
	}

	public override void OnCreatedRoom()
	{
		Debug.Log("OnCreatedRoom ");
		SendEvent("room_created");
		CurrentState = PhotonStates.ToGame;
	}

	public override void OnPhotonPlayerConnected(PhotonPlayer newPlayer)
	{
		Debug.Log("ID new player : " + IndexTranslator(newPlayer.ID));
		DebugF.Log("OnPlayerConnected count = {0} index = {1} name = {2} room.playerCount {3}", PhotonNetwork.playerList.Length, newPlayer.ID, newPlayer.NickName, PhotonNetwork.room.PlayerCount);
		SendEvent("player_conected", IndexTranslator(newPlayer.ID));
		if (room != null)
		{
			room.PlayerConnected(newPlayer);
		}
		CurrentState = PhotonStates.ToGame;
	}

	public override void OnPhotonPlayerDisconnected(PhotonPlayer otherPlayer)
	{
		Debug.Log("ID new player : " + IndexTranslator(otherPlayer.ID));
		DebugF.Log("OnPlayerDisconnected count = {0} index = {1} name = {2}", PhotonNetwork.playerList.Length, otherPlayer.ID, otherPlayer.NickName);
		SendEvent("player_disconected", IndexTranslator(otherPlayer.ID));
		if (room != null)
		{
			room.PlayerDisconnected(otherPlayer);
		}
		CurrentState = PhotonStates.ToGame;
	}

	public override void OnPhotonPlayerPropertiesChanged(object[] playerAndUpdatedProps)
	{
		PhotonPlayer photonPlayer = playerAndUpdatedProps[0] as PhotonPlayer;
		ExitGames.Client.Photon.Hashtable hashtable = playerAndUpdatedProps[1] as ExitGames.Client.Photon.Hashtable;
		string text = hashtable["state"] as string;
		if (text != null && room != null)
		{
			room.PlayerChanged(text, photonPlayer, hashtable);
			SendEvent("property_changed", IndexTranslator(photonPlayer.ID));
		}
		CurrentState = PhotonStates.ToGame;
	}

	public override void OnPhotonPlayerActivityChanged(PhotonPlayer otherPlayer)
	{
		if (room != null)
		{
			room.ActivityChanged(otherPlayer);
		}
		SendEvent("activity_changed", IndexTranslator(otherPlayer.ID));
		CurrentState = PhotonStates.ToGame;
	}

	private void SendEvent(string message, params object[] args)
	{
		if (this.OnRoomChange != null)
		{
			this.OnRoomChange(message, args);
		}
	}
}
