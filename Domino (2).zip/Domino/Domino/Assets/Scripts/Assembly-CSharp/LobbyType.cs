public enum LobbyType : byte
{
	Default = 0,
	SqlLobby = 2,
	AsyncRandomLobby = 3
}
