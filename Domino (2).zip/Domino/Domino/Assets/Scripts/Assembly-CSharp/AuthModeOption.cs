public enum AuthModeOption
{
	Auth = 0,
	AuthOnce = 1,
	AuthOnceWss = 2
}
