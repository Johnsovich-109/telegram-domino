public class StatisticItem
{
	public int start;

	public int finish;

	public int win;

	public int loss;

	public void Parse(string raw)
	{
		if (raw.Length > 0)
		{
			string[] array = raw.Split(':');
			start = int.Parse(array[0]);
			finish = int.Parse(array[1]);
			win = int.Parse(array[2]);
			loss = int.Parse(array[3]);
		}
	}

	public override string ToString()
	{
		return start + ":" + finish + ":" + win + ":" + loss;
	}
}
