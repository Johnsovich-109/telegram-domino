using System;
using System.Collections;
using Dominoes;
using GoogleMobileAds.Api;
using UnityEngine;

public class AdmobController : MonoBehaviour
{
	private string idInterstitial = "ca-app-pub-1424848282703659/4400478128";

	private InterstitialAd interstitial;

	private bool buisy;

	private bool waitForReload;

	public event Action<string> OnAds;

	public void Load()
	{
		InitAds();
		LoadInternal();
	}

	public void Show()
	{
		Debug.Log((interstitial != null) ? interstitial.IsLoaded().ToString() : "Interstitial NULL");
		if (interstitial != null && interstitial.IsLoaded() && PlayerPrefs.GetInt("ad_enable", 1) == 1)
		{
			interstitial.Show();
			return;
		}
		DestroyAds();
		SendActiveLogic("end_interstitial_not_loaded");
	}

	private void Start()
	{
		StartCoroutine(Tools.Pause(2.5f, Load));
	}

	private void LoadInternal()
	{
		if (interstitial != null && !interstitial.IsLoaded())
		{
			interstitial.LoadAd(new AdRequest.Builder().Build());
		}
	}

	private void InitAds()
	{
		if (interstitial != null)
		{
			DestroyAds();
		}
		interstitial = new InterstitialAd(idInterstitial);
		interstitial.OnAdClosed += Interstitial_OnAdClosed;
		interstitial.OnAdFailedToLoad += Interstitial_OnAdFailedToLoad;
	}

	private void DestroyAds()
	{
		if (interstitial != null)
		{
			interstitial.OnAdClosed -= Interstitial_OnAdClosed;
			interstitial.OnAdFailedToLoad -= Interstitial_OnAdFailedToLoad;
			interstitial.Destroy();
			interstitial = null;
		}
	}

	private IEnumerator PauseBeforeReload()
	{
		if (!buisy)
		{
			buisy = true;
			yield return new WaitForSeconds(20f);
			LoadInternal();
			buisy = false;
		}
	}

	private void SendActiveLogic(string message)
	{
		if (this.OnAds != null)
		{
			this.OnAds(message);
		}
	}

	private void Interstitial_OnAdClosed(object sender, EventArgs e)
	{
		DestroyAds();
		Analytics.InterstitialShowed();
		SendActiveLogic("end_interstitial_showed");
		StartCoroutine(Tools.Pause(5f, Load));
	}

	private void Interstitial_OnAdFailedToLoad(object sender, AdFailedToLoadEventArgs e)
	{
		Debug.Log("Interstitial event: AdFailedToLoad: " + e.Message);
		StartCoroutine(PauseBeforeReload());
	}
}
