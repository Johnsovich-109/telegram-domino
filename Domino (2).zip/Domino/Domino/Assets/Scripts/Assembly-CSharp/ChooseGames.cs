using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ChooseGames : PopupBehaviour
{
	public List<ChooseGameItem> chooseItems;

	public Text textTitle;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<bool> OnChangeView;

	public event Action<GameInfo> OnChooseGame;

	public event Action<string> OnButtonClick;

	public void Show(GameInfo[] games)
	{
		Show();
		SetChoiceItems(games);
	}

	public override void Show()
	{
		base.ActiveSelf = true;
		base.Show();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}

	private void Start()
	{
		foreach (ChooseGameItem chooseItem in chooseItems)
		{
			Adding(chooseItem);
		}
		Title = TextManager.GetString("Choose game");
		base.ActiveSelf = false;
	}

	protected override void OnShowed()
	{
		if (this.OnChangeView != null)
		{
			this.OnChangeView(true);
		}
	}

	protected override void OnHidden()
	{
		base.ActiveSelf = false;
		if (this.OnChangeView != null)
		{
			this.OnChangeView(false);
		}
	}

	private void SetChoiceItems(GameInfo[] games)
	{
		List<ChooseGameItem> collection = AlignGameItems(games.Length);
		Stack<ChooseGameItem> stack = new Stack<ChooseGameItem>(collection);
		foreach (GameInfo info in games)
		{
			stack.Pop().Info = info;
		}
	}

	private List<ChooseGameItem> AlignGameItems(int countEnable)
	{
		if (countEnable < 1)
		{
			throw new Exception("Invalid number: " + countEnable);
		}
		while (chooseItems.Count < countEnable)
		{
			ChooseGameItem item = Create(chooseItems[0]);
			chooseItems.Add(item);
			Adding(item);
		}
		while (chooseItems.Count > countEnable)
		{
			Remove(chooseItems[0]);
			chooseItems.RemoveAt(0);
		}
		return chooseItems;
	}

	private void Adding(ChooseGameItem item)
	{
		item.OnChoose += ChooseGameItem_OnButtonClick;
	}

	private void Remove(ChooseGameItem item)
	{
		item.OnChoose -= ChooseGameItem_OnButtonClick;
		UnityEngine.Object.DestroyObject(item.gameObject);
	}

	private ChooseGameItem Create(ChooseGameItem prototype)
	{
		ChooseGameItem chooseGameItem = UnityEngine.Object.Instantiate(prototype);
		chooseGameItem.transform.SetParent(prototype.transform.parent);
		chooseGameItem.transform.localScale = prototype.transform.localScale;
		return chooseGameItem;
	}

	private void ChooseGameItem_OnButtonClick(ChooseGameItem sender)
	{
		if (this.OnChooseGame != null)
		{
			this.OnChooseGame(sender.Info);
		}
	}
}
