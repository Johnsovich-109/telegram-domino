using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKMessage
	{
		private string _action = string.Empty;

		public long id { get; set; }

		public long user_id { get; set; }

		public long date { get; set; }

		public int read_state { get; set; }

		public int @out { get; set; }

		public string title { get; set; }

		public string body { get; set; }

		public List<VKAttachment> attachments { get; set; }

		public VKGeo geo { get; set; }

		public List<VKMessage> fwd_messages { get; set; }

		public int emoji { get; set; }

		public int important { get; set; }

		public int deleted { get; set; }

		public long chat_id { get; set; }

		public List<long> chat_active { get; set; }

		public int users_count { get; set; }

		public long admin_id { get; set; }

		public VKPushSettings push_settings { get; set; }

		public string action
		{
			get
			{
				return _action;
			}
			set
			{
				_action = value ?? string.Empty;
			}
		}

		public long action_mid { get; set; }

		public string action_email { get; set; }

		public string action_text { get; set; }

		public string photo_50 { get; set; }

		public string photo_100 { get; set; }

		public string photo_200 { get; set; }

		public static VKMessage Deserialize(object message)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)message;
			VKMessage vKMessage = new VKMessage();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKMessage.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("user_id", out value2))
			{
				vKMessage.user_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("date", out value3))
			{
				vKMessage.date = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("read_state", out value4))
			{
				vKMessage.read_state = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("out", out value5))
			{
				vKMessage.@out = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("title", out value6))
			{
				vKMessage.title = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("body", out value7))
			{
				vKMessage.body = (string)value7;
			}
			object value8;
			if (dictionary.TryGetValue("attachments", out value8))
			{
				List<VKAttachment> list = new List<VKAttachment>();
				List<object> list2 = (List<object>)value8;
				foreach (object item in list2)
				{
					list.Add(VKAttachment.Deserialize(item));
				}
				vKMessage.attachments = list;
			}
			object value9;
			if (dictionary.TryGetValue("geo", out value9))
			{
				vKMessage.geo = VKGeo.Deserialize(value9);
			}
			object value10;
			if (dictionary.TryGetValue("fwd_messages", out value10))
			{
				List<VKMessage> list3 = new List<VKMessage>();
				List<VKMessage> list4 = (List<VKMessage>)value10;
				foreach (VKMessage item2 in list4)
				{
					list3.Add(Deserialize(item2));
				}
				vKMessage.fwd_messages = list3;
			}
			object value11;
			if (dictionary.TryGetValue("emoji", out value11))
			{
				vKMessage.emoji = (int)(long)value11;
			}
			object value12;
			if (dictionary.TryGetValue("important", out value12))
			{
				vKMessage.important = (int)(long)value12;
			}
			object value13;
			if (dictionary.TryGetValue("deleted", out value13))
			{
				vKMessage.deleted = (int)(long)value13;
			}
			object value14;
			if (dictionary.TryGetValue("chat_id", out value14))
			{
				vKMessage.chat_id = (long)value14;
			}
			object value15;
			if (dictionary.TryGetValue("chat_active", out value15))
			{
				vKMessage.chat_active = new List<long>();
				foreach (object item3 in (List<object>)value15)
				{
					vKMessage.chat_active.Add((long)item3);
				}
			}
			object value16;
			if (dictionary.TryGetValue("users_count", out value16))
			{
				vKMessage.users_count = (int)(long)value16;
			}
			object value17;
			if (dictionary.TryGetValue("admin_id", out value17))
			{
				vKMessage.admin_id = (long)value17;
			}
			object value18;
			if (dictionary.TryGetValue("push_settings", out value18))
			{
				vKMessage.push_settings = VKPushSettings.Deserialize(value18);
			}
			object value19;
			if (dictionary.TryGetValue("action", out value19))
			{
				vKMessage.action = (string)value19;
			}
			object value20;
			if (dictionary.TryGetValue("action_mid", out value20))
			{
				vKMessage.action_mid = (long)value20;
			}
			object value21;
			if (dictionary.TryGetValue("action_email", out value21))
			{
				vKMessage.action_email = (string)value21;
			}
			object value22;
			if (dictionary.TryGetValue("action_text", out value22))
			{
				vKMessage.action_text = (string)value22;
			}
			object value23;
			if (dictionary.TryGetValue("photo_50", out value23))
			{
				vKMessage.photo_50 = (string)value23;
			}
			object value24;
			if (dictionary.TryGetValue("photo_100", out value24))
			{
				vKMessage.photo_100 = (string)value24;
			}
			object value25;
			if (dictionary.TryGetValue("photo_200", out value25))
			{
				vKMessage.photo_200 = (string)value25;
			}
			return vKMessage;
		}
	}
}
