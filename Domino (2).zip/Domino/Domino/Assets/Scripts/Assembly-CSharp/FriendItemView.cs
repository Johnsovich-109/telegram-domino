using System;
using UnityEngine.UI;

public class FriendItemView : GameBehaviour
{
	public Text textName;

	public AvatarView avatar;

	private UserProfile friendData;

	public string Username
	{
		get
		{
			return textName.text;
		}
		set
		{
			textName.text = value;
		}
	}

	public UserProfile FriendData
	{
		get
		{
			return friendData;
		}
		set
		{
			friendData = value;
			base.ActiveSelf = value != null;
			if (value != null)
			{
				Username = value.username;
				avatar.AvatarURL = value.avatar;
			}
		}
	}

	public event Action<UserProfile> OnClick;

	public void ButtonClick()
	{
		if (this.OnClick != null)
		{
			this.OnClick(FriendData);
		}
	}

	public void Set(UserProfile data)
	{
		FriendData = data;
	}
}
