using System;
using System.Collections.Generic;
using OneSignalPush.MiniJSON;
using UnityEngine;

public class OneSignal : MonoBehaviour
{
	public delegate void NotificationReceived(OSNotification notification);

	public delegate void NotificationOpened(OSNotificationOpenedResult result);

	public delegate void IdsAvailableCallback(string playerID, string pushToken);

	public delegate void TagsReceived(Dictionary<string, object> tags);

	public delegate void PromptForPushNotificationsUserResponse(bool accepted);

	public delegate void OnPostNotificationSuccess(Dictionary<string, object> response);

	public delegate void OnPostNotificationFailure(Dictionary<string, object> response);

	public delegate void PermissionObservable(OSPermissionStateChanges stateChanges);

	public delegate void SubscriptionObservable(OSSubscriptionStateChanges stateChanges);

	public enum LOG_LEVEL
	{
		NONE = 0,
		FATAL = 1,
		ERROR = 2,
		WARN = 3,
		INFO = 4,
		DEBUG = 5,
		VERBOSE = 6
	}

	public enum OSInFocusDisplayOption
	{
		None = 0,
		InAppAlert = 1,
		Notification = 2
	}

	public class UnityBuilder
	{
		public string appID;

		public string googleProjectNumber;

		public Dictionary<string, bool> iOSSettings;

		public NotificationReceived notificationReceivedDelegate;

		public NotificationOpened notificationOpenedDelegate;

		public UnityBuilder HandleNotificationReceived(NotificationReceived inNotificationReceivedDelegate)
		{
			notificationReceivedDelegate = inNotificationReceivedDelegate;
			return this;
		}

		public UnityBuilder HandleNotificationOpened(NotificationOpened inNotificationOpenedDelegate)
		{
			notificationOpenedDelegate = inNotificationOpenedDelegate;
			return this;
		}

		public UnityBuilder InFocusDisplaying(OSInFocusDisplayOption display)
		{
			inFocusDisplayType = display;
			return this;
		}

		public UnityBuilder Settings(Dictionary<string, bool> settings)
		{
			return this;
		}

		public void EndInit()
		{
			Init();
		}
	}

	public static IdsAvailableCallback idsAvailableDelegate;

	public static TagsReceived tagsReceivedDelegate;

	private static PromptForPushNotificationsUserResponse notificationUserResponseDelegate;

	private static PermissionObservable internalPermissionObserver;

	private static bool addedPermissionObserver;

	private static SubscriptionObservable internalSubscriptionObserver;

	private static bool addedSubscriptionObserver;

	public const string kOSSettingsAutoPrompt = "kOSSettingsAutoPrompt";

	public const string kOSSettingsInAppLaunchURL = "kOSSettingsInAppLaunchURL";

	internal static UnityBuilder builder;

	private static OneSignalPlatform oneSignalPlatform;

	private const string gameObjectName = "OneSignalRuntimeObject_KEEP";

	private static LOG_LEVEL logLevel = LOG_LEVEL.INFO;

	private static LOG_LEVEL visualLogLevel;

	internal static OnPostNotificationSuccess postNotificationSuccessDelegate;

	internal static OnPostNotificationFailure postNotificationFailureDelegate;

	private static OSInFocusDisplayOption _inFocusDisplayType = OSInFocusDisplayOption.InAppAlert;

	public static OSInFocusDisplayOption inFocusDisplayType
	{
		get
		{
			return _inFocusDisplayType;
		}
		set
		{
			_inFocusDisplayType = value;
			if (oneSignalPlatform != null)
			{
				oneSignalPlatform.SetInFocusDisplaying(_inFocusDisplayType);
			}
		}
	}

	public static event PermissionObservable permissionObserver
	{
		add
		{
			if (oneSignalPlatform != null)
			{
				internalPermissionObserver = (PermissionObservable)Delegate.Combine(internalPermissionObserver, value);
				addPermissionObserver();
			}
		}
		remove
		{
			if (oneSignalPlatform != null)
			{
				internalPermissionObserver = (PermissionObservable)Delegate.Remove(internalPermissionObserver, value);
				if (addedPermissionObserver && internalPermissionObserver.GetInvocationList().Length == 0)
				{
					addedPermissionObserver = false;
					oneSignalPlatform.removePermissionObserver();
				}
			}
		}
	}

	public static event SubscriptionObservable subscriptionObserver
	{
		add
		{
			if (oneSignalPlatform != null)
			{
				internalSubscriptionObserver = (SubscriptionObservable)Delegate.Combine(internalSubscriptionObserver, value);
				addSubscriptionObserver();
			}
		}
		remove
		{
			if (oneSignalPlatform != null)
			{
				internalSubscriptionObserver = (SubscriptionObservable)Delegate.Remove(internalSubscriptionObserver, value);
				if (addedSubscriptionObserver && internalSubscriptionObserver.GetInvocationList().Length == 0)
				{
					oneSignalPlatform.removeSubscriptionObserver();
				}
			}
		}
	}

	private static void addPermissionObserver()
	{
		if (!addedPermissionObserver && internalPermissionObserver != null && internalPermissionObserver.GetInvocationList().Length > 0)
		{
			addedPermissionObserver = true;
			oneSignalPlatform.addPermissionObserver();
		}
	}

	private static void addSubscriptionObserver()
	{
		if (!addedSubscriptionObserver && internalSubscriptionObserver != null && internalSubscriptionObserver.GetInvocationList().Length > 0)
		{
			addedSubscriptionObserver = true;
			oneSignalPlatform.addSubscriptionObserver();
		}
	}

	public static UnityBuilder StartInit(string appID, string googleProjectNumber = null)
	{
		if (builder == null)
		{
			builder = new UnityBuilder();
		}
		builder.appID = appID;
		builder.googleProjectNumber = googleProjectNumber;
		return builder;
	}

	private static void Init()
	{
		initOneSignalPlatform();
	}

	private static void initOneSignalPlatform()
	{
		if (oneSignalPlatform == null && builder != null)
		{
			initAndroid();
			GameObject gameObject = new GameObject("OneSignalRuntimeObject_KEEP");
			gameObject.AddComponent<OneSignal>();
			UnityEngine.Object.DontDestroyOnLoad(gameObject);
			addPermissionObserver();
			addSubscriptionObserver();
		}
	}

	private static void initAndroid()
	{
		oneSignalPlatform = new OneSignalAndroid("OneSignalRuntimeObject_KEEP", builder.googleProjectNumber, builder.appID, inFocusDisplayType, logLevel, visualLogLevel);
	}

	private static void initUnityEditor()
	{
		MonoBehaviour.print("Please run OneSignal on a device to see push notifications.");
	}

	public static void SetLogLevel(LOG_LEVEL inLogLevel, LOG_LEVEL inVisualLevel)
	{
		logLevel = inLogLevel;
		visualLogLevel = inVisualLevel;
	}

	public static void SendTag(string tagName, string tagValue)
	{
		oneSignalPlatform.SendTag(tagName, tagValue);
	}

	public static void SendTags(Dictionary<string, string> tags)
	{
		oneSignalPlatform.SendTags(tags);
	}

	public static void GetTags(TagsReceived inTagsReceivedDelegate)
	{
		tagsReceivedDelegate = inTagsReceivedDelegate;
		oneSignalPlatform.GetTags();
	}

	public static void GetTags()
	{
		oneSignalPlatform.GetTags();
	}

	public static void DeleteTag(string key)
	{
		oneSignalPlatform.DeleteTag(key);
	}

	public static void DeleteTags(IList<string> keys)
	{
		oneSignalPlatform.DeleteTags(keys);
	}

	public static void RegisterForPushNotifications()
	{
		oneSignalPlatform.RegisterForPushNotifications();
	}

	public static void PromptForPushNotificationsWithUserResponse(PromptForPushNotificationsUserResponse inDelegate)
	{
		notificationUserResponseDelegate = inDelegate;
		oneSignalPlatform.promptForPushNotificationsWithUserResponse();
	}

	public static void IdsAvailable(IdsAvailableCallback inIdsAvailableDelegate)
	{
		idsAvailableDelegate = inIdsAvailableDelegate;
		oneSignalPlatform.IdsAvailable();
	}

	public static void IdsAvailable()
	{
		oneSignalPlatform.IdsAvailable();
	}

	public static void EnableVibrate(bool enable)
	{
		((OneSignalAndroid)oneSignalPlatform).EnableVibrate(enable);
	}

	public static void EnableSound(bool enable)
	{
		((OneSignalAndroid)oneSignalPlatform).EnableSound(enable);
	}

	public static void ClearOneSignalNotifications()
	{
		((OneSignalAndroid)oneSignalPlatform).ClearOneSignalNotifications();
	}

	public static void SetSubscription(bool enable)
	{
		oneSignalPlatform.SetSubscription(enable);
	}

	public static void PostNotification(Dictionary<string, object> data)
	{
		PostNotification(data, null, null);
	}

	public static void PostNotification(Dictionary<string, object> data, OnPostNotificationSuccess inOnPostNotificationSuccess, OnPostNotificationFailure inOnPostNotificationFailure)
	{
		postNotificationSuccessDelegate = inOnPostNotificationSuccess;
		postNotificationFailureDelegate = inOnPostNotificationFailure;
		oneSignalPlatform.PostNotification(data);
	}

	public static void SyncHashedEmail(string email)
	{
		oneSignalPlatform.SyncHashedEmail(email);
	}

	public static void PromptLocation()
	{
		oneSignalPlatform.PromptLocation();
	}

	public static OSPermissionSubscriptionState GetPermissionSubscriptionState()
	{
		return oneSignalPlatform.getPermissionSubscriptionState();
	}

	private OSNotification DictionaryToNotification(Dictionary<string, object> jsonObject)
	{
		OSNotification oSNotification = new OSNotification();
		OSNotificationPayload oSNotificationPayload = new OSNotificationPayload();
		Dictionary<string, object> dictionary = jsonObject["payload"] as Dictionary<string, object>;
		if (dictionary.ContainsKey("notificationID"))
		{
			oSNotificationPayload.notificationID = dictionary["notificationID"] as string;
		}
		if (dictionary.ContainsKey("sound"))
		{
			oSNotificationPayload.sound = dictionary["sound"] as string;
		}
		if (dictionary.ContainsKey("title"))
		{
			oSNotificationPayload.title = dictionary["title"] as string;
		}
		if (dictionary.ContainsKey("body"))
		{
			oSNotificationPayload.body = dictionary["body"] as string;
		}
		if (dictionary.ContainsKey("subtitle"))
		{
			oSNotificationPayload.subtitle = dictionary["subtitle"] as string;
		}
		if (dictionary.ContainsKey("launchURL"))
		{
			oSNotificationPayload.launchURL = dictionary["launchURL"] as string;
		}
		if (dictionary.ContainsKey("additionalData"))
		{
			if (dictionary["additionalData"] is string)
			{
				oSNotificationPayload.additionalData = Json.Deserialize(dictionary["additionalData"] as string) as Dictionary<string, object>;
			}
			else
			{
				oSNotificationPayload.additionalData = dictionary["additionalData"] as Dictionary<string, object>;
			}
		}
		if (dictionary.ContainsKey("actionButtons"))
		{
			if (dictionary["actionButtons"] is string)
			{
				oSNotificationPayload.actionButtons = Json.Deserialize(dictionary["actionButtons"] as string) as Dictionary<string, object>;
			}
			else
			{
				oSNotificationPayload.actionButtons = dictionary["actionButtons"] as Dictionary<string, object>;
			}
		}
		if (dictionary.ContainsKey("contentAvailable"))
		{
			oSNotificationPayload.contentAvailable = (bool)dictionary["contentAvailable"];
		}
		if (dictionary.ContainsKey("badge"))
		{
			oSNotificationPayload.badge = Convert.ToInt32(dictionary["badge"]);
		}
		if (dictionary.ContainsKey("smallIcon"))
		{
			oSNotificationPayload.smallIcon = dictionary["smallIcon"] as string;
		}
		if (dictionary.ContainsKey("largeIcon"))
		{
			oSNotificationPayload.largeIcon = dictionary["largeIcon"] as string;
		}
		if (dictionary.ContainsKey("bigPicture"))
		{
			oSNotificationPayload.bigPicture = dictionary["bigPicture"] as string;
		}
		if (dictionary.ContainsKey("smallIconAccentColor"))
		{
			oSNotificationPayload.smallIconAccentColor = dictionary["smallIconAccentColor"] as string;
		}
		if (dictionary.ContainsKey("ledColor"))
		{
			oSNotificationPayload.ledColor = dictionary["ledColor"] as string;
		}
		if (dictionary.ContainsKey("lockScreenVisibility"))
		{
			oSNotificationPayload.lockScreenVisibility = Convert.ToInt32(dictionary["lockScreenVisibility"]);
		}
		if (dictionary.ContainsKey("groupKey"))
		{
			oSNotificationPayload.groupKey = dictionary["groupKey"] as string;
		}
		if (dictionary.ContainsKey("groupMessage"))
		{
			oSNotificationPayload.groupMessage = dictionary["groupMessage"] as string;
		}
		if (dictionary.ContainsKey("fromProjectNumber"))
		{
			oSNotificationPayload.fromProjectNumber = dictionary["fromProjectNumber"] as string;
		}
		oSNotification.payload = oSNotificationPayload;
		if (jsonObject.ContainsKey("isAppInFocus"))
		{
			oSNotification.isAppInFocus = (bool)jsonObject["isAppInFocus"];
		}
		if (jsonObject.ContainsKey("shown"))
		{
			oSNotification.shown = (bool)jsonObject["shown"];
		}
		if (jsonObject.ContainsKey("silentNotification"))
		{
			oSNotification.silentNotification = (bool)jsonObject["silentNotification"];
		}
		if (jsonObject.ContainsKey("androidNotificationId"))
		{
			oSNotification.androidNotificationId = Convert.ToInt32(jsonObject["androidNotificationId"]);
		}
		if (jsonObject.ContainsKey("displayType"))
		{
			oSNotification.displayType = (OSNotification.DisplayType)Convert.ToInt32(jsonObject["displayType"]);
		}
		return oSNotification;
	}

	private void onPushNotificationReceived(string jsonString)
	{
		if (builder.notificationReceivedDelegate != null)
		{
			Dictionary<string, object> jsonObject = Json.Deserialize(jsonString) as Dictionary<string, object>;
			builder.notificationReceivedDelegate(DictionaryToNotification(jsonObject));
		}
	}

	private void onPushNotificationOpened(string jsonString)
	{
		if (builder.notificationOpenedDelegate == null)
		{
			return;
		}
		Dictionary<string, object> dictionary = Json.Deserialize(jsonString) as Dictionary<string, object>;
		OSNotificationAction oSNotificationAction = new OSNotificationAction();
		if (dictionary.ContainsKey("action"))
		{
			Dictionary<string, object> dictionary2 = dictionary["action"] as Dictionary<string, object>;
			if (dictionary2.ContainsKey("actionID"))
			{
				oSNotificationAction.actionID = dictionary2["actionID"] as string;
			}
			if (dictionary2.ContainsKey("type"))
			{
				oSNotificationAction.type = (OSNotificationAction.ActionType)Convert.ToInt32(dictionary2["type"]);
			}
		}
		OSNotificationOpenedResult oSNotificationOpenedResult = new OSNotificationOpenedResult();
		oSNotificationOpenedResult.notification = DictionaryToNotification((Dictionary<string, object>)dictionary["notification"]);
		oSNotificationOpenedResult.action = oSNotificationAction;
		builder.notificationOpenedDelegate(oSNotificationOpenedResult);
	}

	private void onIdsAvailable(string jsonString)
	{
		if (idsAvailableDelegate != null)
		{
			Dictionary<string, object> dictionary = Json.Deserialize(jsonString) as Dictionary<string, object>;
			idsAvailableDelegate((string)dictionary["userId"], (string)dictionary["pushToken"]);
		}
	}

	private void onTagsReceived(string jsonString)
	{
		if (tagsReceivedDelegate != null)
		{
			tagsReceivedDelegate(Json.Deserialize(jsonString) as Dictionary<string, object>);
		}
	}

	private void onPostNotificationSuccess(string response)
	{
		if (postNotificationSuccessDelegate != null)
		{
			OnPostNotificationSuccess onPostNotificationSuccess = postNotificationSuccessDelegate;
			postNotificationFailureDelegate = null;
			postNotificationSuccessDelegate = null;
			onPostNotificationSuccess(Json.Deserialize(response) as Dictionary<string, object>);
		}
	}

	private void onPostNotificationFailed(string response)
	{
		if (postNotificationFailureDelegate != null)
		{
			OnPostNotificationFailure onPostNotificationFailure = postNotificationFailureDelegate;
			postNotificationFailureDelegate = null;
			postNotificationSuccessDelegate = null;
			onPostNotificationFailure(Json.Deserialize(response) as Dictionary<string, object>);
		}
	}

	private void onOSPermissionChanged(string stateChangesJSONString)
	{
		OSPermissionStateChanges stateChanges = oneSignalPlatform.parseOSPermissionStateChanges(stateChangesJSONString);
		internalPermissionObserver(stateChanges);
	}

	private void onOSSubscriptionChanged(string stateChangesJSONString)
	{
		OSSubscriptionStateChanges stateChanges = oneSignalPlatform.parseOSSubscriptionStateChanges(stateChangesJSONString);
		internalSubscriptionObserver(stateChanges);
	}

	private void onPromptForPushNotificationsWithUserResponse(string accepted)
	{
		notificationUserResponseDelegate(Convert.ToBoolean(accepted));
	}
}
