using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class PlayerPanel : MonoBehaviour
{
	public Text textName;

	public Text textDominoLeft;

	public Text textScore;

	public Text textWon;

	public Text titleLeft;

	public Text titleScore;

	public AvatarGameView avatar;

	public PlayerTimer timer;

	public PlayerHand hand;

	public GameObject glowObject;

	public PlayerSkipMessage skipMessage;

	private int indexPlayer;

	private int indexActive;

	private int dominoScore;

	private int dominoLeft;

	public int Index
	{
		get
		{
			return indexPlayer;
		}
	}

	public bool IsActive
	{
		get
		{
			return indexActive == indexPlayer;
		}
	}

	public bool IsShow
	{
		get
		{
			return base.gameObject.activeSelf;
		}
		set
		{
			base.gameObject.SetActive(value);
		}
	}

	public string Username
	{
		get
		{
			return textName.text;
		}
		set
		{
			textName.text = Tools.Username(value);
		}
	}

	public int IndexActive
	{
		get
		{
			return indexActive;
		}
		set
		{
			indexActive = value;
			glowObject.SetActive(IsActive);
		}
	}

	public int Count
	{
		get
		{
			return hand.Count;
		}
	}

	public int DominoScore
	{
		get
		{
			return dominoScore;
		}
		set
		{
			Text text = textScore;
			int num = (dominoScore = value);
			text.text = num.ToString();
		}
	}

	private int DominoLeft
	{
		get
		{
			return dominoLeft;
		}
		set
		{
			Text text = textDominoLeft;
			int num = (dominoLeft = value);
			text.text = num.ToString();
		}
	}

	public void StartGame(int index)
	{
		indexPlayer = index;
		Clear();
	}

	public void NewRound()
	{
		SmallClear();
	}

	public void Clear()
	{
		avatar.HideAvatar();
		DominoScore = 0;
		Username = string.Empty;
		SmallClear();
	}

	private void SmallClear()
	{
		DominoLeft = 0;
		hand.Clear();
		timer.Stop();
		skipMessage.Hide();
		textWon.gameObject.SetActive(false);
	}

	public void ShowWon(int wonValue)
	{
		if (wonValue > 0)
		{
			GameSounds.Play(SoundType.Scoring);
			textWon.gameObject.SetActive(true);
			textWon.text = wonValue + " " + TextManager.GetString("Points");
			textWon.SendMessage("Show");
			StartCoroutine(Tools.Pause(1, delegate
			{
				textWon.SendMessage("EmergenceHide");
			}));
		}
	}

	private void OnHiddenWon(bool completed)
	{
		if (completed)
		{
			textWon.gameObject.SetActive(false);
		}
	}

	public void Push(Bone bone, BoneView tile, Action callback = null)
	{
		hand.Push(bone, tile, callback);
		DominoLeft = hand.Count;
	}

	public void Push(ListBone bones, List<BoneView> tiles)
	{
		hand.Push(bones, tiles);
		DominoLeft = hand.Count;
	}

	public BoneView Pull(Bone bone)
	{
		BoneView result = hand.Pull(bone);
		DominoLeft = hand.Count;
		return result;
	}

	public BoneView PullRandom()
	{
		BoneView result = hand.PullRandom();
		DominoLeft = hand.Count;
		return result;
	}

	public List<BoneView> PullAll()
	{
		List<BoneView> result = hand.PullAll();
		DominoLeft = hand.Count;
		return result;
	}

	public BoneView GetBone(Bone moveBone)
	{
		BoneView bone = hand.GetBone(moveBone);
		DominoLeft = hand.Count;
		return bone;
	}

	public void Skip(Action callback)
	{
		GameSounds.Play(SoundType.Skip);
		skipMessage.Play(callback);
	}

	public void Sync(Player player)
	{
		hand.Sync(player);
		DominoLeft = hand.Count;
		timer.Stop();
	}

	public void SetPlayerInfo(PlayerInfo info)
	{
		if (info == null)
		{
			avatar.AvatarURL = string.Empty;
			avatar.ShowJoin();
			Username = string.Empty;
			if (Index == 0)
			{
				Debug.LogError("Avatar join");
			}
		}
		else
		{
			avatar.AvatarURL = info.Avatar;
			avatar.ShowAvatar();
			Username = info.Username;
		}
	}

	private void Awake()
	{
		hand.Init(this);
	}

	private void Start()
	{
		string text = ". . . . . . . . . . . . . . . . ";
		titleLeft.text = TextManager.GetString("Dominoes left") + text;
		titleScore.text = TextManager.GetString("Score") + text;
		IndexActive = -1;
	}
}
