using System.Text;

namespace Dominoes
{
	public class TurnDataOnline : TurnData
	{
		public static int uID;

		private ListBone addList;

		public bool isWaitResponse;

		public bool isAddRequest;

		public BoneView tileMoving;

		private int indexAdd;

		public int AddLength
		{
			get
			{
				return addList.Count;
			}
		}

		public bool IsAddEnable
		{
			get
			{
				return addList.Count > 0 && indexAdd < addList.Count;
			}
		}

		public Bone PullAdding
		{
			get
			{
				return (!IsAddEnable) ? null : addList[indexAdd++];
			}
		}

		public bool IsLastAddBone
		{
			get
			{
				return indexAdd == addList.Count - 1;
			}
		}

		public TurnDataOnline()
		{
			uID++;
			addList = new ListBone(10);
		}

		public void SetAddList(ListBone addList)
		{
			this.addList = addList;
			isAddRequest = true;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("TurnDataOnline: ");
			stringBuilder.AppendLine("Adding: " + addList.ToString());
			stringBuilder.AppendLine("Index: " + indexAdd);
			stringBuilder.AppendLine("WaitResponse: " + isWaitResponse);
			return stringBuilder.ToString();
		}
	}
}
