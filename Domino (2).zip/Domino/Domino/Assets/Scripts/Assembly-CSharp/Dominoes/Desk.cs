using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dominoes
{
	public class Desk : List<Branch>
	{
		public ListBone collection;

		public Bone boneToClose;

		private int doubleCount;

		private Bone spinner;

		public int CountBranches
		{
			get
			{
				return base.Count;
			}
		}

		public int CountBones
		{
			get
			{
				return collection.Count;
			}
		}

		public bool IsEmpty
		{
			get
			{
				return collection.Count == 0;
			}
		}

		public List<Branch> BranchAvailable
		{
			get
			{
				return new List<Branch>(this.Where((Branch x) => x.IsAvailable && CheckBranchAvailable(x)));
			}
		}

		public Desk(int count)
			: base(count)
		{
			collection = new ListBone();
			for (int i = 0; i < count; i++)
			{
				Add(new Branch(i));
			}
		}

		public void NewRound()
		{
			ResetInternal();
		}

		public void Sync(int[][] desk, ListBone list)
		{
			ResetInternal();
			foreach (Bone item in list)
			{
				if (item.IsDouble)
				{
					doubleCount++;
				}
			}
			for (int i = 0; i < desk.Length; i++)
			{
				if (desk[i].Length > 0)
				{
					Bone bone = list.FindById(desk[i][0]);
					if (i == 1)
					{
						base[i].Init(bone, bone.SideB);
					}
					else
					{
						base[i].Init(bone, bone.SideA);
					}
					for (int j = 1; j < desk[i].Length; j++)
					{
						base[i].Play(list.FindById(desk[i][j]));
					}
				}
			}
			if (desk.Length > 0 && desk[0].Length > 0)
			{
				spinner = list.FindById(desk[0][0]);
			}
			if (base.Count > 2 && base[2].IsInit && base[3].IsInit && spinner != base[2][0])
			{
				spinner = base[2][0];
				Align(base[0], base[1], spinner);
			}
			collection = list;
		}

		private void Align(Branch a, Branch b, Bone spinner)
		{
			ListBone listBone = new ListBone(a);
			listBone.Reverse();
			listBone.AddRange(b.GetRange(1, b.Count - 1));
			a.Clear();
			b.Clear();
			int num = listBone.IndexOf(spinner);
			a.AddRange(listBone.GetRange(0, num + 1));
			a.Reverse();
			b.AddRange(listBone.GetRange(num, listBone.Count - num));
		}

		public bool Play(Turn turn)
		{
			Bone moveBone = turn.MoveBone;
			if (IsEmpty)
			{
				if (moveBone.IsDouble)
				{
					doubleCount++;
					using (Enumerator enumerator = GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							Branch current = enumerator.Current;
							current.Init(moveBone, moveBone.SideA);
						}
					}
				}
				else
				{
					base[0].Init(moveBone, moveBone.SideA);
					base[1].Init(moveBone, moveBone.SideB);
				}
				spinner = moveBone;
			}
			else
			{
				base[turn.MoveBranch].Play(turn.MoveBone);
				if (moveBone.IsDouble && doubleCount++ == 0)
				{
					int moveBranch = turn.MoveBranch;
					int index = (moveBranch + 1) % 2;
					ConcatinecteBrances(base[moveBranch], base[index]);
					for (int i = 2; i < base.Count; i++)
					{
						base[i].Init(moveBone, moveBone.SideA);
					}
				}
			}
			collection.Add(moveBone);
			return true;
		}

		private void ConcatinecteBrances(Branch source, Branch receiver)
		{
			ListBone listBone = new ListBone(source.Count);
			for (int num = source.Count - 1; num > 0; num--)
			{
				listBone.Add(source[num]);
			}
			source.RemoveRange(0, source.Count - 1);
			receiver.InsertRange(0, listBone);
		}

		public ListBone GetPairing(Bone bone)
		{
			ListBone listBone = new ListBone(base.Count);
			if (IsEmpty)
			{
				return listBone;
			}
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].Pairing(bone))
				{
					listBone.Add(base[i].head.bone);
				}
				if (i < 2 && base[i].Count == 1 && spinner.IsDouble)
				{
					break;
				}
			}
			return listBone;
		}

		private void ResetInternal()
		{
			collection.Clear();
			doubleCount = 0;
			spinner = null;
			for (int i = 0; i < base.Count; i++)
			{
				base[i].Reset();
			}
		}

		private bool CheckBranchAvailable(Branch branch)
		{
			if (branch.id == 0 || branch.id == 1)
			{
				return true;
			}
			if (base[0].Count > 1 && base[1].Count > 1)
			{
				return true;
			}
			return false;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Branch current = enumerator.Current;
					stringBuilder.Append(current.ToString() + " | ");
					foreach (Bone item in current)
					{
						stringBuilder.Append(item.ToString() + " ");
					}
					stringBuilder.AppendLine();
				}
			}
			return stringBuilder.ToString();
		}
	}
}
