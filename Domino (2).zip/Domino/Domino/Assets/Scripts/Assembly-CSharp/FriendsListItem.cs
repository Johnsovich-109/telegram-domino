using System;
using Dominoes;
using UnityEngine.UI;

public class FriendsListItem : GameBehaviour
{
	public Text textName;

	public AvatarView avatar;

	private FriendData friendData;

	public string Username
	{
		get
		{
			return textName.text;
		}
		set
		{
			textName.text = value;
		}
	}

	public FriendData FriendData
	{
		get
		{
			return friendData;
		}
		set
		{
			friendData = value;
			base.ActiveSelf = value != null;
			if (value != null)
			{
				Username = value.username;
				avatar.AvatarURL = value.avatar;
			}
		}
	}

	public event Action<FriendData> OnClick;

	public void ButtonClick()
	{
		if (this.OnClick != null)
		{
			this.OnClick(FriendData);
		}
	}

	public void Set(FriendData data)
	{
		FriendData = data;
	}
}
