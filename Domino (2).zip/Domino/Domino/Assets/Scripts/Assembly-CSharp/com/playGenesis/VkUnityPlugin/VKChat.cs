using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKChat
	{
		public string type { get; set; }

		public long id { get; set; }

		public string title { get; set; }

		public long admin_id { get; set; }

		public List<long> users { get; set; }

		public string photo_100 { get; set; }

		public string photo_200 { get; set; }

		public static VKChat Deserialize(object Chat)
		{
			VKChat vKChat = new VKChat();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Chat;
			object value;
			if (dictionary.TryGetValue("type", out value))
			{
				vKChat.type = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("id", out value2))
			{
				vKChat.id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("title", out value3))
			{
				vKChat.title = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("admin_id", out value4))
			{
				vKChat.admin_id = (long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("users", out value5))
			{
				vKChat.users = new List<long>();
				foreach (object item in (List<object>)value5)
				{
					vKChat.users.Add((long)item);
				}
			}
			object value6;
			if (dictionary.TryGetValue("photo_100", out value6))
			{
				vKChat.photo_100 = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("photo_200", out value7))
			{
				vKChat.photo_200 = (string)value7;
			}
			return vKChat;
		}
	}
}
