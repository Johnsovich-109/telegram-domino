using System;

namespace Dominoes
{
	public static class MoveToUtils
	{
		public static class Convert
		{
			public static int[] ArrayByteToInt(byte[] bytesArray)
			{
				if (bytesArray == null)
				{
					throw new NullReferenceException("Array not defined.");
				}
				if (bytesArray.Length % 4 != 0)
				{
					throw new InvalidCastException("Can not convert if array length is not a multiple of 4.");
				}
				if (bytesArray.Length == 0)
				{
					return new int[0];
				}
				return Internal_ArrayByteToInt32(bytesArray);
			}

			public static byte[] ArrayIntToByte(int[] intsArray)
			{
				if (intsArray == null)
				{
					throw new NullReferenceException("Array not defined.");
				}
				if (intsArray.Length == 0)
				{
					return new byte[0];
				}
				return Internal_ArrayInt32ToByte(intsArray);
			}

			private static int[] Internal_ArrayByteToInt32(byte[] bytes)
			{
				int[] array = new int[bytes.Length / 4];
				int num = 0;
				int num2 = 0;
				while (num < array.Length)
				{
					array[num] = BitConverter.ToInt32(bytes, num2);
					num++;
					num2 += 4;
				}
				return array;
			}

			private static byte[] Internal_ArrayInt32ToByte(int[] array)
			{
				byte[] array2 = new byte[array.Length * 4];
				int num = 0;
				int num2 = 0;
				while (num < array.Length)
				{
					Array.Copy(BitConverter.GetBytes(array[num]), 0, array2, num2, 4);
					num++;
					num2 += 4;
				}
				return array2;
			}
		}
	}
}
