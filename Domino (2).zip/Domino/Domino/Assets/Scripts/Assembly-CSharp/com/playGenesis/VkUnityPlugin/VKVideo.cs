using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKVideo
	{
		public long id { get; set; }

		public long owner_id { get; set; }

		public string title { get; set; }

		public int duration { get; set; }

		public string description { get; set; }

		public int date { get; set; }

		public int views { get; set; }

		public string photo_130 { get; set; }

		public string photo_320 { get; set; }

		public string photo_640 { get; set; }

		public string player { get; set; }

		public static VKVideo Deserialize(object video)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)video;
			VKVideo vKVideo = new VKVideo();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKVideo.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("owner_id", out value2))
			{
				vKVideo.owner_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("title", out value3))
			{
				vKVideo.title = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("duration", out value4))
			{
				vKVideo.duration = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("date", out value5))
			{
				vKVideo.date = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("views", out value6))
			{
				vKVideo.views = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("photo_130", out value7))
			{
				vKVideo.photo_130 = (string)value7;
			}
			object value8;
			if (dictionary.TryGetValue("photo_320", out value8))
			{
				vKVideo.photo_320 = (string)value8;
			}
			object value9;
			if (dictionary.TryGetValue("photo_640", out value9))
			{
				vKVideo.photo_640 = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("player", out value10))
			{
				vKVideo.player = (string)value10;
			}
			if (dictionary.TryGetValue("id", out value))
			{
				vKVideo.id = (long)value;
			}
			return vKVideo;
		}
	}
}
