using UnityEngine.UI;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKNotificationUI : QueueWorker<string>
	{
		public Text message;

		private void Start()
		{
			message = base.gameObject.GetComponentInChildren<Text>();
		}

		public void Notity(string message)
		{
			Add(message);
		}

		protected override void StartProcessing()
		{
			base.gameObject.SetActive(true);
			base.transform.SetAsLastSibling();
			message.text = _current.Element;
		}

		public void Notify(VKRequest r)
		{
			if (!string.IsNullOrEmpty(r.error.error_msg))
			{
				Add(r.error.error_msg);
			}
		}

		public void onOkButton()
		{
			message.text = string.Empty;
			if (_current.NextElement == null)
			{
				base.gameObject.SetActive(false);
			}
			ProccessNext();
		}
	}
}
