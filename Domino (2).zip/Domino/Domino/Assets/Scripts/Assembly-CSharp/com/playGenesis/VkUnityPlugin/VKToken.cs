using System;
using UnityEngine;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKToken : EventArgs
	{
		public string access_token;

		public int expires_in;

		public string user_id;

		public DateTime tokenRecievedTime;

		public static VKToken ParseSerializeTokenFromNaviteSdk(string message)
		{
			string[] array = message.Split('#');
			VKToken vKToken = new VKToken();
			vKToken.access_token = array[0];
			vKToken.tokenRecievedTime = DateTime.Now;
			vKToken.expires_in = ((int.Parse(array[1]) != 0) ? int.Parse(array[1]) : 999999);
			vKToken.user_id = array[2];
			return vKToken;
		}

		public static bool IsValidToken(VKToken ti)
		{
			return (ti.tokenRecievedTime.AddSeconds(ti.expires_in) > DateTime.Now) ? true : false;
		}

		public static int TokenValidFor()
		{
			VKToken currentToken = VkApi.CurrentToken;
			return (int)(currentToken.tokenRecievedTime.AddSeconds(currentToken.expires_in) - DateTime.Now).TotalSeconds;
		}

		public static void ResetToken()
		{
			VKToken vKToken = new VKToken();
			vKToken.access_token = string.Empty;
			vKToken.tokenRecievedTime = DateTime.Parse("1/1/1992");
			vKToken.expires_in = 1;
			vKToken.user_id = string.Empty;
			VkApi.CurrentToken = vKToken;
			PlayerPrefs.SetString("vkaccess_token", string.Empty);
			PlayerPrefs.SetInt("vkexpires_in", 0);
			PlayerPrefs.SetString("vkuser_id", string.Empty);
			PlayerPrefs.SetString("vktokenRecievedTime", "1/1/1992");
		}

		public void Save()
		{
			PlayerPrefs.SetString("vkaccess_token", access_token);
			PlayerPrefs.SetInt("vkexpires_in", expires_in);
			PlayerPrefs.SetString("vkuser_id", user_id);
			PlayerPrefs.SetString("vktokenRecievedTime", tokenRecievedTime.ToString());
		}

		public static VKToken LoadPersistent()
		{
			DateTime result = DateTime.Parse("1/1/1990");
			DateTime.TryParse(PlayerPrefs.GetString("vktokenRecievedTime", string.Empty), out result);
			VKToken vKToken = new VKToken();
			vKToken.access_token = PlayerPrefs.GetString("vkaccess_token", string.Empty);
			vKToken.expires_in = PlayerPrefs.GetInt("vkexpires_in", 0);
			vKToken.tokenRecievedTime = result;
			vKToken.user_id = PlayerPrefs.GetString("vkuser_id", string.Empty);
			return vKToken;
		}

		public static string ParseFromAuthUrl(string url)
		{
			string[] array = url.Split('#')[1].Split('&');
			string text = string.Empty;
			string text2 = string.Empty;
			string text3 = string.Empty;
			string[] array2 = array;
			foreach (string text4 in array2)
			{
				string text5 = text4.Split('=')[0];
				string text6 = text4.Split('=')[1];
				switch (text5)
				{
				case "access_token":
					text = text6;
					break;
				case "expires_in":
					text2 = text6;
					break;
				case "user_id":
					text3 = text6;
					break;
				}
			}
			return text + "#" + text2 + "#" + text3;
		}
	}
}
