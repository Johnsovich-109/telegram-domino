using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class LeaderboardGames : GameBehaviour
{
	public LeaderboardGameItem prototype;

	public Sprite[] sprites;

	private GameInfo[] activeGames;

	private List<LeaderboardGameItem> listGames;

	private LeaderboardGameItem selectItem;

	public LeaderboardGameItem SelectItem
	{
		get
		{
			return selectItem;
		}
		set
		{
			if (selectItem != null)
			{
				selectItem.IsSelect = false;
			}
			selectItem = value;
			if (selectItem != null)
			{
				selectItem.IsSelect = true;
			}
		}
	}

	public event Action<GameInfo> OnClick;

	public void Select(GameInfo game)
	{
		SelectItem = GetItem(game);
	}

	public void SetGames(GameInfo[] activeGames)
	{
		AlignList(activeGames.Length);
		SetData(activeGames);
	}

	private void Start()
	{
		listGames = new List<LeaderboardGameItem> { prototype };
		foreach (LeaderboardGameItem listGame in listGames)
		{
			listGame.OnClick += Game_OnClick;
		}
	}

	private LeaderboardGameItem GetItem(GameInfo game)
	{
		foreach (LeaderboardGameItem listGame in listGames)
		{
			if (listGame.GameInfo.Name == game.Name)
			{
				return listGame;
			}
		}
		return null;
	}

	private void SetData(GameInfo[] activeGames)
	{
		for (int i = 0; i < activeGames.Length; i++)
		{
			listGames[i].Title = TextManager.GetString(activeGames[i].Name);
			listGames[i].Icon = GetSprite(activeGames[i].Name);
			listGames[i].GameInfo = activeGames[i];
		}
	}

	private Sprite GetSprite(string name)
	{
		Sprite[] array = sprites;
		foreach (Sprite sprite in array)
		{
			if (sprite.name == name)
			{
				return sprite;
			}
		}
		return null;
	}

	private void AlignList(int length)
	{
		if (listGames == null)
		{
			listGames = new List<LeaderboardGameItem> { prototype };
		}
		while (listGames.Count < length)
		{
			CreateItem(prototype);
		}
		while (listGames.Count > length)
		{
			RemoveItem();
		}
	}

	private void CreateItem(LeaderboardGameItem prototype)
	{
		LeaderboardGameItem leaderboardGameItem = UnityEngine.Object.Instantiate(prototype);
		leaderboardGameItem.OnClick += Game_OnClick;
		CopyTransform(prototype.transform, leaderboardGameItem.transform);
		listGames.Add(leaderboardGameItem);
	}

	private void RemoveItem()
	{
		if (listGames.Count > 0)
		{
			LeaderboardGameItem leaderboardGameItem = listGames[listGames.Count - 1];
			listGames.RemoveAt(listGames.Count - 1);
			leaderboardGameItem.OnClick -= Game_OnClick;
			UnityEngine.Object.DestroyObject(leaderboardGameItem.gameObject);
		}
	}

	private void CopyTransform(Transform from, Transform to)
	{
		to.SetParent(from.parent);
		to.localScale = from.localScale;
	}

	private void Game_OnClick(LeaderboardGameItem item)
	{
		SelectItem = item;
		if (this.OnClick != null)
		{
			this.OnClick(item.GameInfo);
		}
	}
}
