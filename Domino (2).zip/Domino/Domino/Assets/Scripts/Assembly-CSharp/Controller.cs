using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using com.playGenesis.VkUnityPlugin;
using com.playGenesis.VkUnityPlugin.MiniJSON;

public class Controller : MonoBehaviour
{
	public VkApi vkapi;

	public Downloader d;

	public List<VKUser> friends = new List<VKUser>();

	public VkSettings sets;

	private void Start()
	{
		sets = VkApi.VkSetts;
		vkapi = VkApi.VkApiInstance;
		d = vkapi.gameObject.GetComponent<Downloader>();
		if (vkapi.IsUserLoggedIn)
		{
			startWorkingWithVk();
			return;
		}
		vkapi.LoggedIn += startWorkingWithVk;
		vkapi.Login();
	}

	public void Login()
	{
		vkapi.Login();
	}

	public void LogOut()
	{
		vkapi.Logout();
		sets.forceOAuth = true;
		sets.revoke = true;
	}

	public void startWorkingWithVk()
	{
		if (VKToken.TokenValidFor() < 120)
		{
			Login();
		}
		Get3FriendsDataFromVk();
	}

	public void Get3FriendsDataFromVk()
	{
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "friends.get?user_id=" + VkApi.CurrentToken.user_id + "&count=3&fields=photo_200";
		vKRequest.CallBackFunction = OnGet5FriendsCompleted;
		VKRequest httprequest = vKRequest;
		vkapi.Call(httprequest);
	}

	private void OnGet5FriendsCompleted(VKRequest arg)
	{
		if (arg.error != null)
		{
			GlobalErrorHandler globalErrorHandler = UnityEngine.Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(arg);
			}
			return;
		}
		Dictionary<string, object> dictionary = Json.Deserialize(arg.response) as Dictionary<string, object>;
		Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary["response"];
		List<object> list = (List<object>)dictionary2["items"];
		foreach (object item in list)
		{
			friends.Add(VKUser.Deserialize(item));
		}
		for (int i = 0; i < friends.Count; i++)
		{
			FriendManager[] array = UnityEngine.Object.FindObjectsOfType<FriendManager>();
			Action<DownloadRequest> onFinished = delegate(DownloadRequest downloadRequest)
			{
				FriendManager friendManager = (FriendManager)downloadRequest.CustomData[0];
				friendManager.setUpImage(downloadRequest.DownloadResult.texture);
			};
			array[i].t.text = friends[i].first_name + " " + friends[i].last_name;
			array[i].friend = friends[i];
			DownloadRequest downloadRequest2 = new DownloadRequest();
			downloadRequest2.url = friends[i].photo_200;
			downloadRequest2.onFinished = onFinished;
			downloadRequest2.CustomData = new object[1] { array[i] };
			DownloadRequest downloadRequest3 = downloadRequest2;
			d.download(downloadRequest3);
		}
	}

	public void Back()
	{
		SceneManager.LoadScene("StarterScene");
	}
}
