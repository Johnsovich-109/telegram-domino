using UnityEngine;

namespace com.playGenesis.VkUnityPlugin
{
	public class MessageHandler : MonoBehaviour
	{
		private VkApi vkapi;

		private void Awake()
		{
			vkapi = GetComponent<VkApi>();
		}

		public void ReceiveNewTokenMessage(string message)
		{
			VKToken e = VKToken.ParseSerializeTokenFromNaviteSdk(message);
			vkapi.onReceiveNewToken(e);
		}

		public void AccessDeniedMessage(string errormessage)
		{
			Error error = Error.ParseSerializedFromFromNativeSdk(errormessage);
			Debug.Log("Access Denied " + error.error_msg);
			vkapi.onAccessDenied(error);
		}

		public void NoVkApp(string msg)
		{
			Debug.Log("No vk app");
			VkApi.VkSetts.forceOAuth = true;
			vkapi.Login();
		}
	}
}
