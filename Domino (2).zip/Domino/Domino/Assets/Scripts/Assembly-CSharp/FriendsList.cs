using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class FriendsList : MonoBehaviour
{
	public List<FriendsListItem> listFriends;

	private bool init;

	public event Action<FriendData> OnFriendClick;

	public void Init()
	{
		if (init)
		{
			return;
		}
		foreach (FriendsListItem listFriend in listFriends)
		{
			listFriend.OnClick += Friend_OnClick;
			listFriend.Set(null);
		}
		init = true;
	}

	public void Set(List<FriendData> friendsList)
	{
		if (friendsList == null)
		{
			for (int i = 0; i < listFriends.Count; i++)
			{
				listFriends[i].Set(null);
			}
			return;
		}
		if (listFriends.Count == 0)
		{
			throw new Exception("The list friends was not initialized");
		}
		while (listFriends.Count < listFriends.Count)
		{
			CreateFriendItem(listFriends[0]);
		}
		while (listFriends.Count < listFriends.Count)
		{
			RemoveFriendItem(0);
		}
		for (int j = 0; j < friendsList.Count; j++)
		{
			listFriends[j].Set(friendsList[j]);
		}
	}

	public void Add(FriendData data)
	{
		FriendsListItem friendsListItem = CreateFriendItem(listFriends[0]);
		friendsListItem.Set(data);
	}

	public void AddRange(FriendData[] data)
	{
		for (int i = 0; i < data.Length; i++)
		{
			FriendsListItem friendsListItem = CreateFriendItem(listFriends[0]);
			friendsListItem.Set(data[i]);
		}
	}

	public void Remove(FriendData data)
	{
		int num = listFriends.FindIndex((FriendsListItem x) => x.FriendData.id == data.id);
		if (num > -1)
		{
			RemoveFriendItem(num);
		}
	}

	private void Start()
	{
		Init();
	}

	private FriendsListItem CreateFriendItem(FriendsListItem prototype)
	{
		FriendsListItem friendsListItem = UnityEngine.Object.Instantiate(prototype);
		friendsListItem.transform.SetParent(prototype.transform.parent);
		friendsListItem.transform.localScale = prototype.transform.localScale;
		friendsListItem.OnClick += Friend_OnClick;
		listFriends.Add(friendsListItem);
		return friendsListItem;
	}

	private void RemoveFriendItem(int index)
	{
		if (listFriends.Count > index)
		{
			FriendsListItem friendsListItem = listFriends[index];
			listFriends.RemoveAt(index);
			UnityEngine.Object.DestroyObject(friendsListItem.gameObject);
			return;
		}
		throw new IndexOutOfRangeException("The list of objects is empty");
	}

	private void Friend_OnClick(FriendData friendData)
	{
		if (this.OnFriendClick != null)
		{
			this.OnFriendClick(friendData);
		}
	}
}
