using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUniversity
	{
		public long id { get; set; }

		public long country { get; set; }

		public long city { get; set; }

		public string name { get; set; }

		public long faculty { get; set; }

		public string faculty_name { get; set; }

		public long chair { get; set; }

		public string chair_name { get; set; }

		public int graduation { get; set; }

		public static VKUniversity Deserialize(object University)
		{
			VKUniversity vKUniversity = new VKUniversity();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)University;
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKUniversity.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("country", out value2))
			{
				vKUniversity.country = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("city", out value3))
			{
				vKUniversity.city = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("name", out value4))
			{
				vKUniversity.name = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("faculty", out value5))
			{
				vKUniversity.faculty = (long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("faculty_name", out value6))
			{
				vKUniversity.faculty_name = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("chair", out value7))
			{
				vKUniversity.chair = (long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("chair_name", out value8))
			{
				vKUniversity.chair_name = (string)value8;
			}
			object value9;
			if (dictionary.TryGetValue("graduation", out value9))
			{
				vKUniversity.graduation = (int)(long)value9;
			}
			return vKUniversity;
		}
	}
}
