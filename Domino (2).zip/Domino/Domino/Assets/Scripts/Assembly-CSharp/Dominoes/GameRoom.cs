using System.Collections.Generic;
using ExitGames.Client.Photon;

namespace Dominoes
{
	public class GameRoom
	{
		public List<PhotonFriend> inviteFriends;

		private int bet;

		private int friendGame;

		private int size;

		private GameInfo gameInfo;

		private Dictionary<int, PlayerInfo> players;

		public int Size
		{
			get
			{
				return size;
			}
			set
			{
				size = value;
			}
		}

		public int CountCurrent
		{
			get
			{
				return players.Count;
			}
		}

		public bool IsFilling
		{
			get
			{
				return players.Count == Size;
			}
		}

		public int Bet
		{
			get
			{
				return bet;
			}
			set
			{
				bet = value;
			}
		}

		public int FriendGame
		{
			get
			{
				return friendGame;
			}
			set
			{
				friendGame = value;
			}
		}

		public string NameOnline
		{
			get
			{
				return gameInfo.NameOnline;
			}
		}

		public GameInfo GameInfo
		{
			get
			{
				return gameInfo;
			}
			set
			{
				gameInfo = value;
			}
		}

		public bool IsFriends
		{
			get
			{
				return friendGame > 0;
			}
		}

		public PlayerInfo this[int index]
		{
			get
			{
				if (players.ContainsKey(index))
				{
					return players[index];
				}
				return null;
			}
		}

		public GameRoom(bool gameFriend)
		{
			friendGame = (gameFriend ? 1 : 0);
			players = new Dictionary<int, PlayerInfo>(4);
			bet = 100;
			size = 2;
		}

		public void PlayerChanged(string state, PhotonPlayer player, Hashtable properties)
		{
			Join(player, properties);
			if (PhotonNetwork.playerList.Length == CountCurrent)
			{
				return;
			}
			players.Clear();
			Dictionary<int, PlayerInfo> dictionary = new Dictionary<int, PlayerInfo>(4);
			PhotonPlayer[] playerList = PhotonNetwork.playerList;
			foreach (PhotonPlayer photonPlayer in playerList)
			{
				int key = IndexTranslator(photonPlayer.ID);
				if (players.ContainsKey(key))
				{
					dictionary.Add(key, players[key]);
				}
				else
				{
					dictionary.Add(key, new PlayerInfo(photonPlayer));
				}
			}
			players = dictionary;
			Join(player, properties);
		}

		private void Join(PhotonPlayer player, Hashtable properties)
		{
			PlayerInfo playerInfo = new PlayerInfo(player, properties);
			int key = IndexTranslator(playerInfo.ID);
			if (players.ContainsKey(key))
			{
				players[key] = playerInfo;
			}
			else
			{
				players.Add(key, playerInfo);
			}
		}

		public void Leave()
		{
			players.Clear();
		}

		public void PlayerConnected(PhotonPlayer player)
		{
		}

		public void PlayerDisconnected(PhotonPlayer player)
		{
			int num = IndexTranslator(player.ID);
			if (players.ContainsKey(num))
			{
				players.Remove(num);
			}
			DebugF.LogError("Remove index: {0}; ID: {1}", num, player.ID);
		}

		public void ActivityChanged(PhotonPlayer player)
		{
		}

		public int IndexTranslator(int index)
		{
			return (index - PhotonNetwork.player.ID + size) % size;
		}
	}
}
