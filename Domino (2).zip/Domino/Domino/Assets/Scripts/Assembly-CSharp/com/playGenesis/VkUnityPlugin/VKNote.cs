using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKNote
	{
		public long id { get; set; }

		public long user_id { get; set; }

		public long owner_id
		{
			get
			{
				return user_id;
			}
			set
			{
				user_id = value;
			}
		}

		public string title { get; set; }

		public string text { get; set; }

		public int comments { get; set; }

		public int read_comments { get; set; }

		public string view_url { get; set; }

		public static VKNote Deserialize(object note)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)note;
			VKNote vKNote = new VKNote();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKNote.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("user_id", out value2))
			{
				vKNote.user_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("owner_id", out value3))
			{
				vKNote.owner_id = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("text", out value4))
			{
				vKNote.text = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("title", out value5))
			{
				vKNote.title = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("comments", out value6))
			{
				vKNote.comments = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("read_comments", out value7))
			{
				vKNote.read_comments = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("view_url", out value8))
			{
				vKNote.view_url = (string)value8;
			}
			return vKNote;
		}
	}
}
