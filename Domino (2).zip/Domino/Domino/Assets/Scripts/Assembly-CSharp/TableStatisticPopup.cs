using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class TableStatisticPopup : PopupBehaviour
{
	protected const float addWidth = 100f;

	public List<TableStatisticColumn> listColumns;

	public List<RectTransform> listLines;

	private int count;

	public int Count
	{
		get
		{
			return count;
		}
		set
		{
			if ((count = value) < 2)
			{
				throw new Exception("Invalid number of columns: " + value);
			}
			SetColumn(value);
			SetVertLines(value);
			AlignColumn(value);
		}
	}

	public virtual void Refresh(ScoresController scores)
	{
		Count = scores.Count;
		for (int i = 0; i < Count; i++)
		{
			listColumns[i].Refresh(scores[i]);
		}
	}

	private void AlignColumn(int value)
	{
		float num = (listColumns[0].transform as RectTransform).rect.width * 0.5f;
		float num2 = (listLines[0].transform as RectTransform).rect.width * 0.5f;
		float num3 = (float)(-value) * num;
		for (int i = 0; i < listColumns.Count; i++)
		{
			num3 += num;
			listColumns[i].Position = num3;
			num3 += num;
			if (i < listLines.Count)
			{
				num3 += num2;
				listLines[i].localPosition = new Vector3(num3, 0f);
				num3 += num2;
			}
		}
		RectTransform rectTransform = base.transform as RectTransform;
		rectTransform.sizeDelta = new Vector2((num * (float)value + num2 * (float)listLines.Count) * 2f + 100f, rectTransform.sizeDelta.y);
	}

	private void SetVertLines(int value)
	{
		while (count - 1 > listLines.Count)
		{
			CreateLine();
		}
		for (int i = 0; i < listLines.Count; i++)
		{
			listLines[i].gameObject.SetActive(i < count - 1);
		}
	}

	private void SetColumn(int count)
	{
		while (count > listColumns.Count)
		{
			CreateColumn();
		}
		for (int i = 0; i < listColumns.Count; i++)
		{
			listColumns[i].ActiveSelf = i < count;
		}
	}

	private void CreateLine()
	{
		if (listLines.Count == 0)
		{
			throw new Exception("Error: Can not create line!");
		}
		RectTransform item = CreateLine(listLines[0]);
		listLines.Add(item);
	}

	private RectTransform CreateLine(RectTransform prototype)
	{
		RectTransform rectTransform = UnityEngine.Object.Instantiate(prototype);
		rectTransform.SetParent(prototype.transform.parent);
		rectTransform.sizeDelta = prototype.sizeDelta;
		return rectTransform;
	}

	private void CreateColumn()
	{
		if (listColumns.Count == 0)
		{
			throw new Exception("Error: Can not create column!");
		}
		TableStatisticColumn item = CreateColumn(listColumns[0]);
		listColumns.Add(item);
	}

	private TableStatisticColumn CreateColumn(TableStatisticColumn prototype)
	{
		TableStatisticColumn tableStatisticColumn = UnityEngine.Object.Instantiate(prototype);
		tableStatisticColumn.transform.SetParent(prototype.transform.parent);
		RectTransform rectTransform = tableStatisticColumn.transform as RectTransform;
		RectTransform rectTransform2 = prototype.transform as RectTransform;
		rectTransform.sizeDelta = rectTransform2.sizeDelta;
		tableStatisticColumn.transform.localScale = prototype.transform.localScale;
		return tableStatisticColumn;
	}
}
