using System;
using UnityEngine.UI;

public class GameMenuPopup : PopupBehaviour
{
	public Text textTitle;

	public Text[] textButtons;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<string> OnClick;

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		Text[] array = textButtons;
		foreach (Text text in array)
		{
			text.text = TextManager.GetString(text.text);
		}
	}
}
