namespace Dominoes
{
	public class GameAllThrees : GameAllNumber
	{
		public GameAllThrees(int players)
			: base(players, 3)
		{
		}
	}
}
