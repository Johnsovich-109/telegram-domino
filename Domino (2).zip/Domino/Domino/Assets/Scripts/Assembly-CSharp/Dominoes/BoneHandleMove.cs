using System.Collections.Generic;

namespace Dominoes
{
	public class BoneHandleMove
	{
		private List<BoneView> tileDesk;

		private BoneView tileMove;

		public List<BoneView> TileDesk
		{
			get
			{
				return tileDesk;
			}
			set
			{
				tileDesk = value;
			}
		}

		public BoneView TileMove
		{
			get
			{
				return tileMove;
			}
			set
			{
				tileMove = value;
			}
		}

		public BoneHandleMove(BoneView tileMove, List<BoneView> tileDesk)
		{
			TileMove = tileMove;
			TileDesk = tileDesk;
		}
	}
}
