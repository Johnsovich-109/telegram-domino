using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class PlayerHandOpen : PlayerHand
{
	protected RectTransform nodeUI;

	protected DominoPool pool;

	protected float[] position;

	public override void Sync(Player player)
	{
		foreach (BoneView item in collection)
		{
			BonePulled(item);
		}
		base.Sync(player);
		if (player.Count != base.Count)
		{
			throw new Exception(string.Format("Not the same size in collections 'players' = {0} and 'hand' = {1}", player.Count, base.Count));
		}
		CalculatePositions();
		for (int i = 0; i < base.Count; i++)
		{
			BonePushed(base[i]);
			base[i].Show(player[i]);
			base[i].node.localScale = scaleInHandVector;
			base[i].node.localPosition = Vector3.right * position[i];
			base[i].node.localRotation = Quaternion.identity;
		}
	}

	public override void Clear()
	{
		foreach (BoneView item in collection)
		{
			BonePulled(item);
		}
		base.Clear();
	}

	public override void Push(Bone bone, BoneView tile, Action callback)
	{
		base.Push(bone, tile, callback);
		AlignCollectionFast();
		tile.Show(bone);
		BonePushed(tile);
		StartCoroutine(Tools.Pause(0.1f * (float)base.Count + DominoSettings.TimeMoveBone, callback));
	}

	public override void Push(ListBone list, List<BoneView> tiles)
	{
		base.Push(list, tiles);
		if (list.Count != tiles.Count)
		{
			throw new Exception("Incorrect data");
		}
		for (int i = 0; i < list.Count; i++)
		{
			tiles[i].Show(list[i]);
			BonePushed(tiles[i]);
		}
		CalculatePositions();
		StartCoroutine(AlignAnimation(-1));
		StartCoroutine(SoundPlaying());
	}

	public override BoneView Pull(Bone bone)
	{
		BoneView boneView = base.Pull(bone);
		BonePulled(boneView);
		AlignCollection();
		return boneView;
	}

	public override BoneView PullRandom()
	{
		BoneView boneView = base.PullRandom();
		BonePulled(boneView);
		AlignCollection();
		return boneView;
	}

	public override List<BoneView> PullAll()
	{
		foreach (BoneView item in collection)
		{
			BonePulled(item);
		}
		return base.PullAll();
	}

	public override BoneView GetBone(Bone moveBone)
	{
		if (moveBone == null)
		{
			return null;
		}
		return collection.Find((BoneView x) => x.Bone.Equals(moveBone));
	}

	public void SetAvailable(ListBone available)
	{
		if (available == null)
		{
			SetBlackout(false);
			return;
		}
		if (available.Count == 0)
		{
			SetBlackout(true);
			return;
		}
		foreach (BoneView item in collection)
		{
			item.Blackout = !available.Exists(item.Bone);
		}
	}

	protected void CalculatePositions()
	{
		float num = nodeUI.rect.x + pool.sizeTile.width * scaleInHand / 2f;
		float num2 = Mathf.Clamp(nodeUI.rect.width / (float)base.Count, 0f, pool.sizeTile.width * scaleInHand * 1.4f);
		position = new float[base.Count];
		for (int i = 0; i < position.Length; i++)
		{
			position[i] = num + num2 * (float)i;
		}
	}

	protected void MoveIndexOf(int index)
	{
		base[index].mover.Scale(scaleInHandVector, DominoSettings.TimeMoveBone);
		base[index].mover.Move(Vector3.right * position[index], DominoSettings.TimeMoveBone);
	}

	protected int IndexOf(BoneView tile)
	{
		if (tile == null)
		{
			return -1;
		}
		for (int num = collection.Count - 1; num >= 0; num--)
		{
			if (collection[num].Equals(tile))
			{
				return num;
			}
		}
		return -1;
	}

	protected virtual void BonePulled(BoneView tile)
	{
	}

	protected virtual void BonePushed(BoneView tile)
	{
	}

	private void Awake()
	{
		scaleInHandVector = Vector3.one * scaleInHand;
	}

	private void Start()
	{
		nodeUI = base.transform as RectTransform;
		pool = DominoPool.instance;
	}

	private IEnumerator Autoplay()
	{
		Debug.LogError("Player autorun");
		while (true)
		{
			if (!player.IsActive)
			{
				yield return null;
				continue;
			}
			yield return new WaitForSeconds(1f);
			for (int i = 0; i < collection.Count; i++)
			{
				if (!player.IsActive)
				{
					break;
				}
				if (!collection[i].Blackout && collection[i].Enabled)
				{
					collection[i].OnBeginDrag(null);
					yield return null;
					if (collection.Count <= i || collection[i] == null)
					{
						break;
					}
					Vector3 vector = collection[i].transform.localPosition;
					vector.y += 100f;
					collection[i].transform.localPosition = vector;
					collection[i].OnEndDrag(null);
					yield return new WaitForSeconds(DominoSettings.TimeMoveBone);
				}
			}
			yield return null;
		}
	}

	private void AlignCollectionFast()
	{
		CalculatePositions();
		for (int i = 0; i < base.Count; i++)
		{
			MoveIndexOf(i);
		}
	}

	private void AlignCollection(int index = -1)
	{
		CalculatePositions();
		StartCoroutine(AlignAnimation(index));
	}

	private IEnumerator AlignAnimation(int index)
	{
		if (index > -1)
		{
			MoveIndexOf(index);
		}
		for (int i = 0; i < base.Count; i++)
		{
			if (i != index)
			{
				MoveIndexOf(i);
				yield return new WaitForSeconds(0.1f);
			}
		}
	}

	private void SetBlackout(bool blackout)
	{
		foreach (BoneView item in collection)
		{
			item.Blackout = blackout;
		}
	}
}
