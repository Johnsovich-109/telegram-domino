using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class GameOverColumn : TableStatisticColumn
{
	public GameObject rankItem;

	public Sprite spriteRankInc;

	public Sprite spriteRankDec;

	public Text textRank;

	public Text textCoins;

	public Image imageRankIcon;

	public bool IsRankShow
	{
		get
		{
			return rankItem.activeSelf;
		}
		set
		{
			rankItem.SetActive(value);
		}
	}

	public override void Refresh(PlayerScores playScore)
	{
		base.Refresh(playScore);
		imageRankIcon.sprite = ((playScore.CurrentRating >= 0) ? spriteRankInc : spriteRankDec);
		textRank.text = playScore.CurrentRating.ToString();
		textCoins.text = playScore.BalanceChanges.ToString();
	}
}
