internal enum JoinType
{
	CreateRoom = 0,
	JoinRoom = 1,
	JoinRandomRoom = 2,
	JoinOrCreateRoom = 3
}
