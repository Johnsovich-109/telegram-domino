using System.Collections.Generic;

public class ResponseStatistic : ResponseBase
{
	public readonly int finished;

	public readonly int started;

	public readonly int win;

	public readonly int loss;

	public readonly int score;

	public ResponseStatistic(Dictionary<string, object> dict)
		: base(dict)
	{
		object value;
		if (dict.TryGetValue("values", out value))
		{
			dict = value as Dictionary<string, object>;
			if (dict.TryGetValue("ended", out value))
			{
				finished = (int)(long)value;
			}
			if (dict.TryGetValue("game", out value))
			{
				started = (int)(long)value;
			}
			if (dict.TryGetValue("win", out value))
			{
				win = (int)(long)value;
			}
			loss = started - win;
		}
		score = GetInt("score");
	}
}
