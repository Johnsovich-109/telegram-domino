public abstract class BaseState : IState
{
	protected bool isActive;

	public abstract string GetName { get; }

	public virtual bool IsActive
	{
		get
		{
			return isActive;
		}
		set
		{
			isActive = value;
		}
	}

	protected void ChangeActiveController(string name)
	{
		MainController.instance.ChangeActiveController(name);
	}

	public virtual void OnInit()
	{
	}

	public virtual void OnEnter(string oldState, object args)
	{
	}

	public virtual void OnEscape()
	{
	}

	public virtual void OnInvite()
	{
	}

	public virtual void OnExit(string newState)
	{
	}

	public virtual void OnUpdate(float deltaTime)
	{
	}
}
