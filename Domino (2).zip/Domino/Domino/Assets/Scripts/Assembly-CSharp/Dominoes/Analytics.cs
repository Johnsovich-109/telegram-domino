using UnityEngine.Analytics;

namespace Dominoes
{
	public static class Analytics
	{
		public static void SingleGame(GameCurrent gameCurrent)
		{
			Event("SingleGame_{0}_{1}", gameCurrent.Name, gameCurrent.CountPlayers);
		}

		public static void OnlineGame(GameCurrent gameCurrent)
		{
			Event("OnlineGame_{0}_{1}", gameCurrent.Name, gameCurrent.CountPlayers);
		}

		public static void RewardShowed()
		{
			Event("Show rewarded video");
		}

		public static void InterstitialShowed()
		{
			Event("Show interstitial");
		}

		public static void Event(string format, params object[] args)
		{
			Event(string.Format(format, args));
		}

		public static void Event(string eventName)
		{
			UnityEngine.Analytics.Analytics.CustomEvent(eventName);
		}
	}
}
