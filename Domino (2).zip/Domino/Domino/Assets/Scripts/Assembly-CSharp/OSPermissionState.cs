public class OSPermissionState
{
	public bool hasPrompted;

	public OSNotificationPermission status;
}
