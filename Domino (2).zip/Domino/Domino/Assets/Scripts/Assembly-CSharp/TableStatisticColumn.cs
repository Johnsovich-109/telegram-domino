using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class TableStatisticColumn : GameBehaviour
{
	public Text textName;

	public Text textScoreTotal;

	public AvatarView avatar;

	public float Position
	{
		get
		{
			return base.Node.localPosition.x;
		}
		set
		{
			base.Node.localPosition = new Vector3(value, 0f);
		}
	}

	public virtual void Refresh(PlayerScores playScore)
	{
		textName.text = playScore.Player.Name;
		textScoreTotal.text = playScore.GameTotal.ToString();
		avatar.AvatarURL = playScore.Player.Avatar;
		avatar.ShowAvatar();
	}
}
