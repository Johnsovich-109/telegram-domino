public enum PhotonTargets
{
	All = 0,
	Others = 1,
	MasterClient = 2,
	AllBuffered = 3,
	OthersBuffered = 4,
	AllViaServer = 5,
	AllBufferedViaServer = 6
}
