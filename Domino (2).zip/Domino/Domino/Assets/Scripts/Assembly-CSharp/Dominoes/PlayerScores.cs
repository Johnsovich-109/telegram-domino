using System.Collections.Generic;
using System.Text;

namespace Dominoes
{
	public class PlayerScores
	{
		public int Game;

		public int Round;

		public int PlayWon;

		public int Memory;

		public int Temp;

		public int Bones;

		public int CurrentRating;

		public int Balance;

		public int BalanceChanges;

		public int DiffRating;

		public List<int> RoundList;

		public List<int> MemoryList;

		public List<bool> BlockedList;

		private Player player;

		private int count;

		public Player Player
		{
			get
			{
				return player;
			}
		}

		public int Count
		{
			get
			{
				return count;
			}
		}

		public int RoundTotal
		{
			get
			{
				return Round + PlayWon;
			}
		}

		public int GameTotal
		{
			get
			{
				return Game + PlayWon;
			}
		}

		public PlayerScores(Player player)
		{
			this.player = player;
			RoundList = new List<int>(10);
			MemoryList = new List<int>(10);
			BlockedList = new List<bool>(10);
		}

		public void RoundNew()
		{
			PlayWon = 0;
			Round = 0;
		}

		public void RoundOver(bool blocked)
		{
			RoundList.Add(RoundTotal);
			MemoryList.Add(Memory);
			BlockedList.Add(blocked);
			count++;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("Game\t" + Game + "; ");
			stringBuilder.AppendLine("Round\t" + Round + "; " + Utils.ToString(RoundList));
			stringBuilder.AppendLine("Memory\t" + Memory + "; " + Utils.ToString(MemoryList));
			stringBuilder.AppendLine("Temp\t" + Temp + "; ");
			stringBuilder.AppendLine("Bones\t" + Bones + "; ");
			return stringBuilder.ToString();
		}
	}
}
