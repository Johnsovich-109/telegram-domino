using Dominoes;
using UnityEngine.UI;

public class GamePreview : GameBehaviour
{
	public Text textGameName;

	public Text textFinalScore;

	public Text textRate;

	public Image imageIcon;

	private int finalScore;

	private int rate;

	public string Game
	{
		get
		{
			return textGameName.text;
		}
		set
		{
			textGameName.text = TextManager.GetString("Game") + ": " + TextManager.GetString(value);
			imageIcon.sprite = SpriteCollection.GetGameIcon(value);
			imageIcon.SetNativeSize();
		}
	}

	public int FinalScore
	{
		get
		{
			return finalScore;
		}
		set
		{
			finalScore = value;
			if ((bool)textFinalScore)
			{
				textFinalScore.text = TextManager.GetString("Score") + ": " + value;
			}
		}
	}

	public int Rate
	{
		get
		{
			return rate;
		}
		set
		{
			rate = value;
			textRate.text = TextManager.GetString("Bet") + ": " + value.ToString("### ##0");
		}
	}

	public void Show(GameCurrent currentGame)
	{
		Game = currentGame.Name;
		FinalScore = currentGame.FinalScore;
		Rate = currentGame.Rate;
	}
}
