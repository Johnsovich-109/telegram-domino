using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Facebook.Unity;
using UnityEngine;

public class SocialFBController : MonoBehaviour
{
	public static SocialFBController instance;

	private List<string> perms = new List<string> { "public_profile", "email", "user_friends" };

	public bool IsLoggedIn
	{
		get
		{
			return FB.IsLoggedIn;
		}
	}

	public event Action<string> OnDeepLinkResult;

	public event Action<object> OnRequestResult;

	public event Action<UserProfile, string[]> OnLogin;

	public event Action OnLogout;

	public event Action<string> OnFailed;

	public void LogIn()
	{
		FB.LogInWithReadPermissions(perms, AuthCallback);
	}

	public void LogOut()
	{
		FB.LogOut();
	}

	public void AppInvite()
	{
		string uriString = "https://fb.me/118471652092986";
		string uriString2 = "https://nardeweb.skillcap.net/i/banners/domino_invite_banner.jpg";
		Debug.Log("App invite " + FB.IsLoggedIn);
		if (FB.IsLoggedIn)
		{
			FB.Mobile.AppInvite(new Uri(uriString), new Uri(uriString2), delegate(IAppInviteResult result)
			{
				Debug.Log(result.RawResult);
			});
			return;
		}
		FB.LogInWithReadPermissions(perms, delegate(ILoginResult result)
		{
			Debug.Log(result.RawResult);
			if (string.IsNullOrEmpty(result.Error) && !result.Cancelled)
			{
				GetUserData();
				DeepLink();
				AppInvite();
			}
		});
	}

	public void Share(string title, string description, string photoUrl)
	{
		FB.ShareLink(new Uri("http://dominoesweb.skillcap.net/ogp/domino_test.html"), title, description, new Uri(photoUrl), delegate(IShareResult result)
		{
			Debug.Log(result.Error);
			Debug.Log(result.RawResult);
		});
	}

	public void Feed()
	{
		StartCoroutine("ShareImageShot");
	}

	private void Awake()
	{
		instance = this;
		if (!FB.IsInitialized)
		{
			FB.Init(InitCallback, OnHideUnity);
		}
		else
		{
			FB.ActivateApp();
		}
	}

	private void Start()
	{
	}

	private void InitCallback()
	{
		if (FB.IsInitialized)
		{
			FB.ActivateApp();
			return;
		}
		Debug.Log("Failed to Initialize the Facebook SDK");
		SendFailed("init");
	}

	private void OnHideUnity(bool isGameShown)
	{
	}

	public void Do(params object[] args)
	{
		switch ((string)args[0])
		{
		case "Share":
			Share((string)args[1], (string)args[2], (string)args[3]);
			break;
		case "Feed":
			Feed();
			break;
		case "Like":
			Like();
			break;
		case "Request":
			Request((string)args[1]);
			break;
		case "Send":
			Send((string)args[1]);
			break;
		}
	}

	private void AuthCallback(ILoginResult result)
	{
		if (FB.IsLoggedIn)
		{
			AccessToken currentAccessToken = AccessToken.CurrentAccessToken;
			GetUserData();
			DeepLink();
		}
		else
		{
			this.OnFailed("cancel");
			Debug.Log("User cancelled login");
		}
	}

	private void GetUserData()
	{
		FB.API("/me?fields=id,name,picture.type(normal),friends.limit(100).fields(id)", HttpMethod.GET, delegate(IGraphResult result)
		{
			Debug.Log("Profile result = " + result.RawResult);
			if (string.IsNullOrEmpty(result.Error) && !result.Cancelled)
			{
				UserProfile arg = new UserProfile(result.ResultDictionary);
				string[] arg2 = ImportFriends(result);
				if (this.OnLogin != null)
				{
					this.OnLogin(arg, arg2);
				}
			}
		});
	}

	private static string[] ImportFriends(IGraphResult result)
	{
		if (result.ResultDictionary.ContainsKey("friends"))
		{
			Dictionary<string, object> dictionary = result.ResultDictionary["friends"] as Dictionary<string, object>;
			List<object> list = dictionary["data"] as List<object>;
			string[] array = new string[list.Count];
			for (int i = 0; i < list.Count; i++)
			{
				Dictionary<string, object> dictionary2 = list[i] as Dictionary<string, object>;
				array[i] = (string)dictionary2["id"];
			}
			return array;
		}
		return null;
	}

	private void DeepLink()
	{
		FB.Mobile.FetchDeferredAppLinkData(delegate(IAppLinkResult result)
		{
			if (string.IsNullOrEmpty(result.Error) && !result.Cancelled)
			{
				string text = "?id=fb";
				if (!string.IsNullOrEmpty(result.TargetUrl) && result.TargetUrl.IndexOf(text) > -1)
				{
					int num = result.TargetUrl.IndexOf(text) + text.Length;
					int length = result.TargetUrl.Length - num;
					Debug.Log(result.TargetUrl.Substring(num, length));
					if (this.OnDeepLinkResult != null)
					{
						this.OnDeepLinkResult(result.TargetUrl.Substring(num, length));
					}
				}
			}
		});
	}

	private IEnumerator ShareImageShot()
	{
		yield return new WaitForEndOfFrame();
		Texture2D snap = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
		snap.ReadPixels(new Rect(0f, 0f, Screen.width, Screen.height), 0, 0);
		snap.Apply();
		byte[] screenshot = snap.EncodeToJPG();
		WWWForm wwwForm = new WWWForm();
		wwwForm.AddBinaryData("image", screenshot, "Screenshot.png");
		wwwForm.AddField("message", "Screenshot from The Dominoes.");
		wwwForm.AddField("no_story", "true");
		FB.API("me/photos", HttpMethod.POST, delegate(IGraphResult result)
		{
			SocialFBController socialFBController = this;
			Debug.Log(result.RawResult);
			if (string.IsNullOrEmpty(result.Error) && !result.Cancelled && result.RawResult.Contains("id"))
			{
				FB.API(string.Concat(result.ResultDictionary["id"], "/picture?redirect"), HttpMethod.GET, delegate(IGraphResult res)
				{
					Debug.Log(res.RawResult);
					if (string.IsNullOrEmpty(result.Error) && !result.Cancelled)
					{
						Debug.Log(((Dictionary<string, object>)res.ResultDictionary["data"])["url"]);
						string photoUrl = (string)((Dictionary<string, object>)res.ResultDictionary["data"])["url"];
						socialFBController.Share("Victory!", "I have just won the game in Dominoes.", photoUrl);
					}
				});
			}
		}, wwwForm);
	}

	public void Like()
	{
		FB.GameGroupJoin("...603164989869833", delegate(IGroupJoinResult result)
		{
			Debug.Log(result.RawResult);
		});
	}

	public void Request(string objectId)
	{
		FB.AppRequest("Please, give me an item!", null, new List<object> { "app_users" }, null, null, string.Empty, "Request item", delegate(IAppRequestResult result)
		{
			Debug.Log(result.RawResult);
			if (string.IsNullOrEmpty(result.Error) && !result.Cancelled && this.OnRequestResult != null)
			{
				this.OnRequestResult(new object[2]
				{
					objectId,
					result.To.ToArray()
				});
			}
		});
	}

	public void Send(string friendId)
	{
		FB.AppRequest("Take it and make it!", new List<string> { friendId }, null, null, null, string.Empty, "Send item", delegate(IAppRequestResult result)
		{
			Debug.Log(result.RawResult);
		});
	}

	private void SendFailed(string message)
	{
		if (this.OnFailed != null)
		{
			this.OnFailed(message);
		}
	}
}
