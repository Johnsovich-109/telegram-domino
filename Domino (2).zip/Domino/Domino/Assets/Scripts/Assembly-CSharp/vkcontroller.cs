using System;
using System.Collections.Generic;
using UnityEngine;
using com.playGenesis.VkUnityPlugin;
using com.playGenesis.VkUnityPlugin.MiniJSON;

public class vkcontroller : MonoBehaviour
{
	private void Start()
	{
		if (VkApi.VkApiInstance.IsUserLoggedIn)
		{
			onLoggedIn();
			return;
		}
		VkApi.VkApiInstance.LoggedIn += onLoggedIn;
		VkApi.VkApiInstance.Login();
	}

	public void onLoggedIn()
	{
		try
		{
			VkApi.VkApiInstance.LoggedIn -= onLoggedIn;
		}
		catch (Exception ex)
		{
			Debug.Log(ex.Message);
		}
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "users.get?user_ids=205387401&photo_50";
		vKRequest.CallBackFunction = OnGotUserInfo;
		VKRequest httprequest = vKRequest;
		VkApi.VkApiInstance.Call(httprequest);
	}

	public void OnGotUserInfo(VKRequest r)
	{
		if (r.error != null)
		{
			Debug.Log(r.error.error_msg);
			return;
		}
		Dictionary<string, object> dictionary = Json.Deserialize(r.response) as Dictionary<string, object>;
		List<object> list = (List<object>)dictionary["response"];
		VKUser vKUser = VKUser.Deserialize(list[0]);
		Debug.Log("user id is " + vKUser.id);
		Debug.Log("user name is " + vKUser.first_name);
		Debug.Log("user last name is " + vKUser.last_name);
	}
}
