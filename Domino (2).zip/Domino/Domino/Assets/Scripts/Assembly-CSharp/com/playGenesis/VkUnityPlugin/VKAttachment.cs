using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKAttachment
	{
		public string type { get; set; }

		public VKAudio audio { get; set; }

		public VKVideo video { get; set; }

		public VKPhoto photo { get; set; }

		public VKPoll poll { get; set; }

		public VKDocument doc { get; set; }

		public VKLink link { get; set; }

		public VKWallPost wall { get; set; }

		public VKNote note { get; set; }

		public VKPage Page { get; set; }

		public static VKAttachment Deserialize(object attachment)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)attachment;
			VKAttachment vKAttachment = new VKAttachment();
			object value;
			if (dictionary.TryGetValue("type", out value))
			{
				vKAttachment.type = (string)value;
			}
			object value2;
			if (dictionary.TryGetValue("audio", out value2))
			{
				vKAttachment.audio = VKAudio.Deserialize(value2);
			}
			object value3;
			if (dictionary.TryGetValue("photo", out value3))
			{
				vKAttachment.photo = VKPhoto.Deserialize(value3);
			}
			object value4;
			if (dictionary.TryGetValue("poll", out value4))
			{
				vKAttachment.poll = VKPoll.Deserialize(value4);
			}
			object value5;
			if (dictionary.TryGetValue("doc", out value5))
			{
				vKAttachment.doc = VKDocument.Deserialize(value5);
			}
			object value6;
			if (dictionary.TryGetValue("link", out value6))
			{
				vKAttachment.link = VKLink.Deserialize(value6);
			}
			object value7;
			if (dictionary.TryGetValue("wall", out value7))
			{
				vKAttachment.wall = VKWallPost.Deserialize(value7);
			}
			object value8;
			if (dictionary.TryGetValue("note", out value8))
			{
				vKAttachment.note = VKNote.Deserialize(value8);
			}
			object value9;
			if (dictionary.TryGetValue("Page", out value9))
			{
				vKAttachment.Page = VKPage.Deserialize(value9);
			}
			return vKAttachment;
		}
	}
}
