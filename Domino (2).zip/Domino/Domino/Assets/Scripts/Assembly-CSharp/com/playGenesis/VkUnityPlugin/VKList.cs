using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKList<T>
	{
		public int count { get; set; }

		public List<T> items { get; set; }
	}
}
