using System.Collections.Generic;
using System.Text;

namespace Dominoes
{
	public class PlayersController : List<Player>
	{
		public const int LocalIndex = 0;

		public readonly int StartBones;

		public Player Last;

		private int index;

		public Player Current
		{
			get
			{
				return base[index];
			}
		}

		public Player Local
		{
			get
			{
				return base[0];
			}
		}

		public int Index
		{
			get
			{
				return index;
			}
			set
			{
				index = value;
			}
		}

		public bool IsMyTurn
		{
			get
			{
				return index == 0;
			}
		}

		public PlayersController(int count)
			: base(count)
		{
			index = 0;
			for (int i = 0; i < count; i++)
			{
				Add(new Player(i));
			}
		}

		public void NewRound()
		{
			for (int i = 0; i < base.Count; i++)
			{
				base[i].NewRound();
			}
		}

		public void Distribution(Heap heap)
		{
			DebugF.LogError("Start dist: " + StartBones);
			for (int i = 0; i < base.Count; i++)
			{
				base[i].AddRange(heap.PullRandom(StartBones));
			}
		}

		public void Next()
		{
			index = (index + 1) % base.Count;
		}

		public void Scoring(int lastPlayer, GameState result)
		{
			if ((result & GameState.Won) == GameState.Won)
			{
				base[lastPlayer].CounterWin++;
			}
			if ((result & GameState.Block) == GameState.Block)
			{
				base[lastPlayer].CounterFish++;
			}
		}

		public int[] GetTotalScore()
		{
			int[] array = new int[base.Count];
			for (int i = 0; i < base.Count; i++)
			{
				array[i] = base[i].Score.Game + base[i].Score.Round;
			}
			return array;
		}

		public int[] GetAllScoreGame()
		{
			int[] array = new int[base.Count];
			for (int i = 0; i < base.Count; i++)
			{
				array[i] = base[i].Score.Game;
			}
			return array;
		}

		public int GetScoreTempMin()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Temp < base[result].Score.Temp)
				{
					result = i;
				}
			}
			return result;
		}

		public int GetScoreTempMax()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Temp > base[result].Score.Temp)
				{
					result = i;
				}
			}
			return result;
		}

		public int GetScoreRoundMin()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Round < base[result].Score.Round)
				{
					result = i;
				}
			}
			return result;
		}

		public int GetScoreRoundMax()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Round > base[result].Score.Round)
				{
					result = i;
				}
			}
			return result;
		}

		public int GetScoreGameMin()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Game < base[result].Score.Game)
				{
					result = i;
				}
			}
			return result;
		}

		public int GetScoreGameMax()
		{
			int result = 0;
			for (int i = 1; i < base.Count; i++)
			{
				if (base[i].Score.Game > base[result].Score.Game)
				{
					result = i;
				}
			}
			return result;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Player current = enumerator.Current;
					stringBuilder.AppendLine("Player " + current.Id + " : " + Utils.ToString(current));
				}
			}
			return stringBuilder.ToString();
		}
	}
}
