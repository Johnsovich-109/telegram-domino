using System;
using UnityEngine;

public class LeaderboardTimeChoose : MonoBehaviour
{
	public LeaderboardTimeItem[] times;

	private LeaderboardTimeItem selectItem;

	public LeaderboardTimeItem SelectItem
	{
		get
		{
			return selectItem;
		}
		set
		{
			if (selectItem != null)
			{
				selectItem.IsSelect = false;
			}
			selectItem = value;
			if (selectItem != null)
			{
				selectItem.IsSelect = true;
			}
		}
	}

	public event Action<string> OnClick;

	public void Select(string name)
	{
		SelectItem = GetItem(name);
	}

	private void Start()
	{
		LeaderboardTimeItem[] array = times;
		foreach (LeaderboardTimeItem leaderboardTimeItem in array)
		{
			leaderboardTimeItem.OnClick += Item_OnClick;
		}
	}

	private void Item_OnClick(LeaderboardTimeItem item)
	{
		SelectItem = item;
		if (this.OnClick != null)
		{
			this.OnClick(item.nameItem);
		}
	}

	private LeaderboardTimeItem GetItem(string name)
	{
		LeaderboardTimeItem[] array = times;
		foreach (LeaderboardTimeItem leaderboardTimeItem in array)
		{
			if (leaderboardTimeItem.nameItem == name)
			{
				return leaderboardTimeItem;
			}
		}
		return null;
	}
}
