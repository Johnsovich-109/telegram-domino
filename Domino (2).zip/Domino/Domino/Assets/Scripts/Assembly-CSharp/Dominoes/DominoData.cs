namespace Dominoes
{
	public static class DominoData
	{
		public const bool APPLICATION_RELEASE = false;

		public static GameCurrent GameCurrent;

		public static RoomInvite RoomInvite;

		public static GamesCollection Games;

		public static ShopCollection Shop;

		public static UserData User;

		public static GameValues Values;

		public static Responses Responses;

		public static Statistics Statistics;

		public static Bonus Bonus;

		public static BetsCollection Bets;

		private static bool modelInit;

		public static void ScenrAwake()
		{
			if (!modelInit)
			{
				Init();
				Statistics.Load();
				modelInit = true;
			}
		}

		private static void Init()
		{
			Games = new GamesCollection();
			Shop = new ShopCollection();
			User = new UserData();
			Values = new GameValues();
			Responses = new Responses();
			Statistics = new Statistics();
			Bonus = new Bonus();
			Bets = new BetsCollection();
		}

		public static void SceneDestroy()
		{
			Statistics.Save();
			Bonus.Save();
		}

		public static void SetInit(ResponseInit response)
		{
			Responses.init = response;
			if (response != null)
			{
				User.Name = response.username;
				Values.Balance = response.balance;
				Bonus.Set(response.bonus_timer, response.daily_bonus, response.daily_bonus_level, response.daily_reward);
				DominoSettings.AdsEnable = response.ad_enable;
			}
		}
	}
}
