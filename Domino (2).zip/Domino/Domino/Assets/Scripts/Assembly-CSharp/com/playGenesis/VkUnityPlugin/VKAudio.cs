using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKAudio
	{
		public long id { get; set; }

		public long owner_id { get; set; }

		public string artist { get; set; }

		public string title { get; set; }

		public int duration { get; set; }

		public string url { get; set; }

		public long lyrics_id { get; set; }

		public long album_id { get; set; }

		public long genre_id { get; set; }

		public static VKAudio Deserialize(object Audio)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)Audio;
			VKAudio vKAudio = new VKAudio();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKAudio.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("owner_id", out value2))
			{
				vKAudio.owner_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("artist", out value3))
			{
				vKAudio.artist = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("title", out value4))
			{
				vKAudio.title = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("duration", out value5))
			{
				vKAudio.duration = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("url", out value6))
			{
				vKAudio.url = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("lyrics_id", out value7))
			{
				vKAudio.lyrics_id = (long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("album_id", out value8))
			{
				vKAudio.album_id = (long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("genre_id", out value9))
			{
				vKAudio.genre_id = (long)value9;
			}
			return vKAudio;
		}
	}
}
