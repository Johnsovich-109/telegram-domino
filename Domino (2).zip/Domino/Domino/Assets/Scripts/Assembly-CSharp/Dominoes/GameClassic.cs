namespace Dominoes
{
	public class GameClassic : GameManager
	{
		private const int _numberBranches = 4;

		private const int _numberOfBoneValues = 7;

		public GameClassic(int players)
			: base(players, 4, 7)
		{
			numberBonesGive = 5;
			finalScore = 101;
			startDoubleArray = new int[7] { 1, 0, 2, 3, 4, 5, 6 };
		}
	}
}
