using System;
using System.Collections;
using System.Collections.Generic;

namespace Dominoes
{
	public class RoundOverData : IEnumerable
	{
		public class Player
		{
			private Dominoes.Player player;

			private List<BoneView> listBoneView;

			public int Id
			{
				get
				{
					return player.Id;
				}
			}

			public int ScoreRound
			{
				get
				{
					return player.Score.Round;
				}
			}

			public int ScoreBones
			{
				get
				{
					return player.Score.Bones;
				}
			}

			public int ScoreGame
			{
				get
				{
					return player.Score.Game;
				}
			}

			public List<BoneView> CollectionTile
			{
				get
				{
					return listBoneView;
				}
			}

			public ListBone CollectionBone
			{
				get
				{
					return player;
				}
			}

			public int Count
			{
				get
				{
					return listBoneView.Count;
				}
			}

			public Player(Dominoes.Player player, List<BoneView> collection)
			{
				this.player = player;
				listBoneView = collection;
				if (player.Count != collection.Count)
				{
					throw new Exception("Error: incorrect data. Player " + player.Id + ": Bones " + player.Count + "; Tiles " + collection.Count);
				}
			}
		}

		private List<Player> list;

		public Player this[int index]
		{
			get
			{
				return list[index];
			}
			protected set
			{
				list[index] = value;
			}
		}

		public int Count
		{
			get
			{
				return list.Count;
			}
		}

		public RoundOverData(int capacity)
		{
			list = new List<Player>(capacity);
		}

		public void Add(Dominoes.Player player, List<BoneView> collection)
		{
			list.Add(new Player(player, collection));
		}

		public void Add(Dominoes.Player player, BoneView[] collection)
		{
			list.Add(new Player(player, new List<BoneView>(collection)));
		}

		public void Add(Player data)
		{
			list.Add(data);
		}

		public IEnumerator GetEnumerator()
		{
			return list.GetEnumerator();
		}
	}
}
