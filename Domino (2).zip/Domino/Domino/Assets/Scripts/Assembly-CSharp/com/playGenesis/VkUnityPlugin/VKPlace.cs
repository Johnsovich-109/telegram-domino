using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPlace
	{
		public long id { get; set; }

		public string title { get; set; }

		public int latitude { get; set; }

		public int longitude { get; set; }

		public string type { get; set; }

		public long country { get; set; }

		public long city { get; set; }

		public string address { get; set; }

		public static VKPlace Deserialize(object place)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)place;
			VKPlace vKPlace = new VKPlace();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKPlace.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("title", out value2))
			{
				vKPlace.title = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("latitude", out value3))
			{
				vKPlace.latitude = (int)(long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("longitude", out value4))
			{
				vKPlace.longitude = (int)(long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("type", out value5))
			{
				vKPlace.type = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("country", out value6))
			{
				vKPlace.country = (long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("city", out value7))
			{
				vKPlace.city = (long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("address", out value8))
			{
				vKPlace.address = (string)value8;
			}
			return vKPlace;
		}
	}
}
