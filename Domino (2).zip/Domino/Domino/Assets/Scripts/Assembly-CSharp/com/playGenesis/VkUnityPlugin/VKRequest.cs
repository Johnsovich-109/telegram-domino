using System;

namespace com.playGenesis.VkUnityPlugin
{
	[Serializable]
	public class VKRequest
	{
		private string _url = string.Empty;

		public string fullurl = string.Empty;

		public string response;

		public Error error;

		public int attempt;

		public Action<VKRequest> CallBackFunction;

		public object[] data;

		public bool needsToBeeConfirmed;

		public string url
		{
			get
			{
				return _url;
			}
			set
			{
				_url = value;
				fullurl = string.Empty;
			}
		}
	}
}
