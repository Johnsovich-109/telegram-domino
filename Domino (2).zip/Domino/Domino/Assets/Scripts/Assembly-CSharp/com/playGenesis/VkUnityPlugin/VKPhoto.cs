using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPhoto
	{
		public long id { get; set; }

		public long album_id { get; set; }

		public long owner_id { get; set; }

		public long user_id { get; set; }

		public string photo_75 { get; set; }

		public string photo_130 { get; set; }

		public string photo_604 { get; set; }

		public string photo_807 { get; set; }

		public string photo_1280 { get; set; }

		public string photo_2560 { get; set; }

		public int width { get; set; }

		public int height { get; set; }

		public string text { get; set; }

		public int date { get; set; }

		public static VKPhoto Deserialize(object photo)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)photo;
			VKPhoto vKPhoto = new VKPhoto();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKPhoto.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("album_id", out value2))
			{
				vKPhoto.album_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("owner_id", out value3))
			{
				vKPhoto.owner_id = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("user_id", out value4))
			{
				vKPhoto.user_id = (long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("photo_75", out value5))
			{
				vKPhoto.photo_75 = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("photo_130", out value6))
			{
				vKPhoto.photo_130 = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("photo_604", out value7))
			{
				vKPhoto.photo_604 = (string)value7;
			}
			object value8;
			if (dictionary.TryGetValue("photo_807", out value8))
			{
				vKPhoto.photo_807 = (string)value8;
			}
			object value9;
			if (dictionary.TryGetValue("photo_1280", out value9))
			{
				vKPhoto.photo_1280 = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("photo_2560", out value10))
			{
				vKPhoto.photo_2560 = (string)value10;
			}
			object value11;
			if (dictionary.TryGetValue("width", out value11))
			{
				vKPhoto.width = (int)(long)value11;
			}
			object value12;
			if (dictionary.TryGetValue("height", out value12))
			{
				vKPhoto.height = (int)(long)value12;
			}
			object value13;
			if (dictionary.TryGetValue("text", out value13))
			{
				vKPhoto.text = (string)value13;
			}
			object value14;
			if (dictionary.TryGetValue("date", out value14))
			{
				vKPhoto.date = (int)(long)value14;
			}
			return vKPhoto;
		}
	}
}
