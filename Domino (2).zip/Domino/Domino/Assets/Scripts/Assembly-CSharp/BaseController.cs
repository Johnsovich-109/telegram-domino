using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseController : MonoBehaviour, IController
{
	protected Dictionary<string, IState> states;

	protected IState activeState;

	private bool initStates;

	public bool IsActive { get; set; }

	public abstract string GetName { get; }

	public abstract void OnActive(string oldController, object args);

	public abstract void OnInactive(string newController);

	public virtual void OnInit()
	{
		foreach (KeyValuePair<string, IState> state in states)
		{
			state.Value.OnInit();
		}
	}

	public virtual void OnEscape()
	{
		activeState.OnEscape();
	}

	public virtual void OnUpdate(float deltaTime)
	{
		activeState.OnUpdate(deltaTime);
	}

	public virtual void OnInvite()
	{
		activeState.OnInvite();
	}

	public void ChangeState(string newState, object args)
	{
		string getName = activeState.GetName;
		activeState.OnExit(newState);
		activeState.IsActive = false;
		activeState = states[newState];
		activeState.IsActive = true;
		activeState.OnEnter(getName, args);
	}

	public void Pause(float time, Action callback)
	{
		StartCoroutine(PauseInternal(time, callback));
	}

	public void Pause(int frames, Action callback)
	{
		StartCoroutine(PauseInternal(frames, callback));
	}

	protected void CheckInit()
	{
		if (!initStates)
		{
			OnInit();
			initStates = true;
		}
	}

	private IEnumerator PauseInternal(float time, Action callback)
	{
		yield return new WaitForSeconds(time);
		if (callback != null)
		{
			callback();
		}
	}

	private IEnumerator PauseInternal(int frames, Action callback)
	{
		while (frames-- > 0)
		{
			yield return null;
		}
		if (callback != null)
		{
			callback();
		}
	}
}
