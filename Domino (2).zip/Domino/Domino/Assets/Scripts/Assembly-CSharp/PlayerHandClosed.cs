using System;
using System.Collections;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;

public class PlayerHandClosed : PlayerHand
{
	public override void Sync(Player player)
	{
		base.Sync(player);
		foreach (BoneView item in collection)
		{
			item.node.localScale = scaleInHandVector;
			item.node.localPosition = Vector3.zero;
		}
	}

	public override void Push(Bone bone, BoneView tile, Action callback)
	{
		base.Push(bone, tile, callback);
		PushTile(tile, callback);
	}

	public override void Push(ListBone list, List<BoneView> tiles)
	{
		base.Push(list, tiles);
		StartCoroutine(PushInternal(tiles));
		StartCoroutine(SoundPlaying());
	}

	public override BoneView Pull(Bone bone)
	{
		return base.PullRandom();
	}

	public override BoneView PullRandom()
	{
		return base.PullRandom();
	}

	private void Awake()
	{
		scaleInHandVector = Vector3.one * scaleInHand;
	}

	private void Start()
	{
	}

	private IEnumerator PushInternal(List<BoneView> tiles)
	{
		foreach (BoneView item in tiles)
		{
			PushTile(item);
			yield return new WaitForSeconds(0.1f);
		}
	}

	private void PushTile(BoneView item, Action callback = null)
	{
		item.mover.Scale(scaleInHandVector, DominoSettings.TimeMoveBone);
		item.mover.Move(Vector3.zero, DominoSettings.TimeMoveBone, callback);
	}
}
