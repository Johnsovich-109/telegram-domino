using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKDocument
	{
		public long id { get; set; }

		public long owner_id { get; set; }

		private string title { get; set; }

		public long size { get; set; }

		public string ext { get; set; }

		public string url { get; set; }

		public string photo_100 { get; set; }

		public string photo_130 { get; set; }

		public static VKDocument Deserialize(object doc)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)doc;
			VKDocument vKDocument = new VKDocument();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKDocument.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("owner_id", out value2))
			{
				vKDocument.owner_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("title", out value3))
			{
				vKDocument.title = (string)value3;
			}
			object value4;
			if (dictionary.TryGetValue("size", out value4))
			{
				vKDocument.size = (long)value;
			}
			object value5;
			if (dictionary.TryGetValue("ext", out value5))
			{
				vKDocument.ext = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("url", out value6))
			{
				vKDocument.url = (string)value6;
			}
			object value7;
			if (dictionary.TryGetValue("photo_100", out value7))
			{
				vKDocument.photo_100 = (string)value7;
			}
			object value8;
			if (dictionary.TryGetValue("photo_130", out value8))
			{
				vKDocument.photo_130 = (string)value8;
			}
			return vKDocument;
		}
	}
}
