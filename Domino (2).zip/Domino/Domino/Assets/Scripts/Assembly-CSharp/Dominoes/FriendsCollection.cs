using System;
using System.Collections.Generic;

namespace Dominoes
{
	public class FriendsCollection
	{
		public List<PhotonFriend> online;

		public List<PhotonFriend> offline;

		public List<PhotonFriend> ignore;

		public List<PhotonFriend> select;

		private int size;

		private AuthType authType;

		public int Size
		{
			get
			{
				return size;
			}
		}

		public AuthType AuthType
		{
			get
			{
				return authType;
			}
		}

		public FriendsCollection(int size, AuthType authType)
		{
			this.authType = authType;
			this.size = size;
			select = new List<PhotonFriend>(size);
		}

		public void ReceivedFriends(Dictionary<string, object> dict)
		{
			online = GetList(dict["friends_online"] as List<object>);
			offline = GetList(dict["friends_offline"] as List<object>);
			ignore = GetList(dict["ignore"] as List<object>);
		}

		public void MoveToSelect(FriendData item)
		{
			if (online == null || online.Count == 0)
			{
				throw new Exception("List for select is empty");
			}
			MoveItem(online, select, item);
		}

		public void MoveToOnline(FriendData item)
		{
			if (select == null || select.Count == 0)
			{
				throw new Exception("List for select is empty");
			}
			MoveItem(select, online, item);
		}

		private void MoveItem(List<PhotonFriend> from, List<PhotonFriend> to, FriendData item)
		{
			int num = from.FindIndex((PhotonFriend x) => x.id == item.id);
			if (num < 0)
			{
				throw new Exception("This item not found");
			}
			if (to.Exists((PhotonFriend x) => x.id == item.id))
			{
				throw new Exception("This item is exist in list");
			}
			to.Add(from[num]);
			from.RemoveAt(num);
		}

		private List<PhotonFriend> GetList(List<object> list)
		{
			if (list == null || list.Count == 0)
			{
				return new List<PhotonFriend>();
			}
			List<PhotonFriend> list2 = new List<PhotonFriend>(list.Count);
			foreach (object item in list)
			{
				PhotonFriend current2 = new PhotonFriend(item as Dictionary<string, object>);
				if (!list2.Exists((PhotonFriend x) => x.id == current2.id))
				{
					list2.Add(current2);
				}
			}
			return list2;
		}

		private PhotonFriend Find(FriendData friend)
		{
			return online.FindLast((PhotonFriend x) => x.id == friend.id);
		}
	}
}
