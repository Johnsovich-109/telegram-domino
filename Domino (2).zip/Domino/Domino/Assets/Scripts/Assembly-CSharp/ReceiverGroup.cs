public enum ReceiverGroup : byte
{
	Others = 0,
	All = 1,
	MasterClient = 2
}
