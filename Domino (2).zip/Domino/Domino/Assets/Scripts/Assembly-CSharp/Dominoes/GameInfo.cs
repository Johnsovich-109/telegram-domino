namespace Dominoes
{
	public class GameInfo
	{
		public readonly GameType gameType;

		private bool singleEnable;

		private bool onlineEnable;

		public string Name
		{
			get
			{
				return gameType.ToString();
			}
		}

		public bool SingleEnable
		{
			get
			{
				return singleEnable;
			}
			set
			{
				singleEnable = value;
			}
		}

		public bool OnlineEnable
		{
			get
			{
				return onlineEnable;
			}
			set
			{
				onlineEnable = value;
			}
		}

		public string NameOnline
		{
			get
			{
				switch (gameType)
				{
				case GameType.AllFives:
					return "muggins";
				case GameType.BlockGame:
					return "block";
				case GameType.DrawGame:
					return "draw";
				case GameType.Kozel:
					return "kozel";
				default:
					return "unknown";
				}
			}
		}

		public GameInfo(GameType gameType)
			: this(gameType, true, false)
		{
		}

		public GameInfo(GameType gameType, bool singleEnable)
			: this(gameType, singleEnable, false)
		{
		}

		public GameInfo(GameType gameType, bool singleEnable, bool onlineEnable)
		{
			this.singleEnable = singleEnable;
			this.onlineEnable = onlineEnable;
			this.gameType = gameType;
		}

		public override string ToString()
		{
			return "GameInfo: " + Name + ". Enable: " + singleEnable;
		}
	}
}
