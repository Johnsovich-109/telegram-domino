using System.Collections.Generic;

public class ResponseBonus : ResponseBase
{
	public readonly int reward;

	public readonly int reward_2;

	public readonly int balance;

	public readonly int second_balance;

	public readonly int daily_bonus_level;

	public readonly int bonus_timer;

	public readonly int daily_next_reward;

	public ResponseBonus(Dictionary<string, object> dict)
		: base(dict)
	{
		reward = GetInt("reward ");
		reward_2 = GetInt("reward_2");
		balance = GetInt("balance");
		second_balance = GetInt("second_balance");
		daily_bonus_level = GetInt("daily_bonus_level");
		bonus_timer = GetInt("bonus_timer");
		daily_next_reward = GetInt("daily_next_reward");
	}
}
