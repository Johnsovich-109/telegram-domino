using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKPollAnswer
	{
		public long id { get; set; }

		public string text { get; set; }

		public int votes { get; set; }

		public double rate { get; set; }

		public static VKPollAnswer Dererialize(object answer)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)answer;
			VKPollAnswer vKPollAnswer = new VKPollAnswer();
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKPollAnswer.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("text", out value2))
			{
				vKPollAnswer.text = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("votes", out value3))
			{
				vKPollAnswer.votes = (int)(long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("rate", out value4))
			{
				vKPollAnswer.rate = (double)value4;
			}
			return vKPollAnswer;
		}
	}
}
