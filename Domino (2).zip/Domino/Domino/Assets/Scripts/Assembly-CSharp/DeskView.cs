using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class DeskView : MonoBehaviour
{
	private const int capacity = 28;

	public Text textGameName;

	internal Transform node;

	internal RectTransform nodeUI;

	internal BoneView tileSpinner;

	internal Vector2 sizeReal;

	private float _scale;

	private float maxScale = 0.6f;

	private float minScale = 0.25f;

	private DominoPool pool;

	private List<BoneView> collection;

	private List<DeskBranch> branches;

	private List<BonePhantom> phantoms;

	private float[] tableScales;

	public float Scale
	{
		get
		{
			return _scale;
		}
		set
		{
			_scale = value;
			sizeReal = sizeTile * value;
		}
	}

	public BoneView this[Bone bone]
	{
		get
		{
			return collection.Find((BoneView x) => x.Bone.Equals(bone));
		}
	}

	public bool IsEmpty
	{
		get
		{
			return collection.Count == 0;
		}
	}

	public string GameName
	{
		get
		{
			return textGameName.text;
		}
		set
		{
			textGameName.text = TextManager.GetString(value);
		}
	}

	internal Vector2 sizeTile
	{
		get
		{
			return new Vector2(pool.sizeTile.width, pool.sizeTile.height) * 1.01f;
		}
	}

	public void NewGame(int countBranches)
	{
		tileSpinner = null;
		collection = new List<BoneView>(28);
		branches = new List<DeskBranch>(countBranches);
		for (int i = 0; i < countBranches; i++)
		{
			branches.Add(new DeskBranch(i, this));
		}
	}

	public void NewRound()
	{
		ResetInternal();
	}

	public void Sync(Desk desk)
	{
		ResetInternal();
		if (desk.CountBones == 0)
		{
			return;
		}
		for (int i = 0; i < desk.Count; i++)
		{
			for (int j = ((i != 0) ? 1 : 0); j < desk[i].Count; j++)
			{
				BoneView boneView = pool.PullTile();
				boneView.Show(desk[i][j]);
				AddTile(i, boneView);
			}
		}
		SelectScale();
		SetAlignSpinner();
		DeskBuild();
		AlignField();
		Vector3 localScale = Vector3.one * Scale;
		foreach (BoneView item in collection)
		{
			item.node.localPosition = item.TestPosition;
			item.node.localScale = localScale;
			item.node.localRotation = Quaternion.Euler(0f, 0f, 90f * (float)item.TestRotate);
			item.PointNormalization();
		}
	}

	public void Turn(int i, BoneView tile, Action callback)
	{
		AddTile(i, tile);
		SelectScale();
		SetAlignSpinner();
		DeskBuild();
		AlignField();
		Commit();
		StartCoroutine(Tools.Pause(DominoSettings.TimeMoveBone, delegate
		{
			GameSounds.Play(SoundType.Tile);
			callback();
		}));
	}

	public IEnumerable<BoneView> PullAll()
	{
		List<BoneView> result = collection;
		collection = new List<BoneView>(28);
		return result;
	}

	private void ResetInternal()
	{
		tileSpinner = null;
		collection.Clear();
		foreach (DeskBranch branch in branches)
		{
			branch.Reset();
		}
	}

	private void SelectScale()
	{
		Scale = tableScales[collection.Count];
	}

	private void SetSpinner(BoneView tile)
	{
		tileSpinner = tile;
		if (tile.Bone.IsDouble)
		{
			tile.TestRotate = 0;
		}
		else
		{
			tile.TestRotate = 1;
		}
	}

	private void AddTile(int index, BoneView tile)
	{
		tile.node.SetParent(node);
		collection.Add(tile);
		if (collection.Count == 1)
		{
			AddFirstTile(tile);
		}
		else
		{
			AddNextTile(index, tile);
		}
	}

	private void AddNextTile(int index, BoneView tile)
	{
		if (!tileSpinner.Bone.IsDouble && tile.Bone.IsDouble)
		{
			int index2 = (index + 1) % 2;
			List<BoneView> concatinecteCollection = GetConcatinecteCollection(branches[index], branches[index2]);
			for (int i = 0; i < branches.Count; i++)
			{
				branches[i].Add(tile);
			}
			SetSpinner(tile);
			branches[index2].AddRange(concatinecteCollection);
		}
		else
		{
			branches[index].Add(tile);
		}
	}

	private List<BoneView> GetConcatinecteCollection(DeskBranch source, DeskBranch receiver)
	{
		List<BoneView> list = new List<BoneView>(source.Count + receiver.Count);
		for (int num = source.Count - 1; num > 0; num--)
		{
			list.Add(source[num]);
		}
		for (int i = 0; i < receiver.Count; i++)
		{
			list.Add(receiver[i]);
		}
		source.Clear();
		receiver.Clear();
		return list;
	}

	private void AddFirstTile(BoneView tile)
	{
		if (tile.Bone.IsDouble)
		{
			for (int i = 0; i < branches.Count; i++)
			{
				branches[i].Add(tile);
			}
		}
		else
		{
			for (int j = 0; j < 2; j++)
			{
				branches[j].Add(tile);
			}
		}
		SetSpinner(tile);
	}

	private void SetAlignSpinner()
	{
		float num = (float)branches[0].Count / (float)(branches[0].Count + branches[1].Count) - 0.5f;
		float num2 = num;
		if (branches.Count > 2 && (branches[2].Count > 0 || branches[3].Count > 0))
		{
			num2 = 0.5f - (float)branches[2].Count / (float)(branches[2].Count + branches[3].Count);
		}
		tileSpinner.TestPosition = new Vector3((nodeUI.rect.width - sizeReal.x) * num, (nodeUI.rect.height - sizeReal.y) * num2);
	}

	private void DeskBuild()
	{
		foreach (DeskBranch branch in branches)
		{
			branch.Build();
		}
	}

	private void AlignField()
	{
		if (collection.Count <= 1)
		{
			return;
		}
		Vector2 vector = collection[0].TestPosition;
		Vector2 vector2 = vector;
		foreach (BoneView item in collection)
		{
			Vector3 testPosition = item.TestPosition;
			if (testPosition.x < vector.x)
			{
				vector.x = testPosition.x;
			}
			else if (testPosition.x > vector2.x)
			{
				vector2.x = testPosition.x;
			}
			if (testPosition.y < vector.y)
			{
				vector.y = testPosition.y;
			}
			else if (testPosition.y > vector2.y)
			{
				vector2.y = testPosition.y;
			}
		}
		Vector3 vector3 = (vector + vector2) * 0.5f;
		foreach (BoneView item2 in collection)
		{
			item2.TestPosition -= vector3;
		}
	}

	private void Commit()
	{
		Vector3 to = Vector3.one * Scale;
		foreach (BoneView item in collection)
		{
			item.mover.Move(item.TestPosition, DominoSettings.TimeMoveBone);
			item.mover.Scale(to, DominoSettings.TimeMoveBone);
			item.mover.Rotate(Quaternion.Euler(0f, 0f, 90f * (float)item.TestRotate), DominoSettings.TimeMoveBone, item.PointNormalization);
		}
	}

	private void Awake()
	{
		node = base.transform;
		nodeUI = node as RectTransform;
		collection = new List<BoneView>(28);
	}

	private void Start()
	{
		pool = DominoPool.instance;
		tableScales = new float[56];
		tableScales[0] = maxScale;
		for (int i = 1; i < tableScales.Length; i++)
		{
			if ((tableScales[i] = tableScales[i - 1] * 0.92f) < minScale)
			{
				tableScales[i] = minScale;
			}
		}
	}

	public void SetBacklight(BoneHandleMove handle)
	{
		if (handle == null)
		{
			SetBacklightHide();
		}
		else if (IsEmpty)
		{
			SetBacklightEmpty(handle);
		}
		else
		{
			SetBacklightShow(handle);
		}
	}

	private void SetBacklightEmpty(BoneHandleMove handle)
	{
		if (phantoms == null)
		{
			BonePhantom bonePhantom = pool.PullPhantom();
			phantoms = new List<BonePhantom> { bonePhantom };
			bonePhantom.Show(node);
			bonePhantom.Scale = maxScale;
		}
	}

	private void SetBacklightShow(BoneHandleMove handle)
	{
		int count = handle.TileDesk.Count;
		BonePhantom[] array = pool.PullPhantom(count);
		for (int i = 0; i < count; i++)
		{
			array[i].Show(handle.TileDesk[i].node);
		}
		if (phantoms == null)
		{
			phantoms = new List<BonePhantom>(count);
		}
		phantoms.AddRange(array);
	}

	private void SetBacklightHide()
	{
		if (phantoms == null)
		{
			return;
		}
		foreach (BonePhantom item in phantoms)
		{
			item.Hide(delegate
			{
				pool.PushPhantom(item);
			});
		}
		phantoms = null;
	}
}
