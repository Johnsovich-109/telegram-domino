using System;
using System.Collections.Generic;
using MiniJSON;
using UnityEngine;
using com.playGenesis.VkUnityPlugin;

public class SocialVKController : MonoBehaviour
{
	public static SocialVKController instance;

	public VkApi vk;

	public event Action<string> OnFailed;

	public event Action<UserProfile> OnLoggedIn;

	public event Action OnLoggedOut;

	public event Action<VKFriendsList> OnImportFriends;

	public event Action OnJoingGroup;

	public event Action<bool> OnStateLogin;

	public void Login()
	{
		if (vk.IsUserLoggedIn)
		{
			VK_LoggedIn();
		}
		else
		{
			vk.Login();
		}
	}

	public void Logout()
	{
		vk.Logout();
	}

	public void ImportFriends()
	{
		if (vk.IsUserLoggedIn)
		{
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "friends.get?user_id=" + VkApi.CurrentToken.user_id + "&order=hints&fields=photo_50";
			vKRequest.CallBackFunction = HandleImportFriends;
			VKRequest httprequest = vKRequest;
			vk.Call(httprequest);
		}
		else
		{
			vk.Login();
		}
	}

	public void InviteVKFriend(string idFriend)
	{
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "apps.sendRequest?user_id=" + idFriend + "&text=Готов забить козла?&type=invite";
		vKRequest.CallBackFunction = HandleVkInviteFriend;
		VKRequest httprequest = vKRequest;
		vk.Call(httprequest);
	}

	public void Share()
	{
		Share("Готов забить козла?", "https://vk.com/club149536085");
	}

	public void Share(string msg, string link)
	{
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "wall.post?owner_id=" + VkApi.CurrentToken.user_id + "&message=" + msg + "&attachments=photo-149536085_456239017," + link + "&v=5.50&access_token=" + VkApi.CurrentToken.access_token;
		vKRequest.CallBackFunction = HandleShare;
		VKRequest httprequest = vKRequest;
		vk.Call(httprequest);
	}

	public void JoinVkGroup(int grpJoinIndex)
	{
		string text = string.Empty;
		switch (grpJoinIndex)
		{
		case 0:
			text = "149536085";
			break;
		case 1:
			text = "78616012";
			break;
		}
		VKRequest vKRequest = new VKRequest();
		vKRequest.url = "groups.join?group_id=" + text + "&v=5.50";
		vKRequest.CallBackFunction = HandleVkJoinGroup;
		VKRequest httprequest = vKRequest;
		vk.Call(httprequest);
	}

	private void HandleVkJoinGroup(VKRequest arg)
	{
		Debug.LogError("VK ERROR: " + arg.error);
		if (arg.error != null)
		{
			if (arg.error.error_code == "5" || arg.error.error_code == "15")
			{
				vk.Login();
			}
			GlobalErrorHandler globalErrorHandler = UnityEngine.Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(arg);
			}
		}
		else if (this.OnJoingGroup != null)
		{
			this.OnJoingGroup();
		}
	}

	private void HandleVkInviteFriend(VKRequest arg)
	{
		if (arg.error != null)
		{
			Debug.Log("HandleVkInviteFriend ERROR");
			Debug.LogError(arg.error.error_code);
			Debug.LogError(arg.error.error_msg);
			GlobalErrorHandler globalErrorHandler = UnityEngine.Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(arg);
			}
		}
		else
		{
			Debug.LogError(arg.response);
		}
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		if (vk == null)
		{
			vk = VkApi.VkApiInstance;
		}
		vk.LoggedIn += VK_LoggedIn;
		vk.LoggedOut += VK_LoggedOut;
		vk.AccessDenied += Vk_AccessDenied;
	}

	public void CheckStateLogin()
	{
		if (vk.IsUserLoggedIn)
		{
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "users.get?user_id=" + VkApi.CurrentToken.user_id + "&fields=photo_200";
			vKRequest.CallBackFunction = HandleResponseRecieved1;
			VKRequest httprequest = vKRequest;
			vk.Call(httprequest);
		}
		else if (this.OnStateLogin != null)
		{
			this.OnStateLogin(false);
		}
	}

	private void HandleResponseRecieved1(VKRequest request)
	{
		if (this.OnStateLogin != null)
		{
			this.OnStateLogin(request.error == null || request.error.error_code != "5");
		}
	}

	private void VK_LoggedIn()
	{
		if (vk.IsUserLoggedIn)
		{
			VKRequest vKRequest = new VKRequest();
			vKRequest.url = "users.get?user_id=" + VkApi.CurrentToken.user_id + "&fields=photo_200";
			vKRequest.CallBackFunction = HandleResponseRecieved;
			VKRequest httprequest = vKRequest;
			vk.Call(httprequest);
		}
		else
		{
			SendFailed("login");
		}
	}

	private void VK_LoggedOut()
	{
		if (this.OnLoggedOut != null)
		{
			this.OnLoggedOut();
		}
	}

	private void Vk_AccessDenied(object sender, Error e)
	{
		SendFailed("AccessDenied");
	}

	private void HandleImportFriends(VKRequest arg1)
	{
		if (arg1.error == null)
		{
			Debug.LogError(arg1.response);
			VKFriendsList obj = new VKFriendsList(arg1.response);
			if (this.OnImportFriends != null)
			{
				this.OnImportFriends(obj);
			}
		}
		else
		{
			DebugF.LogError(arg1.error.error_msg);
			SendFailed("get_friends");
		}
	}

	private void HandleResponseRecieved(VKRequest request)
	{
		if (request.error != null)
		{
			Debug.LogError("VK >> GET USER DATA FAILED");
			if (request.error.error_code == "5")
			{
				vk.Login();
			}
			else
			{
				SendFailed("get_info");
			}
			GlobalErrorHandler globalErrorHandler = UnityEngine.Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(request);
			}
		}
		else
		{
			Debug.Log("Vk response: \n\n\n" + request.response);
			ImportFriends();
			Profile(Json.Deserialize(request.response) as Dictionary<string, object>);
		}
	}

	private void HandleShare(VKRequest arg)
	{
		if (arg.error != null)
		{
			if (arg.error.error_code == "5" || arg.error.error_code == "15")
			{
				vk.Login();
			}
			GlobalErrorHandler globalErrorHandler = UnityEngine.Object.FindObjectOfType<GlobalErrorHandler>();
			if (globalErrorHandler != null)
			{
				globalErrorHandler.Notification.Notify(arg);
			}
		}
	}

	private void Profile(Dictionary<string, object> response)
	{
		List<object> list = response["response"] as List<object>;
		if (list == null || list.Count == 0)
		{
			SendFailed("don't_data");
			return;
		}
		UserProfile obj = new UserProfile(list[0] as Dictionary<string, object>);
		if (this.OnLoggedIn != null)
		{
			this.OnLoggedIn(obj);
		}
	}

	private void SendFailed(string message)
	{
		if (this.OnFailed != null)
		{
			this.OnFailed(message);
		}
	}
}
