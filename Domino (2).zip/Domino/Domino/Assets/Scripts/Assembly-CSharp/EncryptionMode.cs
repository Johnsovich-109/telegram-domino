public enum EncryptionMode
{
	PayloadEncryption = 0,
	DatagramEncryption = 10
}
