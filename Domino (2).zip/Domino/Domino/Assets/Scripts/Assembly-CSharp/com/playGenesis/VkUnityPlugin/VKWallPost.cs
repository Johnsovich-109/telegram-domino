using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKWallPost
	{
		public long id { get; set; }

		public long owner_id { get; set; }

		public long from_id { get; set; }

		public long date { get; set; }

		public string text { get; set; }

		public long reply_owner_id { get; set; }

		public long reply_post_id { get; set; }

		public int friends_only { get; set; }

		public VKComments comments { get; set; }

		public VKLikes likes { get; set; }

		public VKReposts reposts { get; set; }

		public string post_type { get; set; }

		public VKPostSource post_source { get; set; }

		public List<VKAttachment> attachments { get; set; }

		public VKGeo geo { get; set; }

		public long signer_id { get; set; }

		public List<VKWallPost> copy_history { get; set; }

		public int can_pin { get; set; }

		public int is_pinned { get; set; }

		public static VKWallPost Deserialize(object WallPost)
		{
			VKWallPost vKWallPost = new VKWallPost();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)WallPost;
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKWallPost.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("owner_id", out value2))
			{
				vKWallPost.owner_id = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("from_id", out value3))
			{
				vKWallPost.from_id = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("date", out value4))
			{
				vKWallPost.date = (long)value4;
			}
			object value5;
			if (dictionary.TryGetValue("text", out value5))
			{
				vKWallPost.text = (string)value5;
			}
			object value6;
			if (dictionary.TryGetValue("reply_owner_id", out value6))
			{
				vKWallPost.reply_owner_id = (long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("reply_post_id", out value7))
			{
				vKWallPost.reply_post_id = (long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("friends_only", out value8))
			{
				vKWallPost.friends_only = (int)(long)value8;
			}
			object value9;
			if (dictionary.TryGetValue("comments", out value9))
			{
				vKWallPost.comments = VKComments.Deserialize(value9);
			}
			object value10;
			if (dictionary.TryGetValue("likes", out value10))
			{
				vKWallPost.likes = VKLikes.Deserialize(value10);
			}
			object value11;
			if (dictionary.TryGetValue("reposts", out value11))
			{
				vKWallPost.reposts = VKReposts.Deserialize(value11);
			}
			object value12;
			if (dictionary.TryGetValue("post_type", out value12))
			{
				vKWallPost.post_type = (string)value12;
			}
			object value13;
			if (dictionary.TryGetValue("post_source", out value13))
			{
				vKWallPost.post_source = VKPostSource.Deserialize(value13);
			}
			object value14;
			if (dictionary.TryGetValue("attachments", out value14))
			{
				List<VKAttachment> list = new List<VKAttachment>();
				foreach (object item in (List<object>)value14)
				{
					list.Add(VKAttachment.Deserialize(item));
				}
				vKWallPost.attachments = list;
			}
			object value15;
			if (dictionary.TryGetValue("geo", out value15))
			{
				vKWallPost.geo = VKGeo.Deserialize(value15);
			}
			object value16;
			if (dictionary.TryGetValue("signer_id", out value16))
			{
				vKWallPost.signer_id = (long)value16;
			}
			object value17;
			if (dictionary.TryGetValue("copy_history", out value17))
			{
				List<VKWallPost> list2 = new List<VKWallPost>();
				foreach (object item2 in (List<object>)value17)
				{
					list2.Add(Deserialize(item2));
				}
				vKWallPost.copy_history = list2;
			}
			object value18;
			if (dictionary.TryGetValue("can_pin", out value18))
			{
				vKWallPost.can_pin = (int)(long)value18;
			}
			object value19;
			if (dictionary.TryGetValue("is_pinned", out value19))
			{
				vKWallPost.is_pinned = (int)(long)value19;
			}
			return vKWallPost;
		}
	}
}
