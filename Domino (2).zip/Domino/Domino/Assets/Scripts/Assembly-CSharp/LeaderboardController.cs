using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class LeaderboardController : PopupBehaviour
{
	public Text textTitle;

	public LeaderboardTimeChoose times;

	public LeaderboardGames games;

	public LeaderboardLeaders leaders;

	public LeaderboardPlayers players;

	public Transform loader;

	private bool activeLoader;

	private float deltaTimeLoader = 0.1f;

	private float counterTime;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public event Action<string> OnClick;

	public void Show(ResponseLeaderboard response)
	{
		bool flag = response != null;
		leaders.SetVisibility(flag);
		players.SetVisibility(flag);
		activeLoader = !flag;
		loader.gameObject.SetActive(activeLoader);
		if (flag)
		{
			leaders.SetData(response.top);
			players.SetData(response.scores);
		}
		base.Show();
	}

	public void SetGames(GameInfo[] activeGames)
	{
		games.SetGames(activeGames);
	}

	public override void Hide()
	{
		base.Hide();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
	}

	private void Update()
	{
		if (activeLoader && (counterTime += Time.deltaTime) > deltaTimeLoader)
		{
			counterTime -= deltaTimeLoader;
			loader.Rotate(0f, 0f, -43f);
		}
	}
}
