using Dominoes;
using UnityEngine.UI;

public class PanelBranchValues : EmergenceByAlphaUI
{
	public Text textSummBranches;

	public Text[] textBranches;

	public new void Show()
	{
		if (!base.IsShow)
		{
			base.ActiveSelf = true;
			EmergenceShow();
		}
	}

	public new void Hide()
	{
		if (base.IsShow)
		{
			EmergenceHide();
		}
	}

	public void NewRound()
	{
		textSummBranches.text = "0";
		for (int i = 0; i < textBranches.Length; i++)
		{
			textBranches[i].text = "0";
		}
	}

	public void Set(ScoreBranches scores)
	{
		textSummBranches.text = scores.Summ.ToString();
		for (int i = 0; i < textBranches.Length && i < scores.Count; i++)
		{
			textBranches[i].text = scores[i].ToString();
		}
	}

	private void Awake()
	{
	}

	private void Start()
	{
		EmergenceReset();
		base.ActiveSelf = false;
		ResetScores();
	}

	private void OnHidden()
	{
		base.ActiveSelf = false;
	}

	private void ResetScores()
	{
		textSummBranches.text = "0";
		for (int i = 0; i < textBranches.Length; i++)
		{
			textBranches[i].text = "0";
		}
	}
}
