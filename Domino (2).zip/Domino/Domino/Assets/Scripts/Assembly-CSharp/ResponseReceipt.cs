using System.Collections.Generic;

public class ResponseReceipt : ResponseBase
{
	public readonly int balance;

	public readonly int second_balance;

	public readonly string transactionId;

	public readonly string msg;

	public readonly int amount;

	public ResponseReceipt(Dictionary<string, object> dict)
		: base(dict)
	{
		object value;
		if (dict.TryGetValue("balance", out value))
		{
			balance = (int)(long)value;
		}
		if (dict.TryGetValue("second_balance", out value))
		{
			second_balance = (int)(long)value;
		}
		if (dict.TryGetValue("transactionId", out value))
		{
			transactionId = (string)value;
		}
		if (dict.TryGetValue("msg", out value))
		{
			msg = (string)value;
		}
		if (dict.TryGetValue("amount", out value))
		{
			amount = (int)(long)value;
		}
	}
}
