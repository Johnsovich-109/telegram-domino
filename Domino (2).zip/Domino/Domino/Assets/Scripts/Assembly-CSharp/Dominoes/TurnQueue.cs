using System.Collections.Generic;

namespace Dominoes
{
	public class TurnQueue
	{
		private Queue<Turn> queue;

		private Turn last;

		public Turn Peek
		{
			get
			{
				return (queue.Count <= 0) ? null : queue.Peek();
			}
		}

		public Turn Last
		{
			get
			{
				return last;
			}
			private set
			{
				queue.Enqueue(last = value);
			}
		}

		public int Count
		{
			get
			{
				return queue.Count;
			}
		}

		public TurnQueue()
		{
			queue = new Queue<Turn>(3);
		}

		public Turn Check(Player player)
		{
			if (last == null || last.player.Id != player.Id)
			{
				Last = new Turn(player);
			}
			return last;
		}

		public void Next()
		{
			if (queue.Count > 0)
			{
				queue.Dequeue();
			}
			if (queue.Count == 0)
			{
				last = null;
			}
		}

		public void Clear()
		{
			last = null;
			queue.Clear();
		}
	}
}
