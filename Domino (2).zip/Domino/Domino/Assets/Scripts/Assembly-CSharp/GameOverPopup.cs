using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class GameOverPopup : TableStatisticPopup
{
	public Text[] textButtons;

	public Text textTitle;

	public Text textShareFriends;

	public Toggle toggle;

	public Transform buttonLeft;

	public Transform buttonCenter;

	public Transform buttonQuit;

	public GameObject buttonAgain;

	public float heightShowToggle;

	public float heightHideToggle;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool IsCheckShare
	{
		get
		{
			return toggle.isOn;
		}
		set
		{
			toggle.isOn = value;
		}
	}

	public bool IsToggleShow
	{
		get
		{
			return toggle.gameObject.activeSelf;
		}
		set
		{
			toggle.gameObject.SetActive(value);
			SetHeight((!value) ? heightHideToggle : heightShowToggle);
		}
	}

	public event Action<string> OnClick;

	public event Action<bool> OnCheckShare;

	public override void Show()
	{
		if (base.IsHide)
		{
			GameSounds.Play(SoundType.GameOver);
		}
		base.Show();
	}

	public void Refresh(ScoresController scores, int showRankIndex)
	{
		Refresh(scores);
		for (int i = 0; i < base.Count; i++)
		{
			(listColumns[i] as GameOverColumn).IsRankShow = showRankIndex == 0;
		}
	}

	public override void Refresh(ScoresController scores)
	{
		base.Count = scores.Count;
		for (int i = 0; i < base.Count; i++)
		{
			(listColumns[i] as GameOverColumn).Refresh(scores[i]);
		}
		for (int j = 0; j < base.Count; j++)
		{
			(listColumns[j] as GameOverColumn).IsRankShow = j == 0;
		}
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	public void ToggleValueChange(bool state)
	{
		if (this.OnCheckShare != null)
		{
			this.OnCheckShare(state);
		}
	}

	public void ShowButton(bool playAgain)
	{
		buttonAgain.SetActive(playAgain);
		buttonQuit.transform.localPosition = ((!playAgain) ? buttonCenter.localPosition : buttonLeft.localPosition);
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		textShareFriends.text = TextManager.GetString("ShareGameOver").ToUpper();
		Text[] array = textButtons;
		foreach (Text text in array)
		{
			text.text = TextManager.GetString(text.text);
		}
	}

	private void SetHeight(float height)
	{
		RectTransform rectTransform = base.transform as RectTransform;
		rectTransform.sizeDelta = new Vector2(rectTransform.sizeDelta.x, height);
	}
}
