using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKSchool
	{
		public long id { get; set; }

		public long country { get; set; }

		public long city { get; set; }

		public string name { get; set; }

		public int year_from { get; set; }

		public int year_to { get; set; }

		public int year_graduated { get; set; }

		public string @class { get; set; }

		public string speciality { get; set; }

		public long type { get; set; }

		public string type_str { get; set; }

		public static VKSchool Deserialize(object School)
		{
			VKSchool vKSchool = new VKSchool();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)School;
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKSchool.id = (long)value;
			}
			object value2;
			if (dictionary.TryGetValue("country", out value2))
			{
				vKSchool.country = (long)value2;
			}
			object value3;
			if (dictionary.TryGetValue("city", out value3))
			{
				vKSchool.city = (long)value3;
			}
			object value4;
			if (dictionary.TryGetValue("name", out value4))
			{
				vKSchool.name = (string)value4;
			}
			object value5;
			if (dictionary.TryGetValue("year_from", out value5))
			{
				vKSchool.year_from = (int)(long)value5;
			}
			object value6;
			if (dictionary.TryGetValue("year_to", out value6))
			{
				vKSchool.year_to = (int)(long)value6;
			}
			object value7;
			if (dictionary.TryGetValue("year_graduated", out value7))
			{
				vKSchool.year_graduated = (int)(long)value7;
			}
			object value8;
			if (dictionary.TryGetValue("class", out value8))
			{
				vKSchool.@class = (string)value8;
			}
			object value9;
			if (dictionary.TryGetValue("speciality", out value9))
			{
				vKSchool.speciality = (string)value9;
			}
			object value10;
			if (dictionary.TryGetValue("type", out value10))
			{
				vKSchool.type = (long)value10;
			}
			object value11;
			if (dictionary.TryGetValue("type_str", out value11))
			{
				vKSchool.type_str = (string)value11;
			}
			return vKSchool;
		}
	}
}
