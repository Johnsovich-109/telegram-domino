using System;
using ExitGames.Client.Photon;

public class OnlineGameResult
{
	public readonly int Count;

	public string Status;

	public int[] BalanceChanges;

	public int ExpAdded;

	public int[] Balances;

	public int[] CurrentRating;

	public int[] DiffRating;

	private Hashtable hashtable;

	private object this[byte key]
	{
		get
		{
			return hashtable[key];
		}
	}

	public OnlineGameResult(Hashtable hashtable, Func<int, int> function)
	{
		this.hashtable = hashtable;
		Status = (string)this[0];
		BalanceChanges = (int[])this[1];
		ExpAdded = (int)this[2];
		Balances = (int[])this[3];
		CurrentRating = (int[])this[4];
		DiffRating = (int[])this[5];
		Count = Balances.Length;
		TranslatorIndexes(function);
	}

	private void TranslatorIndexes(Func<int, int> function)
	{
		BalanceChanges = IndexTranslatorInArray(function, BalanceChanges);
		Balances = IndexTranslatorInArray(function, Balances);
		CurrentRating = IndexTranslatorInArray(function, CurrentRating);
		DiffRating = IndexTranslatorInArray(function, DiffRating);
	}

	private int[] IndexTranslatorInArray(Func<int, int> function, int[] array)
	{
		int[] array2 = new int[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array2[function(i + 1)] = array[i];
		}
		return array2;
	}
}
