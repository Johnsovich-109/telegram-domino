public class OSSubscriptionState
{
	public bool userSubscriptionSetting;

	public string userId;

	public string pushToken;

	public bool subscribed;
}
