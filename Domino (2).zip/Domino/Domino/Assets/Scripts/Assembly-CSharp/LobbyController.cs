using System.Collections.Generic;
using Dominoes;
using UnityEngine;

using UnityEngine.Purchasing;

public class LobbyController : BaseController, IController
{
	private abstract class BaseLobbyState : BaseState, IState
	{
		protected LobbyController controller;

		protected LobbyCanvas Lobby
		{
			get
			{
				return LobbyCanvas.instance;
			}
		}

		protected WebManager Web
		{
			get
			{
				return WebManager.instance;
			}
		}

		protected PopupsLobby LobbyPopups
		{
			get
			{
				return PopupsLobby.instance;
			}
		}

		protected ShopController ShopView
		{
			get
			{
				return PopupsLobby.instance.shop;
			}
		}

		protected LeaderboardController Leaderboard
		{
			get
			{
				return PopupsLobby.instance.leaderboard;
			}
		}

		protected ProfileSettingController ProfileView
		{
			get
			{
				return PopupsLobby.instance.profile;
			}
		}

		protected MessagePopupAdvanced Message
		{
			get
			{
				return PopupsLobby.instance.message;
			}
		}

		protected LobbyBonusView BonusView
		{
			get
			{
				return LobbyBonusView.instance;
			}
		}

		public override void OnInvite()
		{
			ChangeState("Finish", "Online");
		}

		protected void ChangeState(string state)
		{
			ChangeState(state, null);
		}

		protected void ChangeState(string state, object args)
		{
			controller.ChangeState(state, args);
		}

		protected void ProfileRefresh()
		{
			Lobby.profileView.Username = DominoData.User.Name;
			Lobby.profileView.Balance = DominoData.Values.Balance;
			Lobby.profileView.AvatarURL = DominoData.User.Avatar;
		}

		protected void ParseInit(ResponseInit responseInit)
		{
			DominoData.Responses.init = responseInit;
			DominoData.Values.Balance = responseInit.balance;
			DominoData.User.Name = responseInit.username;
			DominoData.User.Avatar = responseInit.avatar;
		}
	}

	private class Enter : BaseLobbyState, IState
	{
		public const string Name = "Enter";

		public override string GetName
		{
			get
			{
				return "Enter";
			}
		}

		public Enter(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnUpdate(float deltaTime)
		{
			ChangeState("Ready");
		}
	}

	private class Finish : BaseLobbyState, IState
	{
		public const string Name = "Finish";

		public override string GetName
		{
			get
			{
				return "Finish";
			}
		}

		public Finish(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnEnter(string oldState, object args)
		{
			ChangeActiveController(args as string);
		}

		public override void OnExit(string newState)
		{
			base.Lobby.Hide();
		}
	}

	private class Leaders : BaseLobbyState, IState
	{
		public const string Name = "Leaders";

		private GameInfo currentGame;

		private string currentTime;

		private string activeLeaders;

		public override string GetName
		{
			get
			{
				return "Leaders";
			}
		}

		private ResponseLeaderboard this[string key]
		{
			get
			{
				if (DominoData.Responses.lbs.ContainsKey(key))
				{
					return DominoData.Responses.lbs[key];
				}
				return null;
			}
			set
			{
				if (DominoData.Responses.lbs.ContainsKey(key))
				{
					DominoData.Responses.lbs[key] = value;
				}
				else
				{
					DominoData.Responses.lbs.Add(key, value);
				}
			}
		}

		public Leaders(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.Leaderboard.SetGames(DominoData.Games.OnlineEnables());
			base.Leaderboard.OnClick += Leaderboard_OnClick;
			base.Leaderboard.times.OnClick += Times_OnClick;
			base.Leaderboard.games.OnClick += Games_OnClick;
		}

		public override void OnEnter(string oldState, object args)
		{
			if (currentGame == null)
			{
				currentGame = DominoData.Games.Default;
				currentTime = "around";
			}
			base.LobbyPopups.Show();
			base.Leaderboard.games.Select(currentGame);
			base.Leaderboard.times.Select(currentTime);
			CallLeaderboard(currentGame, currentTime);
		}

		public override void OnEscape()
		{
			ChangeState("Ready");
		}

		public override void OnExit(string newState)
		{
			base.Leaderboard.Hide();
			base.LobbyPopups.Hide();
		}

		private void Leaderboard_OnClick(string message)
		{
			if (isActive && message == "escape")
			{
				OnEscape();
			}
		}

		private void Times_OnClick(string time)
		{
			currentTime = time;
			CallLeaderboard(currentGame, currentTime);
		}

		private void Games_OnClick(GameInfo gameInfo)
		{
			currentGame = gameInfo;
			CallLeaderboard(currentGame, currentTime);
		}

		private void CallLeaderboard(GameInfo currentGame, string currentTime)
		{
			activeLeaders = currentGame.NameOnline + "_" + currentTime;
			ResponseLeaderboard responseLeaderboard = this[activeLeaders];
			if (responseLeaderboard == null || responseLeaderboard.TimeLater > 15)
			{
				if (responseLeaderboard != null && responseLeaderboard.TimeLater > 100)
				{
					responseLeaderboard = null;
				}
				base.Leaderboard.Show(responseLeaderboard);
				base.Web.Leaderboard(currentGame.NameOnline, currentTime, OnResponseLeaderboard);
			}
			else
			{
				base.Leaderboard.Show(responseLeaderboard);
			}
		}

		private void OnResponseLeaderboard(ResponseLeaderboard response)
		{
			if (response != null)
			{
				string text = response.type + "_" + response.cmd;
				if (isActive && activeLeaders == text)
				{
					base.Leaderboard.Show(response);
				}
				this[text] = response;
			}
		}
	}

	private class Profile : BaseLobbyState, IState
	{
		public const string Name = "Social";

		private SocialVKController VK;

		private SocialFBController FB;

		private bool queShareVk;

		public override string GetName
		{
			get
			{
				return "Social";
			}
		}

		public Profile(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ProfileView.OnClick += SocialView_OnClick;
			base.Message.OnClick += Message_OnClick;
			VK = SocialVKController.instance;
			VK.OnLoggedIn += VK_OnLoggedIn;
			VK.OnLoggedOut += OnLogout;
			VK.OnImportFriends += VK_OnImportFriends;
			VK.OnFailed += VK_OnFailed;
			VK.OnJoingGroup += VK_OnJoingGroup;
			FB = SocialFBController.instance;
			FB.OnLogin += FB_OnLogin;
			FB.OnLogout += OnLogout;
			FB.OnFailed += FB_OnFailed;
		}

		public override void OnEnter(string oldState, object args)
		{
			Debug.Log(VK.vk.IsUserLoggedIn);
			queShareVk = false;
			base.LobbyPopups.Show();
			base.ProfileView.Show(DominoData.User, DominoData.Values, DominoData.Statistics);
			base.Web.Statistic(DominoData.Statistics.Single, OnResponseStatistic);
		}

		public override void OnEscape()
		{
			ChangeState("Ready");
		}

		public override void OnExit(string newState)
		{
			base.Message.Hide();
			base.ProfileView.Hide();
			base.LobbyPopups.Hide();
			base.LobbyPopups.ForegroundHide();
		}

		private void FB_Click()
		{
			base.ProfileView.ButtonEnable = false;
			FB.LogIn();
		}

		private void FB_OnLogin(UserProfile info, string[] ids)
		{
			if (isActive)
			{
				OnLogin(AuthType.Facebook, info);
				base.Web.Invite(ids, null);
			}
		}

		private void FB_OnFailed(string message)
		{
			if (isActive)
			{
				switch (message)
				{
				}
				base.ProfileView.ButtonEnable = true;
			}
		}

		private void FBVK_ShareClick()
		{
			switch (DominoData.User.AuthType)
			{
			case AuthType.Facebook:
				FB.Share("Dominoes", "Let’s play dominoes!", "https://nardeweb.skillcap.net/i/banners/domino_invite_banner.jpg");
				break;
			case AuthType.Vkontakte:
				queShareVk = true;
				base.LobbyPopups.ForegroundShow();
				base.Message.BoxButtons = MessageBoxButtons.YesNo;
				base.Message.Show(TextManager.GetString("ShareTitle").ToUpper(), TextManager.GetString("ShareDialog"));
				break;
			default:
				OnLogout();
				break;
			}
		}

		private void FBVK_LogoutClick()
		{
			base.ProfileView.ButtonEnable = false;
			switch (DominoData.User.AuthType)
			{
			case AuthType.Facebook:
				FB.LogOut();
				OnLogout();
				break;
			case AuthType.Vkontakte:
				VK.Logout();
				break;
			default:
				OnLogout();
				break;
			}
		}

		private void VK_Click()
		{
			if (!VK.vk.LoginProccessSterted)
			{
				base.ProfileView.ButtonEnable = false;
				VK.Login();
			}
		}

		private void VK_JoinClick()
		{
			VK.JoinVkGroup(0);
		}

		private void VK_JoinVKClick()
		{
			VK.JoinVkGroup(1);
		}

		private void VK_OnFailed(string message)
		{
			if (isActive)
			{
				switch (message)
				{
				case "get_info":
				case "get_friends":
				case "don't_data":
				case "login":
					ShowMessage(TextManager.GetString("Error"), TextManager.GetString("AuthError"));
					break;
				}
				base.ProfileView.ButtonEnable = true;
			}
		}

		private void VK_OnImportFriends(VKFriendsList friendsList)
		{
			if (isActive)
			{
				base.Web.Invite(friendsList.GetIDs(), null);
			}
		}

		private void VK_OnJoingGroup()
		{
			ShowMessage(TextManager.GetString("JoinGroupTitle"), TextManager.GetString("JoinGroupDialog"));
		}

		private void VK_OnLoggedIn(UserProfile info)
		{
			if (isActive)
			{
				OnLogin(AuthType.Vkontakte, info);
			}
		}

		private void OnLogin(AuthType authType, UserProfile info)
		{
			DominoData.User.AuthType = authType;
			DominoData.User.AccountId = info.id.ToString();
			DominoData.User.Name = info.username;
			DominoData.User.Avatar = info.avatar;
			ShowMessage(TextManager.GetString("TitleLogin_out"), TextManager.GetString("AuthSucces"));
			SendInit();
		}

		private void OnLogout()
		{
			DominoData.User.Clear();
			base.Web.Unbind(OnUnbindResponse);
		}

		private void OnResponseStatistic(ResponseStatistic response)
		{
			if (response != null)
			{
				DominoData.Statistics.Online.start = response.started;
				DominoData.Statistics.Online.finish = response.finished;
				DominoData.Statistics.Online.win = response.win;
				DominoData.Statistics.Online.loss = response.loss;
				DominoData.Values.Points = response.score;
			}
			if (isActive)
			{
				base.ProfileView.SetStatistics(DominoData.Values, DominoData.Statistics);
			}
		}

		private void ShowMessage(string title, string message)
		{
			base.LobbyPopups.ForegroundShow();
			base.Message.BoxButtons = MessageBoxButtons.OK;
			base.Message.Show(title.ToUpper(), message);
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				if (queShareVk && message == "yes" && DominoData.User.AuthType == AuthType.Vkontakte)
				{
					VK.Share();
				}
				queShareVk = false;
				base.LobbyPopups.ForegroundHide();
				base.Message.Hide();
			}
		}

		private void SocialView_OnClick(string message)
		{
			switch (message)
			{
			case "fb":
				FB_Click();
				break;
			case "vk":
				VK_Click();
				break;
			case "join":
				VK_JoinClick();
				break;
			case "joinVK":
				VK_JoinVKClick();
				break;
			case "share":
				FBVK_ShareClick();
				break;
			case "logout":
				FBVK_LogoutClick();
				break;
			case "escape":
				OnEscape();
				break;
			}
		}

		private void SendInit()
		{
			base.Web.Init(OnInitResponse);
		}

		private void OnUnbindResponse(ResponseUnbind responseUnbind)
		{
			if (responseUnbind != null)
			{
				base.Web.Init(OnInitResponse);
				ShowMessage(TextManager.GetString("TitleLogin_out"), TextManager.GetString("LogoutSucces"));
				base.ProfileView.Show(DominoData.User, DominoData.Values, DominoData.Statistics);
			}
		}

		private void OnInitResponse(ResponseInit responseInit)
		{
			if (responseInit != null)
			{
				ParseInit(responseInit);
				ProfileRefresh();
				base.ProfileView.Show(DominoData.User, DominoData.Values, DominoData.Statistics);
				base.ProfileView.ButtonEnable = true;
			}
		}
	}

	private class Quit : BaseLobbyState, IState
	{
		public const string Name = "Quit";

		public override string GetName
		{
			get
			{
				return "Quit";
			}
		}

		public Quit(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.Message.OnClick += Message_OnClick;
			base.Lobby.OnChangeView += Lobby_OnChangeView;
		}

		private void Lobby_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide)
			{
				Application.Quit();
			}
		}

		public override void OnEscape()
		{
			ChangeState("Ready");
		}

		public override void OnEnter(string oldState, object args)
		{
			base.LobbyPopups.foreground.Show();
			base.Message.BoxButtons = MessageBoxButtons.YesNo;
			base.Message.Show(TextManager.GetString("ConfirmationTitle").ToUpper(), TextManager.GetString("Confirmation"));
		}

		public override void OnExit(string newState)
		{
			base.LobbyPopups.foreground.Hide();
			base.Message.Hide();
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				if (message == "yes")
				{
					base.Lobby.Hide();
				}
				else
				{
					OnEscape();
				}
			}
		}
	}

	private class Ready : BaseLobbyState, IState
	{
		public const string Name = "Ready";

		private string nameController;

		public override string GetName
		{
			get
			{
				return "Ready";
			}
		}

		public Ready(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.Message.OnClick += Message_OnClick;
			base.Lobby.OnButtonClick += Lobby_OnButtonClick;
			base.Lobby.OnChangeView += Lobby_OnChangeView;
			DominoData.Values.OnChangeBalance += delegate(int value)
			{
				ChooseCanvas.instance.balance.Balance = value;
			};
			DominoData.Values.OnChangeBalance += delegate(int value)
			{
				LobbyCanvas.instance.profileView.Balance = value;
			};
			DominoData.User.OnChangeAvatar += delegate(string value)
			{
				LobbyCanvas.instance.profileView.AvatarURL = value;
			};
			DominoData.Values.Balance = DominoData.Values.Balance;
			DominoData.Values.Balance = DominoData.Values.Balance;
			DominoData.User.Avatar = DominoData.User.Avatar;
		}

		public override void OnEnter(string oldState, object args)
		{
			nameController = string.Empty;
			base.Lobby.Show();
			ProfileRefresh();
			GetInit();
		}

		public override void OnEscape()
		{
			ChangeState("Quit");
		}

		private void GoToGame(string name)
		{
			nameController = name;
			base.Lobby.Hide();
		}

		private void GoToOnline()
		{
			DominoData.GameCurrent = new GameCurrent(DominoData.Games.Default, false);
			GoToGame("Online");
		}

		private void GoToFriends()
		{
			if (DominoData.User.AuthType == AuthType.None)
			{
				base.Message.BoxButtons = MessageBoxButtons.YesNo;
				base.Message.Show(TextManager.GetString("NotAuthorizedTitle").ToUpper(), TextManager.GetString("NotAuthorized"));
				base.LobbyPopups.Show();
			}
			else
			{
				DominoData.GameCurrent = new GameCurrent(DominoData.Games.Default, true);
				GoToGame("Online");
			}
		}

		private void Lobby_OnChangeView(DisplayState state)
		{
			if (isActive && state == DisplayState.Hide && nameController.Length > 0)
			{
				ChangeState("Finish", nameController);
			}
		}

		private void Lobby_OnButtonClick(string message)
		{
			switch (message)
			{
			case "single game":
				GoToGame("Single");
				break;
			case "online game":
				GoToOnline();
				break;
			case "friend game":
				GoToFriends();
				break;
			case "shop":
				ChangeState("Shop");
				break;
			case "leaders":
				ChangeState("Leaders");
				break;
			case "bonus":
				GetBonus();
				break;
			case "profile":
				ChangeState("Social");
				break;
			}
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				base.Message.Hide();
				if (message == "yes")
				{
					ChangeState("Social");
				}
				else
				{
					base.LobbyPopups.Hide();
				}
			}
		}

		private void GetInit()
		{
			ResponseInit init = DominoData.Responses.init;
			if (init == null || init.TimeLater > 300)
			{
				base.Web.Init(OnResponseInit);
				base.BonusView.Show(DominoData.Bonus);
			}
		}

		private void GetBonus()
		{
			if (DominoData.Bonus.IsEnable)
			{
				base.Web.Bonus(OnResponseBonus);
			}
		}

		private void OnResponseInit(ResponseInit response)
		{
			DominoData.SetInit(response);
			if (response != null)
			{
				DominoData.User.Name = response.username;
				DominoData.User.Avatar = response.avatar;
				DominoData.Values.Balance = response.balance;
			}
			base.BonusView.Show(DominoData.Bonus);
			ProfileRefresh();
		}

		private void OnResponseBonus(ResponseBonus response)
		{
			if (response != null)
			{
				base.Lobby.profileView.AddBalance(response.balance);
				DominoData.Bonus.Set(response.bonus_timer, response.daily_bonus_level, response.reward);
				base.BonusView.Show(DominoData.Bonus);
			}
		}
	}

	private class Shop : BaseLobbyState, IState
	{
		public const string Name = "Shop";

		private ShopItemInfo selectItem;

		private float counterTime;

		public override string GetName
		{
			get
			{
				return "Shop";
			}
		}

		protected UnityIAPController UnityIAP
		{
			get
			{
				return UnityIAPController.instance;
			}
		}

		private ReceiptCollection Receipts
		{
			get
			{
				return controller.reciepts;
			}
		}

		public Shop(LobbyController gameController)
		{
			controller = gameController;
		}

		public override void OnInit()
		{
			base.ShopView.OnClick += ShopView_OnClick;
			base.ShopView.OnClickItem += ShopView_OnClickItem;
			base.Message.OnClick += Message_OnClick;
			UnityIAP.InitializePurchasing(DominoData.Shop);
			UnityIAP.OnFailed += OnPurchaseFailed;
			UnityIAP.OnPurchase += PurchaseProcess;
		}

		public override void OnEnter(string oldState, object args)
		{
			selectItem = null;
			base.LobbyPopups.Show();
			base.ShopView.Show(DominoData.Shop);
			RefreshReadyVideo();
			CheckReciept();
		}

		public override void OnEscape()
		{
			ChangeState("Ready");
		}

		public override void OnUpdate(float deltaTime)
		{
			if ((counterTime -= Time.deltaTime) < 0f)
			{
				RefreshReadyVideo();
			}
		}

		public override void OnExit(string newState)
		{
			base.ShopView.Hide();
			base.LobbyPopups.Hide();
		}

		private void OnPurchaseFailed(Product product, PurchaseFailureReason failureReason)
		{
			ShowMessage(TextManager.GetString("TitleErrorMessage"), TextManager.GetString("PurchaseFail"));
		}

		private void PurchaseProcess(PurchaseEventArgs args)
		{
			string receipt = args.purchasedProduct.receipt;
			string transactionID = args.purchasedProduct.transactionID;
			string id = args.purchasedProduct.definition.id;
			Receipts.Add(transactionID, receipt, id);
			base.Web.Purchase(transactionID, receipt, PurchaseResponse);
		}

		private void PurchaseResponse(ResponseReceipt response)
		{
			if (response != null)
			{
				if (response.status == "OK")
				{
					if (!Receipts.ContainsId(response.transactionId))
					{
						Debug.LogError("Error: Unknown transaction ID: " + response.transactionId);
					}
					else
					{
						string defenition = Receipts.GetDefenition(response.transactionId);
						ShopItemInfo shopItemInfo = DominoData.Shop[defenition];
						DominoData.Values.Balance += shopItemInfo.Size;
						Receipts.Remove(response.transactionId);
						string @string = TextManager.GetString("Purchase сomplete");
						ShowMessage(TextManager.GetString("PurchaseTitle"), string.Format(@string, shopItemInfo.Size));
					}
				}
				else if (response.msg == "Not valid receipt" || response.msg == "Invalid signature")
				{
					Receipts.Remove(response.transactionId);
				}
			}
			CheckReciept();
		}

		private void CheckReciept()
		{
			if (Receipts.Count > 0)
			{
				string text = Receipts.PullID();
				string receipt = Receipts.GetReceipt(text);
				base.Web.Purchase(text, receipt, PurchaseResponse);
			}
		}

		private void RefreshReadyVideo()
		{
			counterTime = 5f;
			//base.ShopView.RewardButton = AdsController.instance.IsRewardReady;
		}

		private void OnWatch()
		{
			
		}

		private void OnBuy()
		{
			if (selectItem != null)
			{
				Debug.Log("Buy");
				UnityIAP.BuyProductID(selectItem.Name);
			}
		}



		private void ShowMessage(string title, string message)
		{
			base.Message.BoxButtons = MessageBoxButtons.OK;
			base.Message.Show(title, message);
			base.LobbyPopups.ForegroundShow();
		}

		private void ShopView_OnClickItem(ShopItemInfo itemInfo)
		{
			if (DominoData.Shop[itemInfo.Name].Enable)
			{
				selectItem = itemInfo;
				base.ShopView.Check(itemInfo);
			}
		}

		private void ShopView_OnClick(string message)
		{
			switch (message)
			{
			case "escape":
				OnEscape();
				break;
			case "watch":
				OnWatch();
				break;
			case "buy":
				OnBuy();
				break;
			}
		}

		private void Message_OnClick(string message)
		{
			if (isActive)
			{
				base.Message.Hide();
				base.LobbyPopups.ForegroundHide();
			}
		}
	}

	public const string Name = "Lobby";

	private ReceiptCollection reciepts;

	public override string GetName
	{
		get
		{
			return "Lobby";
		}
	}

	public override void OnActive(string oldController, object args)
	{
		CheckInit();
		activeState = states["Enter"];
		activeState.IsActive = true;
		activeState.OnEnter(null, null);
	}

	public override void OnInactive(string newController)
	{
		activeState.OnExit(null);
		activeState.IsActive = false;
	}

	private void Awake()
	{
		states = new Dictionary<string, IState>();
		reciepts = new ReceiptCollection();
	}

	private void Start()
	{
		states.Add("Enter", new Enter(this));
		states.Add("Ready", new Ready(this));
		states.Add("Leaders", new Leaders(this));
		states.Add("Shop", new Shop(this));
		states.Add("Social", new Profile(this));
		states.Add("Quit", new Quit(this));
		states.Add("Finish", new Finish(this));
	}
}
