using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKReposts
	{
		public int count { get; set; }

		public int user_reposted { get; set; }

		public static VKReposts Deserialize(object reposts)
		{
			VKReposts vKReposts = new VKReposts();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)reposts;
			object value;
			if (dictionary.TryGetValue("count", out value))
			{
				vKReposts.count = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("user_reposted", out value2))
			{
				vKReposts.user_reposted = (int)(long)value2;
			}
			return vKReposts;
		}
	}
}
