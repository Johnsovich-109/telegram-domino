public class PhotonResponse
{
	private string name;

	private object[] args;

	public string Name
	{
		get
		{
			return name;
		}
		set
		{
			name = value;
		}
	}

	public object this[int index]
	{
		get
		{
			return args[index];
		}
		set
		{
			args[index] = value;
		}
	}

	public PhotonResponse(string name)
		: this(name, null)
	{
	}

	public PhotonResponse(string name, object[] args)
	{
		this.name = name;
		this.args = args;
	}
}
