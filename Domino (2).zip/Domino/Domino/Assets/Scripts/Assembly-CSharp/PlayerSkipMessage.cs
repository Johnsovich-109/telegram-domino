using System;
using UnityEngine.UI;

public class PlayerSkipMessage : EmergenceByAlphaUI
{
	public Text textMessage;

	public float timeShowing = 0.2f;

	public float timeHidding = 0.5f;

	private Action callbackMethod;

	public void Play(Action callback)
	{
		callbackMethod = callback;
		base.Timeout = timeShowing;
		EmergenceShow();
	}

	private void Start()
	{
		textMessage.text = TextManager.GetString(textMessage.text);
		Hide();
	}

	private void OnShowed()
	{
		base.Timeout = timeHidding;
		EmergenceHide();
	}

	private void OnHidden()
	{
		if (callbackMethod != null)
		{
			callbackMethod();
		}
	}
}
