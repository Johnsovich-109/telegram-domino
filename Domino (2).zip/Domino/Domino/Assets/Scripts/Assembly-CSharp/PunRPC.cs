using System;

public class PunRPC : Attribute
{
}
