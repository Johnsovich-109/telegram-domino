using UnityEngine;

public class DemoControllers : MonoBehaviour
{
	public void Check(bool state)
	{
		Debug.Log(state);
	}

	private void Awake()
	{
	}

	private void Start()
	{
	}

	private void Update()
	{
	}
}
