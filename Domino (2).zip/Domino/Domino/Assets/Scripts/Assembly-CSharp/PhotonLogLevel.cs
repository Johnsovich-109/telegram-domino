public enum PhotonLogLevel
{
	ErrorsOnly = 0,
	Informational = 1,
	Full = 2
}
