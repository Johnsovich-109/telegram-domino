namespace Dominoes
{
	public interface IOnlineGame : ISingleGame
	{
		OnlineGameResult GameOverResult { get; }

		GameState StateOnline { get; set; }

		Turn TurnCurrent { get; }

		int SyncTime { get; }

		float TurnPassedTime { get; }

		void OnlineStart(int[] ids, int active, int serverId);

		void OnlineAdd(int[] ids, int count, int senderId);

		void OnlineSkip(int senderId);

		void OnlinePlay(int boneId, int branch, int senderId);

		void OnlineRoundOver(OnlineRoundResult data);

		void OnlineGameOver(OnlineGameResult data);

		void OnlineSync(GameSync data);
	}
}
