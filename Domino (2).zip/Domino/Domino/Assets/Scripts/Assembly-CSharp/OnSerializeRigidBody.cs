public enum OnSerializeRigidBody
{
	OnlyVelocity = 0,
	OnlyAngularVelocity = 1,
	All = 2
}
