using UnityEngine.Purchasing;

namespace Dominoes
{
	public class ShopItemInfo
	{
		private string name;

		private float price;

		private int baseSize;

		private int percent;

		private int actualSize;

		private bool enable;

		private ProductType productType;

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		public int BaseSize
		{
			get
			{
				return baseSize;
			}
			set
			{
				baseSize = value;
			}
		}

		public int Size
		{
			get
			{
				return actualSize;
			}
			set
			{
				actualSize = value;
			}
		}

		public int Percent
		{
			get
			{
				return percent;
			}
			set
			{
				percent = value;
			}
		}

		public float Price
		{
			get
			{
				return price;
			}
			set
			{
				price = value;
			}
		}

		public bool Enable
		{
			get
			{
				return enable;
			}
			set
			{
				enable = value;
			}
		}

		public ProductType ProductType
		{
			get
			{
				return productType;
			}
		}

		public ShopItemInfo(string name, int baseSize, int percent, int actualSize, float price)
			: this(name, baseSize, percent, actualSize, price, true, ProductType.Consumable)
		{
		}

		public ShopItemInfo(string name, int baseSize, int percent, int actualSize, float price, bool enable)
			: this(name, baseSize, percent, actualSize, price, enable, ProductType.Consumable)
		{
		}

		public ShopItemInfo(string name, int baseSize, int percent, int actualSize, float price, bool enable, ProductType productType)
		{
			this.name = name;
			this.baseSize = baseSize;
			this.actualSize = actualSize;
			this.percent = percent;
			this.price = price;
			this.enable = enable;
			this.productType = productType;
		}

		public override string ToString()
		{
			return "ShopItemInfo: " + name + ". Size: " + baseSize + ", Price: " + price;
		}
	}
}
