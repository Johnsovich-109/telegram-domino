using System.Collections;
using System.IO;
using UnityEngine;

public class TextManager : MonoBehaviour
{
	private static TextManager instance;

	private static Hashtable textTable;

	private static bool isLoad;

	private static TextManager Instance
	{
		get
		{
			if (instance == null)
			{
				GameObject gameObject = new GameObject("TextManager");
				instance = (TextManager)gameObject.AddComponent(typeof(TextManager));
			}
			return instance;
		}
	}

	public static bool IsLoad
	{
		get
		{
			return isLoad;
		}
		set
		{
			isLoad = value;
		}
	}

	private TextManager()
	{
	}

	private void Start()
	{
		Object.DontDestroyOnLoad(this);
	}

	public static TextManager GetInstance()
	{
		return Instance;
	}

	public static bool LoadLanguage(string filename)
	{
		GetInstance();
		if (filename == null)
		{
			textTable = null;
			return false;
		}
		string text = "Languages/" + filename + ".po";
		TextAsset textAsset = (TextAsset)Resources.Load(text, typeof(TextAsset));
		if (textAsset == null)
		{
			Debug.LogError("[TextManager] " + text + " file not found.");
			return false;
		}
		if (textTable == null)
		{
			textTable = new Hashtable();
		}
		textTable.Clear();
		StringReader stringReader = new StringReader(textAsset.text);
		string text2 = null;
		string text3 = null;
		string text4;
		while ((text4 = stringReader.ReadLine()) != null)
		{
			if (text4.StartsWith("msgid \""))
			{
				text2 = text4.Substring(7, text4.Length - 8);
			}
			else if (text4.StartsWith("msgstr \""))
			{
				text3 = text4.Substring(8, text4.Length - 9);
			}
			if (text2 != null && text3 != null)
			{
				if (textTable.ContainsKey(text2))
				{
					textTable[text2] = text3;
				}
				else
				{
					textTable.Add(text2, text3);
				}
				text2 = (text3 = null);
			}
		}
		stringReader.Close();
		return true;
	}

	public static string GetString(string key)
	{
		if (!isLoad)
		{
			LoadDictionary();
		}
		if (key != null && textTable != null && textTable.ContainsKey(key))
		{
			string text = (string)textTable[key];
			if (text.Length > 0)
			{
				key = text;
			}
		}
		return key.Replace("##", "\n");
	}

	private static void LoadDictionary()
	{
		switch (Application.systemLanguage)
		{
		case SystemLanguage.English:
			LoadLanguage("Dominoes_English");
			break;
		case SystemLanguage.Russian:
			LoadLanguage("Dominoes_Russian");
			break;
		case SystemLanguage.Portuguese:
			LoadLanguage("Dominoes_Portuguese");
			break;
		case SystemLanguage.Spanish:
			LoadLanguage("Dominoes_Spanish");
			break;
		default:
			LoadLanguage("Dominoes_English");
			break;
		}
		isLoad = true;
	}
}
