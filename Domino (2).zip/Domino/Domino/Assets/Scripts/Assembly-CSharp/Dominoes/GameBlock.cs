namespace Dominoes
{
	public class GameBlock : GameManager
	{
		private const int _numberBranches = 2;

		private const int _numberOfBoneValues = 7;

		public GameBlock(int players)
			: base(players, 2, 7)
		{
			numberBonesGive = ((players != 4) ? 7 : 5);
			finalScore = 50;
			startDoubleArray = new int[6] { 6, 5, 4, 3, 2, 1 };
		}

		public override void NewRound()
		{
			base.NewRound();
			heap.Limit = heap.Count;
		}

		public override GameState Scoring()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			while (num2 < players.Count)
			{
				foreach (Bone item in players[num2])
				{
					num3 += item.Value;
				}
				players[num2].Score.Bones = num3;
				players[num2].Score.Round += num3;
				num += players[num2].Score.Round;
				num2++;
				num3 = 0;
			}
			if ((state & GameState.Block) > GameState.Start)
			{
				int scoreRoundMin = players.GetScoreRoundMin();
				players[scoreRoundMin].Score.Round = num - players[scoreRoundMin].Score.Round * 2;
				players[scoreRoundMin].Score.Game += players[scoreRoundMin].Score.Round;
				for (int i = 0; i < players.Count; i++)
				{
					if (scoreRoundMin != i)
					{
						players[i].Score.Round = 0;
					}
				}
			}
			else
			{
				for (int j = 0; j < players.Count; j++)
				{
					players[j].Score.Round = 0;
				}
				players.Last.Score.Round = num;
				players.Last.Score.Game += num;
			}
			if (CheckGameOver())
			{
				return state |= GameState.GameOver;
			}
			return state;
		}
	}
}
