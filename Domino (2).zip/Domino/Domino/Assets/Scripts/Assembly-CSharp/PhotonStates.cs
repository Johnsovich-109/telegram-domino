public enum PhotonStates
{
	ToMaster = 0,
	ToLobby = 1,
	ToGame = 2,
	Connecting = 3,
	Disconnect = 4
}
