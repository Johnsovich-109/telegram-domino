using System;

namespace Dominoes
{
	public class Branch : ListBone
	{
		private const int capacity = 14;

		public readonly int id;

		public Node head;

		public bool IsBlocked;

		public bool IsInit
		{
			get
			{
				return base.Count > 0;
			}
		}

		public bool IsAvailable
		{
			get
			{
				return base.Count > 0 && !IsBlocked;
			}
		}

		public Branch(int index)
			: base(14)
		{
			id = index;
		}

		public void Reset()
		{
			Clear();
			head = null;
		}

		public void Init(Bone bone, int value)
		{
			head = new Node(this, bone, value);
			Push(bone);
		}

		public void Play(Bone mBone)
		{
			if (base.Count == 0 || head == null)
			{
				throw new Exception("Initialization branch is not fully. ");
			}
			Node node = new Node(this, mBone);
			if (mBone.SideA == head.value)
			{
				node.value = mBone.SideB;
			}
			else
			{
				if (mBone.SideB != head.value)
				{
					DebugF.LogError(ToString());
					throw new Exception(string.Concat("Invalid move! Head: ", head, "; + ", mBone));
				}
				node.value = mBone.SideA;
			}
			Push(mBone);
			head = node;
		}

		public bool Pairing(Bone bone)
		{
			if (base.Count == 0 || bone == null)
			{
				return false;
			}
			return bone.Pairing(head.value);
		}

		public override string ToString()
		{
			return string.Concat("Branch ", id, ". [", head, "] ");
		}
	}
}
