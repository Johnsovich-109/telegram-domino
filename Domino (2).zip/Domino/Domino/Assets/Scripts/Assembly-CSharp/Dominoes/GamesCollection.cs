using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Dominoes
{
	public class GamesCollection : List<GameInfo>
	{
		private GameInfo defaultGame;

		private List<GameType> sortRussian = new List<GameType>
		{
			GameType.Kozel,
			GameType.DrawGame,
			GameType.AllFives,
			GameType.AllThrees
		};

		private List<GameType> sortSpanish = new List<GameType>
		{
			GameType.DrawGame,
			GameType.AllFives
		};

		private List<GameType> sortPortuguese = new List<GameType>
		{
			GameType.DrawGame,
			GameType.AllFives
		};

		private List<GameType> sortEnglish = new List<GameType>
		{
			GameType.DrawGame,
			GameType.AllFives
		};

		public int CountEnable
		{
			get
			{
				return this.Count((GameInfo x) => x.SingleEnable);
			}
		}

		public GameInfo this[string name]
		{
			get
			{
				return FindByName(name);
			}
		}

		public GameInfo this[GameType type]
		{
			get
			{
				return FindByType(type);
			}
		}

		public GameInfo Default
		{
			get
			{
				return defaultGame;
			}
		}

		public GamesCollection()
		{
			Add(new GameInfo(GameType.DrawGame, true, true));
			Add(new GameInfo(GameType.BlockGame, false, false));
			Add(new GameInfo(GameType.AllFives, false, false));
			Add(new GameInfo(GameType.AllThrees));
			Add(new GameInfo(GameType.Kozel, false, false));
			Add(new GameInfo(GameType.Cross));
			Add(new GameInfo(GameType.Gaple, false));
			Add(new GameInfo(GameType.MexicanTrain, false));
			Add(new GameInfo(GameType.CustomGame, false));
			defaultGame = this[GameType.DrawGame];
			switch (Application.systemLanguage)
			{
			case SystemLanguage.Russian:
				GameSorting(sortRussian);
				break;
			case SystemLanguage.Portuguese:
				GameSorting(sortPortuguese);
				break;
			case SystemLanguage.Spanish:
				GameSorting(sortSpanish);
				break;
			default:
				GameSorting(sortEnglish);
				break;
			}
		}

		private void GameSorting(List<GameType> sort)
		{
			for (int i = 0; i < sort.Count && i < base.Count; i++)
			{
				if (sort[i] != base[i].gameType)
				{
					int index = getIndex(sort[i]);
					GameInfo value = base[index];
					base[index] = base[i];
					base[i] = value;
				}
			}
			Reverse();
		}

		private int getIndex(GameType gameType)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].gameType == gameType)
				{
					return i;
				}
			}
			throw new Exception("Game not found: " + gameType);
		}

		public GameInfo[] SingleEnable()
		{
			return this.Where((GameInfo x) => x.SingleEnable).ToArray();
		}

		public GameInfo[] OnlineEnables()
		{
			return this.Where((GameInfo x) => x.OnlineEnable).ToArray();
		}

		private GameInfo FindByName(string name)
		{
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					GameInfo current = enumerator.Current;
					if (name == current.Name)
					{
						return current;
					}
				}
			}
			return null;
		}

		private GameInfo FindByType(GameType type)
		{
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					GameInfo current = enumerator.Current;
					if (type == current.gameType)
					{
						return current;
					}
				}
			}
			return null;
		}

		public static GameType GetTypeByNumber(int table)
		{
			switch (table)
			{
			case 0:
				return GameType.DrawGame;
			case 1:
				return GameType.BlockGame;
			case 2:
				return GameType.AllFives;
			case 3:
				return GameType.Kozel;
			default:
				throw new Exception("Unknown game number: " + table);
			}
		}
	}
}
