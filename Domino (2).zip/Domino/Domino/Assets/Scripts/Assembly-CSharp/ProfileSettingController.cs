using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ProfileSettingController : PopupBehaviour
{
	public Text textTitle;

	public Text textPlayerName;

	public Text[] textButtons;

	public Button buttonFacebook;

	public Button buttonVkontakte;

	public AvatarView avatar;

	public ProfileStatistic singleStatistic;

	public ProfileStatistic onlineStatistic;

	public GameObject blockWithAuth;

	public GameObject blockWithFB;

	public GameObject blockWithVK;

	private bool buttonEnable;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool ButtonEnable
	{
		get
		{
			return buttonEnable;
		}
		set
		{
			buttonEnable = value;
			buttonFacebook.interactable = value;
			buttonVkontakte.interactable = value;
		}
	}

	public string Username
	{
		get
		{
			return textPlayerName.text;
		}
		set
		{
			if (value.Length == 0)
			{
				textPlayerName.text = TextManager.GetString("Player");
			}
			else
			{
				textPlayerName.text = value;
			}
		}
	}

	public event Action<string> OnClick;

	public void Show(UserData data, GameValues values, Statistics statistics)
	{
		base.Show();
		ButtonEnable = true;
		SetAuthType(data.AuthType);
		SetUserData(data);
		SetStatistics(values, statistics);
	}

	public void SetStatistics(GameValues values, Statistics statistics)
	{
		singleStatistic.Set(statistics.Single);
		onlineStatistic.Set(statistics.Online);
		singleStatistic.gameScored.ActiveSelf = false;
		onlineStatistic.gameScored.Value = values.Points.ToString("### ### ##0").Trim();
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void SetUserData(UserData data)
	{
		Username = data.Name;
		avatar.AvatarURL = data.Avatar;
	}

	private void SetAuthType(AuthType authType)
	{
		switch (authType)
		{
		case AuthType.None:
			SetButtons(true, false, false);
			break;
		case AuthType.Facebook:
			SetButtons(false, true, false);
			break;
		case AuthType.Vkontakte:
			SetButtons(false, false, true);
			break;
		}
	}

	private void Start()
	{
		Title = TextManager.GetString(Title).ToUpper();
		Text[] array = textButtons;
		foreach (Text text in array)
		{
			text.text = TextManager.GetString(text.text);
		}
	}

	private void SetButtons(bool auth, bool facebook, bool vkontakte)
	{
		blockWithAuth.SetActive(auth);
		blockWithFB.SetActive(facebook);
		blockWithVK.SetActive(vkontakte);
	}
}
