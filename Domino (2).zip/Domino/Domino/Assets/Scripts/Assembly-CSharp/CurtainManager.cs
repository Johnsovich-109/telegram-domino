using System;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class CurtainManager : GameBehaviour
{
	public Image imageCurtain;

	public Color colorHide = Color.clear;

	public Color colorShow = Color.black;

	protected DisplayState currentState = DisplayState.Hide;

	public DisplayState State
	{
		get
		{
			return currentState;
		}
		private set
		{
			currentState = value;
		}
	}

	public virtual bool IsCanvasActive { get; set; }

	public bool IsCurtainShow
	{
		get
		{
			return imageCurtain.gameObject.activeSelf;
		}
		protected set
		{
			imageCurtain.gameObject.SetActive(value);
		}
	}

	public bool IsShow
	{
		get
		{
			return currentState == DisplayState.Show || currentState == DisplayState.Showing;
		}
	}

	public bool IsHide
	{
		get
		{
			return currentState == DisplayState.Hide || currentState == DisplayState.Hidding;
		}
	}

	public event Action<DisplayState> OnChangeView;

	public virtual void Show()
	{
		if (IsHide)
		{
			currentState = DisplayState.Showing;
			IsCanvasActive = true;
			IsCurtainShow = true;
			SetForeground(colorHide, colorShow, ShowedInternal);
		}
	}

	public virtual void Hide()
	{
		if (IsShow)
		{
			currentState = DisplayState.Hidding;
			IsCurtainShow = true;
			SetForeground(colorShow, colorHide, HiddenInternal);
		}
	}

	public void Reset()
	{
		IsCurtainShow = false;
		IsCanvasActive = false;
	}

	public virtual void OnShowed()
	{
	}

	public virtual void OnHidden()
	{
	}

	private void ShowedInternal()
	{
		currentState = DisplayState.Show;
		OnShowed();
		if (this.OnChangeView != null)
		{
			this.OnChangeView(currentState);
		}
	}

	private void HiddenInternal()
	{
		currentState = DisplayState.Hide;
		IsCurtainShow = false;
		IsCanvasActive = false;
		OnHidden();
		if (this.OnChangeView != null)
		{
			this.OnChangeView(currentState);
		}
	}

	private void SetForeground(Color colorFrom, Color colorTo, Action callback)
	{
		StartCoroutine(Tools.ChangeColor(imageCurtain, colorFrom, colorTo, 0.3f, callback));
	}
}
