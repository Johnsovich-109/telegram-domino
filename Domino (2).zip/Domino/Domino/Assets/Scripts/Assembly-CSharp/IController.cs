public interface IController
{
	bool IsActive { get; set; }

	string GetName { get; }

	void OnActive(string oldController, object args);

	void OnInactive(string newController);

	void OnEscape();

	void OnInvite();

	void OnUpdate(float deltaTime);
}
