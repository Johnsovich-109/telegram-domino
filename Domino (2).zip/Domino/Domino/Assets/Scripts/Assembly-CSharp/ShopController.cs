using System;
using System.Linq;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ShopController : PopupBehaviour
{
	public Text textTitle;

	public Text textButtonBuy;

	public Text textButtonWatch;

	public ShopItemView[] items;

	public Button buttonRewardVideo;

	public int indexCheckDefault = 2;

	public Text[] textInFlags;

	private ShopItemInfo selected;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool RewardButton
	{
		get
		{
			return buttonRewardVideo.gameObject.activeSelf;
		}
		set
		{
			buttonRewardVideo.gameObject.SetActive(value);
		}
	}

	public event Action<string> OnClick;

	public event Action<ShopItemInfo> OnClickItem;

	public void Show(ShopCollection collection)
	{
		int countEnable = collection.CountEnable;
		if (countEnable != items.Length)
		{
			Debug.LogError("Warning: Arrays 'item' and 'shopCollection' are not equal");
		}
		for (int i = 0; i < countEnable && i < items.Length; i++)
		{
			items[i].SetData(collection[i]);
		}
		if (selected == null && collection.Count > indexCheckDefault)
		{
			selected = collection[indexCheckDefault];
			Item_OnClick(selected);
		}
		base.Show();
	}

	public override void Hide()
	{
		base.Hide();
	}

	public void Check(ShopItemInfo itemInfo)
	{
		ShopItemView[] array = items;
		foreach (ShopItemView shopItemView in array)
		{
			shopItemView.Checked = false;
		}
		if (itemInfo != null)
		{
			items.First((ShopItemView x) => x.Name == itemInfo.Name).Checked = true;
		}
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnClick != null)
		{
			this.OnClick(message);
		}
	}

	private void Start()
	{
		Text[] array = textInFlags;
		foreach (Text text in array)
		{
			text.text = TextManager.GetString(text.text).ToUpper();
		}
		Title = TextManager.GetString(Title).ToUpper();
		textButtonBuy.text = TextManager.GetString("shopBuy");
		textButtonWatch.text = TextManager.GetString("shopWatch");
		ShopItemView[] array2 = items;
		foreach (ShopItemView shopItemView in array2)
		{
			shopItemView.OnClick += Item_OnClick;
			shopItemView.Checked = false;
		}
	}

	private void Item_OnClick(ShopItemInfo item)
	{
		if (this.OnClickItem != null)
		{
			this.OnClickItem(item);
		}
	}
}
