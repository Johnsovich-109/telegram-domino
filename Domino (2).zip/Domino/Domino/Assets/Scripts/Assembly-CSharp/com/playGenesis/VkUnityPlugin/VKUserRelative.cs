using System.Collections.Generic;

namespace com.playGenesis.VkUnityPlugin
{
	public class VKUserRelative
	{
		public long id { get; set; }

		public string name { get; set; }

		public string type { get; set; }

		public static VKUserRelative Deserialize(object UserRelative)
		{
			VKUserRelative vKUserRelative = new VKUserRelative();
			Dictionary<string, object> dictionary = (Dictionary<string, object>)UserRelative;
			object value;
			if (dictionary.TryGetValue("id", out value))
			{
				vKUserRelative.id = (int)(long)value;
			}
			object value2;
			if (dictionary.TryGetValue("name", out value2))
			{
				vKUserRelative.name = (string)value2;
			}
			object value3;
			if (dictionary.TryGetValue("type", out value3))
			{
				vKUserRelative.name = (string)value3;
			}
			return vKUserRelative;
		}
	}
}
