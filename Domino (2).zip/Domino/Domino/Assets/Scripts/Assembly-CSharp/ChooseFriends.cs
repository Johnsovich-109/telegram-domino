using System;
using System.Collections.Generic;
using Dominoes;
using UnityEngine;
using UnityEngine.UI;

public class ChooseFriends : PopupBehaviour
{
	public FriendsListOnline onlineFriends;

	public FriendsListSelect selectFriends;

	public GamePreview gamePreview;

	public Transform loader;

	public Button buttonStart;

	public Button buttonVK;

	public Button buttonFB;

	public Text textGameStart;

	public Text textTitle;

	public Text textVK;

	public Text textFB;

	private float deltaTimeLoader = 0.1f;

	private float counterTime;

	private bool activeLoader;

	private bool init;

	public string Title
	{
		get
		{
			return textTitle.text;
		}
		set
		{
			textTitle.text = value;
		}
	}

	public bool ActiveLoader
	{
		get
		{
			return activeLoader;
		}
		set
		{
			activeLoader = value;
			loader.gameObject.SetActive(value);
		}
	}

	public bool ButtonStart
	{
		get
		{
			return buttonStart.interactable;
		}
		set
		{
			buttonStart.interactable = value;
		}
	}

	public event Action<string> OnButtonClick;

	public event Action<FriendData> OnOnlineFriend;

	public event Action<FriendData> OnSelectFriend;

	public void Show(GameCurrent game, FriendsCollection collection)
	{
		base.ActiveSelf = true;
		gamePreview.Show(game);
		selectFriends.SizeRoom = game.CountPlayers;
		if (collection == null)
		{
			SetButtonInvite(AuthType.None);
			SetLists(true, null, null);
		}
		else
		{
			SetButtonInvite(collection.AuthType);
			SetLists(false, collection.online, collection.select);
		}
		base.Show();
	}

	private void SetButtonInvite(AuthType authType)
	{
		buttonVK.gameObject.SetActive(authType == AuthType.Vkontakte);
		buttonFB.gameObject.SetActive(authType == AuthType.Facebook);
	}

	public void ButtonClick(string message)
	{
		GameSounds.Play(SoundType.Button);
		if (this.OnButtonClick != null)
		{
			this.OnButtonClick(message);
		}
	}

	public void SetLists(List<PhotonFriend> online, List<PhotonFriend> select)
	{
		SetLists(false, online, select);
	}

	private void SetLists(bool showLoader, List<PhotonFriend> online, List<PhotonFriend> select)
	{
		ActiveLoader = showLoader;
		onlineFriends.Set(Convert(online));
		selectFriends.Set(Convert(select));
	}

	protected override void OnHidden()
	{
		base.ActiveSelf = false;
	}

	private void Start()
	{
		textGameStart.text = TextManager.GetString("Start");
		textVK.text = TextManager.GetString("Invite from VK");
		textFB.text = TextManager.GetString("Invite from FB");
		Title = TextManager.GetString("Choose friends");
		onlineFriends.OnFriendClick += OnlineFriends_OnFriendClick;
		selectFriends.OnFriendClick += SelectFriends_OnFriendClick;
	}

	private void SelectFriends_OnFriendClick(FriendData data)
	{
		if (this.OnSelectFriend != null)
		{
			this.OnSelectFriend(data);
		}
	}

	private void OnlineFriends_OnFriendClick(FriendData data)
	{
		if (this.OnOnlineFriend != null)
		{
			this.OnOnlineFriend(data);
		}
	}

	private void Update()
	{
		if (ActiveLoader && (counterTime += Time.deltaTime) > deltaTimeLoader)
		{
			counterTime -= deltaTimeLoader;
			loader.Rotate(0f, 0f, -43f);
		}
	}

	private List<FriendData> Convert(List<PhotonFriend> source)
	{
		if (source == null)
		{
			return null;
		}
		List<FriendData> list = new List<FriendData>(source.Count);
		foreach (PhotonFriend item in source)
		{
			list.Add(item);
		}
		return list;
	}
}
