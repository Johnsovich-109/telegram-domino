using System;
using System.Collections;
using UnityEngine;

public class SmoothMover : MonoBehaviour
{
	public enum Function
	{
		Linearly = 0,
		ParabolicAcceleration = 1,
		ParabolicBraking = 2,
		HyperbolicAcceleration = 3,
		HyperbolicBraking = 4,
		Sinusoidal = 5
	}

	public Transform node;

	[SerializeField]
	private Function typeFunction = Function.ParabolicAcceleration;

	private Func<float, float> method;

	private int idMove;

	private int idScale;

	private int idRotate;

	public Function TypeFunction
	{
		get
		{
			return typeFunction;
		}
		set
		{
			typeFunction = value;
			method = SwitchMethod();
		}
	}

	public void Stop()
	{
		idMove++;
		idScale++;
		idRotate++;
	}

	public void Move(Vector3 to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothMove(node.localPosition, to, time, callBack));
	}

	public void Move(Vector3 from, Vector3 to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothMove(from, to, time, callBack));
	}

	public void Scale(float to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothScale(node.localScale, new Vector3(to, to, to), time, callBack));
	}

	public void Scale(Vector3 to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothScale(node.localScale, to, time, callBack));
	}

	public void Scale(Vector3 from, Vector3 to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothScale(from, to, time, callBack));
	}

	public void Rotate(Quaternion to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothRotate(node.localRotation, to, time, callBack));
	}

	public void Rotate(Quaternion from, Quaternion to, float time, Action callBack = null)
	{
		StartCoroutine(SmoothRotate(from, to, time, callBack));
	}

	private IEnumerator SmoothMove(Vector3 from, Vector3 to, float time, Action callback)
	{
		int id = ++idMove;
		float counterTime = 0f;
		while (counterTime < time && id == idMove)
		{
			counterTime += Time.deltaTime;
			if (counterTime > time)
			{
				counterTime = time;
			}
			node.localPosition = Vector3.Lerp(from, to, method(counterTime / time));
			yield return null;
		}
		if (id == idMove && callback != null)
		{
			callback();
		}
	}

	private IEnumerator SmoothScale(Vector3 from, Vector3 to, float time, Action callback)
	{
		float counterTime = 0f;
		int id = ++idScale;
		while (counterTime < time && id == idScale)
		{
			counterTime += Time.deltaTime;
			if (counterTime > time)
			{
				counterTime = time;
			}
			node.localScale = Vector3.Lerp(from, to, method(counterTime / time));
			yield return null;
		}
		if (id == idScale && callback != null)
		{
			callback();
		}
	}

	private IEnumerator SmoothRotate(Quaternion from, Quaternion to, float time, Action callback)
	{
		float counterTime = 0f;
		int id = ++idRotate;
		while (counterTime < time && id == idRotate)
		{
			counterTime += Time.deltaTime;
			if (counterTime > time)
			{
				counterTime = time;
			}
			node.localRotation = Quaternion.Lerp(from, to, method(counterTime / time));
			yield return null;
		}
		if (id == idRotate && callback != null)
		{
			callback();
		}
	}

	private void Awake()
	{
		node = base.transform;
		method = SwitchMethod();
	}

	private Func<float, float> SwitchMethod()
	{
		switch (typeFunction)
		{
		case Function.Linearly:
			return (float x) => x;
		case Function.ParabolicAcceleration:
			return (float x) => Mathf.Pow(x, 2f);
		case Function.ParabolicBraking:
			return (float x) => 1f - Mathf.Pow(1f - x, 2f);
		case Function.HyperbolicAcceleration:
			return (float x) => Mathf.Pow(x, 3f);
		case Function.HyperbolicBraking:
			return (float x) => 1f - Mathf.Pow(1f - x, 3f);
		case Function.Sinusoidal:
			return (float x) => 0.5f * (1f + Mathf.Sin((float)Math.PI * (1.5f - x)));
		default:
			return null;
		}
	}
}
