namespace Dominoes
{
	public enum GameType
	{
		AllFives = 0,
		AllThrees = 1,
		BlockGame = 2,
		Cross = 3,
		CustomGame = 4,
		DrawGame = 5,
		Gaple = 6,
		Kozel = 7,
		MexicanTrain = 8
	}
}
