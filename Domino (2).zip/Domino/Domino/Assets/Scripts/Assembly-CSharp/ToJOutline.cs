using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[AddComponentMenu("UI/ToJ Effects/ToJ Outline", 15)]
public class ToJOutline : Shadow
{
	protected ToJOutline()
	{
	}

	public override void ModifyMesh(VertexHelper vh)
	{
		if (!IsActive())
		{
			return;
		}
		List<UIVertex> list = new List<UIVertex>();
		vh.GetUIVertexStream(list);
		int count = list.Count;
		int num = list.Count * 5;
		if (list.Capacity < num)
		{
			list.Capacity = num;
		}
		int start = 0;
		int count2 = list.Count;
		ApplyShadowZeroAlloc(list, base.effectColor, start, list.Count, base.effectDistance.x, base.effectDistance.y);
		start = count2;
		count2 = list.Count;
		ApplyShadowZeroAlloc(list, base.effectColor, start, list.Count, base.effectDistance.x, 0f - base.effectDistance.y);
		start = count2;
		count2 = list.Count;
		ApplyShadowZeroAlloc(list, base.effectColor, start, list.Count, 0f - base.effectDistance.x, base.effectDistance.y);
		start = count2;
		count2 = list.Count;
		ApplyShadowZeroAlloc(list, base.effectColor, start, list.Count, 0f - base.effectDistance.x, 0f - base.effectDistance.y);
		Text component = GetComponent<Text>();
		if (component != null && component.material.shader == Shader.Find("Text Effects/Fancy Text"))
		{
			for (int i = 0; i < list.Count - count; i++)
			{
				UIVertex value = list[i];
				value.uv1 = new Vector2(0f, 0f);
				list[i] = value;
			}
		}
		vh.Clear();
		vh.AddUIVertexTriangleStream(list);
	}
}
