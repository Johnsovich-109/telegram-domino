using UnityEngine;
using UnityEngine.UI;

public class AvatarView : MonoBehaviour
{
	public Image imageAvatar;

	public Image imageIcon;

	public Sprite spriteBack;

	public Vector3 sizeAvatar = new Vector2(86f, 86f);

	private Sprite currentSpriteAvatar;

	private string avatarURL;

	public string AvatarURL
	{
		get
		{
			return avatarURL;
		}
		set
		{
			if (avatarURL != value)
			{
				avatarURL = value;
				if (string.IsNullOrEmpty(value))
				{
					SetDefault();
				}
				else if (!SpriteDownloader.GetAvatar(value, HandleAvatarLoader))
				{
					SetDefault();
				}
			}
		}
	}

	public void ShowAvatar()
	{
		if (currentSpriteAvatar == null)
		{
			SetIcon(SpriteDownloader.AvatarDefault);
		}
		else
		{
			SetAvatar(currentSpriteAvatar);
		}
	}

	public void HideAvatar()
	{
		avatarURL = string.Empty;
		currentSpriteAvatar = null;
	}

	private void SetIcon(Sprite sprite)
	{
		imageIcon.enabled = true;
		imageIcon.sprite = sprite;
		imageIcon.SetNativeSize();
		imageAvatar.sprite = spriteBack;
		imageAvatar.SetNativeSize();
	}

	private void SetAvatar(Sprite sprite)
	{
		imageIcon.enabled = false;
		imageAvatar.sprite = sprite;
		imageAvatar.rectTransform.sizeDelta = sizeAvatar;
	}

	private void SetDefault()
	{
		currentSpriteAvatar = null;
		SetIcon(SpriteDownloader.AvatarDefault);
	}

	private void HandleAvatarLoader(Sprite sprite)
	{
		currentSpriteAvatar = sprite;
		ShowAvatar();
	}
}
