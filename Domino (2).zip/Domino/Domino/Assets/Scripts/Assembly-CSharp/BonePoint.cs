using UnityEngine;
using UnityEngine.UI;

public class BonePoint : MonoBehaviour
{
	[HideInInspector]
	public Transform node;

	public Image image;

	private int id;

	private bool isSelect;

	public bool IsSelect
	{
		get
		{
			return isSelect;
		}
		set
		{
			isSelect = value;
		}
	}

	public int Id
	{
		get
		{
			return id;
		}
		set
		{
			id = value;
		}
	}

	public bool IsShow
	{
		get
		{
			return base.gameObject.activeSelf;
		}
		set
		{
			base.gameObject.SetActive(value);
		}
	}

	public void Revert()
	{
		IsShow = false;
	}

	public void Normalization()
	{
		node.rotation = Quaternion.identity;
	}

	public void Init()
	{
		node = base.transform;
	}
}
