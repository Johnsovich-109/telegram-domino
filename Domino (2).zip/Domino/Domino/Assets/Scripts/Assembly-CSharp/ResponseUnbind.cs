using System.Collections.Generic;

public class ResponseUnbind : ResponseBase
{
	public ResponseUnbind(Dictionary<string, object> dict)
		: base(dict)
	{
	}
}
